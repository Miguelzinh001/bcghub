import { chromium } from "playwright";
import { writeFileSync } from "node:fs";

const svg = await (await import("node:fs/promises")).readFile(
  "/workspace/.grok/favicon.svg.tmp",
  "utf8",
);

const html = `<!DOCTYPE html>
<html><head><style>
  html,body{margin:0;background:#111;width:64px;height:64px}
  .row{display:flex;gap:8px;padding:8px;background:#111}
  .s16{width:16px;height:16px}
  .s32{width:32px;height:32px}
  .s16 img,.s32 img{width:100%;height:100%;display:block}
</style></head>
<body>
  <div class="row">
    <div class="s16">${svg}</div>
    <div class="s32">${svg}</div>
  </div>
</body></html>`;

writeFileSync("/workspace/.grok/favicon-preview.html", html);

const browser = await chromium.launch();
const page = await browser.newPage({
  viewport: { width: 80, height: 48 },
  deviceScaleFactor: 8,
});
await page.setContent(html);
await page.screenshot({ path: "/workspace/.grok/favicon-preview.png", type: "png" });
await browser.close();
console.log("wrote favicon preview");
