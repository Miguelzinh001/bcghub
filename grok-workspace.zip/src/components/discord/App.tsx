import { useEffect, useState } from "react";
import { useDiscord } from "@/lib/discord/store";
import { LoginScreen } from "./Login";
import { ServerRail } from "./ServerRail";
import { DmSidebar, ChannelSidebar } from "./Sidebars";
import { ChatView, MemberList } from "./Chat";
import { FriendsView } from "./Friends";
import { OverlayHost } from "./Overlays";
import { sfx } from "@/lib/discord/sounds";
import { cn } from "@/lib/utils";

export function DiscordApp() {
  const [ready, setReady] = useState(false);
  const hydrated = useDiscord((s) => s.hydrated);
  const loggedIn = useDiscord((s) => s.loggedIn);
  const theme = useDiscord((s) => s.settings.theme);
  const lang = useDiscord((s) => s.settings.language);
  const fontScale = useDiscord((s) => s.settings.fontScale);
  const reduce = useDiscord((s) => s.settings.reduceMotion);

  useEffect(() => {
    const unsub = useDiscord.persist.onFinishHydration(() => {
      useDiscord.getState().setHydrated();
      setReady(true);
    });
    void useDiscord.persist.rehydrate();
    const t = window.setTimeout(() => {
      useDiscord.getState().setHydrated();
      setReady(true);
    }, 80);
    return () => {
      unsub();
      window.clearTimeout(t);
    };
  }, []);

  useEffect(() => {
    const mode =
      theme === "sync"
        ? window.matchMedia("(prefers-color-scheme: light)").matches
          ? "light"
          : "dark"
        : theme;
    document.documentElement.dataset.theme = mode;
    document.documentElement.lang = lang === "pt" ? "pt-BR" : "en";
    document.documentElement.style.setProperty("--dc-font", `${fontScale}px`);
    if (reduce) document.documentElement.dataset.reduce = "1";
    else delete document.documentElement.dataset.reduce;
  }, [theme, lang, fontScale, reduce]);

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      const meta = e.ctrlKey || e.metaKey;
      const st = useDiscord.getState();
      if (e.key === "Escape") {
        if (st.overlay) st.closeOverlay();
        else if (st.contextMenu) st.setContextMenu(null);
        else if (st.call) st.endCall();
        return;
      }
      if (meta && e.key.toLowerCase() === "k") {
        e.preventDefault();
        st.openOverlay("quick-switcher");
      }
      if (meta && e.key.toLowerCase() === "f") {
        e.preventDefault();
        st.openOverlay("search");
      }
      if (meta && e.key === ",") {
        e.preventDefault();
        st.openOverlay("settings");
      }
      if (meta && e.shiftKey && e.key.toLowerCase() === "m") {
        e.preventDefault();
        sfx.mute();
        st.patchVoice({ muted: !st.voice?.muted });
      }
      if (meta && e.shiftKey && e.key.toLowerCase() === "d") {
        e.preventDefault();
        sfx.deafen();
        st.patchVoice({ deafened: !st.voice?.deafened, muted: true });
      }
      if (meta && e.key.toLowerCase() === "i") {
        e.preventDefault();
        st.openOverlay("inbox");
      }
      if (meta && e.key === "/") {
        e.preventDefault();
        st.openOverlay("shortcuts");
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  if (!ready || !hydrated) return <Splash />;
  if (!loggedIn) return <LoginScreen />;
  return <Shell />;
}

function Splash() {
  return (
    <div className="grid min-h-dvh place-items-center bg-dc-server">
      <div className="flex flex-col items-center gap-4">
        <div className="grid size-16 place-items-center rounded-2xl bg-dc-brand animate-dc-pulse">
          <svg viewBox="0 0 24 24" className="size-9 fill-white">
            <path d="M12 2C6.5 2 2 6.2 2 11.4c0 3.3 1.9 6.2 4.7 8l-.2 3.4 3.5-1.9c.6.1 1.3.2 2 .2 5.5 0 10-4.2 10-9.4S17.5 2 12 2z" />
          </svg>
        </div>
        <p className="text-sm font-medium tracking-wide text-dc-muted">NEXUS</p>
      </div>
    </div>
  );
}

function Shell() {
  const activeServerId = useDiscord((s) => s.activeServerId);
  const activeDmId = useDiscord((s) => s.activeDmId);
  const activeChannelId = useDiscord((s) => s.activeChannelId);
  const mobilePane = useDiscord((s) => s.mobilePane);
  const memberListOpen = useDiscord((s) => s.memberListOpen);
  const showChat = !!(activeDmId || activeChannelId);
  const showFriends = !activeServerId && !activeDmId;

  return (
    <div className="flex h-dvh overflow-hidden bg-dc-server text-dc-text">
      <div
        className={cn(
          "h-full",
          mobilePane === "chat" || mobilePane === "members" ? "hidden md:flex" : "flex",
        )}
      >
        <ServerRail />
      </div>

      <div
        className={cn(
          "relative h-full min-w-0",
          mobilePane === "chat" || mobilePane === "members" ? "hidden md:flex" : "flex w-full md:w-auto",
        )}
      >
        {activeServerId ? <ChannelSidebar /> : <DmSidebar />}
      </div>

      <div
        className={cn(
          "min-w-0 flex-1",
          mobilePane === "list" ? "hidden md:flex" : "flex",
        )}
      >
        {showFriends && <FriendsView />}
        {showChat && (
          <div className="flex min-w-0 flex-1">
            <ChatView />
          </div>
        )}
        {!showFriends && !showChat && <FriendsView />}
      </div>

      {memberListOpen && activeServerId && showChat && (
        <div className={cn("h-full", mobilePane === "members" ? "flex" : "hidden lg:flex")}>
          <MemberList serverId={activeServerId} />
        </div>
      )}

      <OverlayHost />
    </div>
  );
}
