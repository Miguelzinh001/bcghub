import { useState } from "react";
import { useDiscord } from "@/lib/discord/store";
import { t } from "@/lib/discord/i18n";
import { AvatarArt } from "@/lib/discord/avatars";

export function LoginScreen() {
  const lang = useDiscord((s) => s.settings.language);
  const login = useDiscord((s) => s.login);
  const [mode, setMode] = useState<"login" | "register">("login");
  const [email, setEmail] = useState("trinity@nexus.gg");
  const [password, setPassword] = useState("••••••••");
  const [display, setDisplay] = useState("trinity");
  const [user, setUser] = useState("trinity");

  return (
    <div className="relative flex min-h-dvh items-center justify-center overflow-hidden bg-[#0c0d12] px-4">
      <div
        className="pointer-events-none absolute inset-0 opacity-80"
        style={{
          background:
            "radial-gradient(900px 500px at 10% 20%, #5865f233, transparent), radial-gradient(700px 400px at 90% 80%, #23a55a22, transparent)",
        }}
      />
      <div className="relative grid w-full max-w-4xl gap-0 overflow-hidden rounded-lg bg-dc-chat shadow-[var(--shadow-pop)] md:grid-cols-[1fr_280px]">
        <form
          className="p-8"
          onSubmit={(e) => {
            e.preventDefault();
            login(mode === "register" ? display : "trinity", mode === "register" ? user : "trinity");
          }}
        >
          <h1 className="text-center text-2xl font-semibold tracking-tight text-dc-heading">
            {mode === "login" ? t(lang, "loginTitle") : t(lang, "register")}
          </h1>
          <p className="mt-1 text-center text-dc-muted">{mode === "login" ? t(lang, "loginSub") : t(lang, "tos")}</p>

          {mode === "register" && (
            <>
              <label className="mt-5 block text-[11px] font-bold uppercase tracking-wide text-dc-muted">
                {t(lang, "displayName")}
              </label>
              <input
                className="mt-1 h-10 w-full rounded-sm bg-dc-server px-3 text-dc-text outline-none ring-0"
                value={display}
                onChange={(e) => setDisplay(e.target.value)}
              />
              <label className="mt-3 block text-[11px] font-bold uppercase tracking-wide text-dc-muted">
                {t(lang, "usernameField")}
              </label>
              <input
                className="mt-1 h-10 w-full rounded-sm bg-dc-server px-3 text-dc-text outline-none"
                value={user}
                onChange={(e) => setUser(e.target.value)}
              />
            </>
          )}

          <label className="mt-5 block text-[11px] font-bold uppercase tracking-wide text-dc-muted">
            {t(lang, "email")}
            <span className="text-dc-red"> *</span>
          </label>
          <input
            className="mt-1 h-10 w-full rounded-sm bg-dc-server px-3 text-dc-text outline-none"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            autoComplete="username"
          />
          <label className="mt-3 block text-[11px] font-bold uppercase tracking-wide text-dc-muted">
            {t(lang, "password")}
            <span className="text-dc-red"> *</span>
          </label>
          <input
            type="password"
            className="mt-1 h-10 w-full rounded-sm bg-dc-server px-3 text-dc-text outline-none"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoComplete="current-password"
          />
          {mode === "login" && (
            <button type="button" className="mt-1 text-sm text-dc-link hover:underline">
              {t(lang, "forgot")}
            </button>
          )}
          <button
            type="submit"
            className="mt-5 h-11 w-full rounded-sm bg-dc-brand text-[15px] font-medium text-dc-white transition-colors hover:bg-dc-brand-hover"
          >
            {mode === "login" ? t(lang, "login") : t(lang, "register")}
          </button>
          <button
            type="button"
            onClick={() => login()}
            className="mt-2 h-11 w-full rounded-sm bg-dc-green-btn text-[15px] font-medium text-dc-white hover:brightness-110"
          >
            {t(lang, "guest")}
          </button>
          <p className="mt-3 text-sm text-dc-muted">
            {mode === "login" ? t(lang, "needAccount") : t(lang, "already")}{" "}
            <button
              type="button"
              className="text-dc-link hover:underline"
              onClick={() => setMode(mode === "login" ? "register" : "login")}
            >
              {mode === "login" ? t(lang, "register") : t(lang, "login")}
            </button>
          </p>
        </form>
        <aside className="hidden flex-col items-center justify-center gap-4 border-l border-dc-divider bg-dc-sidebar p-8 md:flex">
          <div className="grid size-40 place-items-center rounded-sm bg-dc-white p-2">
            <svg viewBox="0 0 160 160" className="size-full">
              <rect width="160" height="160" fill="#fff" />
              <rect x="16" y="16" width="128" height="128" fill="#111214" />
              <rect x="28" y="28" width="28" height="28" fill="#5865f2" />
              <rect x="68" y="28" width="64" height="10" fill="#dbdee1" />
              <rect x="68" y="44" width="48" height="8" fill="#949ba4" />
              <rect x="28" y="68" width="104" height="8" fill="#dbdee1" />
              <rect x="28" y="84" width="80" height="8" fill="#949ba4" />
              <rect x="28" y="108" width="104" height="24" fill="#5865f2" />
            </svg>
          </div>
          <h2 className="text-center text-lg font-semibold text-dc-heading">{t(lang, "qr")}</h2>
          <p className="text-center text-sm text-dc-muted">{t(lang, "qrHint")}</p>
          <div className="overflow-hidden rounded-full">
            <AvatarArt id="trinity" size={40} />
          </div>
        </aside>
      </div>
    </div>
  );
}
