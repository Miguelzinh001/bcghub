import { Compass, Plus } from "lucide-react";
import { useDiscord } from "@/lib/discord/store";
import { t } from "@/lib/discord/i18n";
import { ServerIcon } from "./primitives";
import { cn } from "@/lib/utils";

export function ServerRail() {
  const servers = useDiscord((s) => s.servers);
  const active = useDiscord((s) => s.activeServerId);
  const setActiveServer = useDiscord((s) => s.setActiveServer);
  const setActiveDm = useDiscord((s) => s.setActiveDm);
  const openOverlay = useDiscord((s) => s.openOverlay);
  const setContextMenu = useDiscord((s) => s.setContextMenu);
  const lang = useDiscord((s) => s.settings.language);
  const dmUnread = useDiscord((s) => s.dms.reduce((n, d) => n + (d.unread ?? 0), 0));
  const homeActive = active === null;

  return (
    <nav
      className="flex h-full w-[72px] shrink-0 flex-col items-center gap-2 overflow-y-auto bg-dc-server py-3 dc-thin-scroll"
      aria-label={t(lang, "servers")}
    >
      <ServerHome active={homeActive} unread={dmUnread} onClick={() => setActiveDm(null)} />
      <div className="h-0.5 w-8 rounded-full bg-dc-active" />
      {servers.map((s) => (
        <ServerIcon
          key={s.id}
          avatar={s.icon}
          label={s.name}
          active={active === s.id}
          unread={s.unread > 0}
          mentions={s.mentions}
          onClick={() => setActiveServer(s.id)}
          onContextMenu={(e) => {
            e.preventDefault();
            setContextMenu({ x: e.clientX, y: e.clientY, kind: "server", id: s.id });
          }}
        />
      ))}
      <button
        type="button"
        title={t(lang, "createServer")}
        aria-label={t(lang, "createServer")}
        onClick={() => openOverlay("create-server")}
        className="grid size-12 place-items-center rounded-[22px] bg-dc-sidebar text-dc-green transition-all hover:rounded-2xl hover:bg-dc-green hover:text-dc-white"
      >
        <Plus className="size-5" />
      </button>
      <button
        type="button"
        title={t(lang, "discover")}
        aria-label={t(lang, "discover")}
        onClick={() => openOverlay("discover")}
        className="grid size-12 place-items-center rounded-[22px] bg-dc-sidebar text-dc-green transition-all hover:rounded-2xl hover:bg-dc-green hover:text-dc-white"
      >
        <Compass className="size-5" />
      </button>
    </nav>
  );
}

function ServerHome({
  active,
  unread,
  onClick,
}: {
  active: boolean;
  unread: number;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      title="Direct Messages"
      aria-label="Direct Messages"
      onClick={onClick}
      className="group relative grid size-12 place-items-center"
    >
      <span
        className={cn(
          "absolute left-0 w-1 rounded-r-full bg-dc-heading transition-all",
          active ? "h-10" : unread ? "h-2" : "h-0 group-hover:h-5",
        )}
      />
      <span
        className={cn(
          "grid size-12 place-items-center transition-all",
          active ? "rounded-2xl bg-dc-brand" : "rounded-[22px] bg-dc-sidebar group-hover:rounded-2xl group-hover:bg-dc-brand",
        )}
      >
        <svg viewBox="0 0 24 24" className="size-7 fill-dc-white">
          <path d="M12 2C6.5 2 2 6.2 2 11.4c0 3.3 1.9 6.2 4.7 8l-.2 3.4 3.5-1.9c.6.1 1.3.2 2 .2 5.5 0 10-4.2 10-9.4S17.5 2 12 2zm5.6 12.1-2.3-2.5-4.4 2.8-4.8-2.8 5.2-4.4 2.3 2.4 4.3-2.7 4.9 2.8-5.2 4.4z" />
        </svg>
      </span>
      {unread > 0 && (
        <span className="absolute -right-0.5 -bottom-0.5 min-w-4 rounded-full bg-dc-red px-1 text-center text-[10px] font-bold leading-4 text-dc-white outline outline-3 outline-dc-server">
          {unread}
        </span>
      )}
    </button>
  );
}
