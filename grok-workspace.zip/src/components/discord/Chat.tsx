import { useEffect, useRef, useState, type KeyboardEvent } from "react";
import {
  Gift,
  ImagePlus,
  PlusCircle,
  Smile,
  Sticker,
  Reply,
  MoreHorizontal,
  Hash,
  Volume2,
} from "lucide-react";
import { useDiscord, findChannel } from "@/lib/discord/store";
import { t } from "@/lib/discord/i18n";
import { Markdown } from "@/lib/discord/markdown";
import { formatClock, formatDaySep, formatFullDate, sameDay, cn } from "@/lib/utils";
import { UserAvatar, Pill, IconBtn } from "./primitives";
import { ChannelIcon, ChatHeader } from "./Sidebars";
import { serverMembers, userRoles } from "@/lib/discord/seed";
import type { Message, User } from "@/lib/discord/types";

export function ChatView() {
  const activeChannelId = useDiscord((s) => s.activeChannelId);
  const activeDmId = useDiscord((s) => s.activeDmId);
  const servers = useDiscord((s) => s.servers);
  const dms = useDiscord((s) => s.dms);
  const users = useDiscord((s) => s.users);
  const meId = useDiscord((s) => s.meId);
  const setMobilePane = useDiscord((s) => s.setMobilePane);
  const lang = useDiscord((s) => s.settings.language);

  const channel = findChannel(servers, activeChannelId);
  const dm = dms.find((d) => d.id === activeDmId);
  const other = dm ? users[dm.userIds.find((id) => id !== meId) ?? ""] : undefined;
  const title = dm
    ? dm.group
      ? dm.name ?? t(lang, "group")
      : other?.displayName ?? ""
    : channel?.name ?? "";
  const channelId = dm?.id ?? channel?.id;
  const isForum = channel?.type === "forum";
  const isStage = channel?.type === "stage";

  if (!channelId && !dm) {
    return <FriendsFallback />;
  }

  return (
    <section className="flex min-w-0 flex-1 flex-col bg-dc-chat">
      <ChatHeader
        title={title}
        icon={
          dm ? null : channel ? <ChannelIcon type={channel.type} /> : <Hash className="size-5" />
        }
        topic={channel?.topic}
        isDm={!!dm}
        onBack={() => setMobilePane("list")}
      />
      {isForum ? (
        <ForumBody channelId={channelId!} />
      ) : isStage ? (
        <StageBody name={title} />
      ) : (
        <MessageList channelId={channelId!} isDm={!!dm} other={other} title={title} />
      )}
    </section>
  );
}

function FriendsFallback() {
  return <div className="hidden flex-1 md:block" />;
}

function MessageList({
  channelId,
  isDm,
  other,
  title,
}: {
  channelId: string;
  isDm: boolean;
  other?: User;
  title: string;
}) {
  const messages = useDiscord((s) => s.messages[channelId] ?? []);
  const users = useDiscord((s) => s.users);
  const lang = useDiscord((s) => s.settings.language);
  const compact = useDiscord((s) => s.settings.messageDisplay === "compact");
  const fontScale = useDiscord((s) => s.settings.fontScale);
  const typing = useDiscord((s) => s.typing);
  const bottom = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottom.current?.scrollIntoView();
  }, [messages.length, typing]);

  return (
    <div className="flex min-h-0 flex-1">
      <div className="flex min-w-0 flex-1 flex-col">
        <div className="flex-1 overflow-y-auto dc-scroll px-1 pb-2">
          <Welcome isDm={isDm} other={other} title={title} />
          {messages.map((m, i) => {
            const prev = messages[i - 1];
            const showDay = !prev || !sameDay(prev.createdAt, m.createdAt);
            const grouped =
              !!prev &&
              prev.authorId === m.authorId &&
              !showDay &&
              new Date(m.createdAt).getTime() - new Date(prev.createdAt).getTime() < 7 * 60 * 1000 &&
              m.type === "default";
            return (
              <div key={m.id}>
                {showDay && (
                  <div className="mx-4 my-3 flex items-center gap-2 text-[12px] font-semibold text-dc-muted">
                    <span className="h-px flex-1 bg-dc-divider" />
                    {formatDaySep(m.createdAt, lang)}
                    <span className="h-px flex-1 bg-dc-divider" />
                  </div>
                )}
                <MessageRow msg={m} author={users[m.authorId]} grouped={grouped} compact={compact} fontScale={fontScale} />
              </div>
            );
          })}
          {typing && typing.channelId === channelId && typing.userIds.length > 0 && (
            <div className="flex items-center gap-2 px-4 py-1 text-sm text-dc-muted">
              <TypingDots />
              {typing.userIds.map((id) => users[id]?.displayName).join(", ")} {t(lang, "typing")}…
            </div>
          )}
          <div ref={bottom} />
        </div>
        <Composer channelId={channelId} placeholder={isDm ? `${t(lang, "messageDm")}${other?.displayName ?? title}` : `${t(lang, "messagePlaceholder")} #${title}`} />
      </div>
    </div>
  );
}

function Welcome({ isDm, other, title }: { isDm: boolean; other?: User; title: string }) {
  const lang = useDiscord((s) => s.settings.language);
  return (
    <div className="px-4 pb-3 pt-6">
      {isDm && other ? (
        <>
          <UserAvatar avatar={other.avatar} size={80} />
          <h2 className="mt-2 text-3xl font-bold text-dc-heading">{other.displayName}</h2>
          <p className="text-dc-muted">
            {t(lang, "welcomeDm")} {other.displayName}.
          </p>
        </>
      ) : (
        <>
          <div className="grid size-16 place-items-center rounded-full bg-dc-mod text-dc-heading">
            <Hash className="size-8" />
          </div>
          <h2 className="mt-2 text-3xl font-bold text-dc-heading">
            {t(lang, "emptyChat")} #{title}
          </h2>
          <p className="text-dc-muted">{t(lang, "emptyChatSub")}</p>
        </>
      )}
    </div>
  );
}

function MessageRow({
  msg,
  author,
  grouped,
  compact,
  fontScale,
}: {
  msg: Message;
  author?: User;
  grouped: boolean;
  compact: boolean;
  fontScale: number;
}) {
  const lang = useDiscord((s) => s.settings.language);
  const meId = useDiscord((s) => s.meId);
  const openProfile = useDiscord((s) => s.openProfile);
  const setContextMenu = useDiscord((s) => s.setContextMenu);
  const setReply = useDiscord((s) => s.setReply);
  const react = useDiscord((s) => s.react);
  const messages = useDiscord((s) => s.messages[msg.channelId] ?? []);
  const mentioned = msg.mentions?.includes(meId) || msg.mentionEveryone;
  const reply = msg.replyToId ? messages.find((m) => m.id === msg.replyToId) : undefined;
  const replyAuthor = reply ? useDiscord.getState().users[reply.authorId] : undefined;

  if (msg.type === "system" || msg.type === "call" || msg.type === "join" || msg.type === "boost" || msg.type === "pin") {
    return (
      <div className="px-4 py-1 text-sm text-dc-muted">
        <span className="mr-2 text-dc-faint">{formatClock(msg.createdAt)}</span>
        {msg.content}
      </div>
    );
  }

  return (
    <article
      className={cn(
        "group relative px-4 hover:bg-black/10",
        grouped && !compact ? "py-0.5" : "py-1.5",
        mentioned && "msg-mention-bar",
      )}
      onContextMenu={(e) => {
        e.preventDefault();
        setContextMenu({ x: e.clientX, y: e.clientY, kind: "message", id: msg.id, extra: msg.channelId });
      }}
    >
      {reply && (
        <div className="mb-0.5 ml-12 flex items-center gap-2 text-xs text-dc-muted">
          <span className="text-dc-faint">↱</span>
          <span className="font-medium text-dc-heading">{replyAuthor?.displayName}</span>
          <span className="truncate">{reply.content}</span>
        </div>
      )}
      <div className="flex gap-3">
        {!compact &&
          (grouped ? (
            <span className="w-10 shrink-0 pt-1 text-center text-[10px] text-transparent group-hover:text-dc-faint">
              {formatClock(msg.createdAt)}
            </span>
          ) : (
            <button type="button" onClick={() => author && openProfile(author.id)} className="shrink-0">
              <UserAvatar avatar={author?.avatar ?? "wumpus"} size={40} />
            </button>
          ))}
        <div className="min-w-0 flex-1">
          {(!grouped || compact) && (
            <div className="flex flex-wrap items-baseline gap-1.5">
              <button
                type="button"
                onClick={() => author && openProfile(author.id)}
                className="font-medium text-dc-heading hover:underline"
                style={{ color: author?.accent }}
              >
                {author?.displayName ?? t(lang, "unknown")}
              </button>
              {author?.bot && <Pill>{author.official ? t(lang, "official") : t(lang, "bot")}</Pill>}
              <time
                className="text-xs text-dc-faint"
                title={formatFullDate(msg.createdAt, lang)}
              >
                {formatClock(msg.createdAt)}
              </time>
              {msg.editedAt && <span className="text-xs text-dc-faint">{t(lang, "edited")}</span>}
              {msg.pinned && <span className="text-xs text-dc-link">{t(lang, "pinned")}</span>}
            </div>
          )}
          <div className="whitespace-pre-wrap break-words text-dc-text leading-[1.375]" style={{ fontSize: fontScale }}>
            <Markdown text={msg.content} />
          </div>
          {msg.attachments?.map((a) =>
            a.type === "image" ? (
              <img
                key={a.id}
                src={a.url}
                alt={a.name}
                className="mt-1 max-h-64 max-w-xs rounded-md outline outline-1 -outline-offset-1 outline-white/10"
              />
            ) : (
              <div key={a.id} className="mt-1 flex max-w-xs items-center gap-2 rounded-md bg-dc-sidebar p-2 text-sm">
                <ImagePlus className="size-5" />
                {a.name}
              </div>
            ),
          )}
          {msg.embeds?.map((e, i) => (
            <div
              key={i}
              className="mt-1 max-w-md overflow-hidden rounded-sm bg-dc-sidebar p-3"
              style={{ borderLeft: `4px solid ${e.color ?? "#5865f2"}` }}
            >
              {e.author && <div className="text-xs font-semibold text-dc-muted">{e.author}</div>}
              {e.title && <div className="font-semibold text-dc-heading">{e.title}</div>}
              {e.description && <div className="text-sm text-dc-text">{e.description}</div>}
              {e.footer && <div className="mt-2 text-xs text-dc-faint">{e.footer}</div>}
            </div>
          ))}
          {msg.poll && (
            <div className="mt-2 max-w-sm rounded-md bg-dc-sidebar p-3">
              <div className="font-semibold text-dc-heading">{msg.poll.question}</div>
              <div className="mt-2 space-y-1.5">
                {msg.poll.options.map((o) => {
                  const total = msg.poll!.options.reduce((n, x) => n + x.votes, 0) || 1;
                  const pct = Math.round((o.votes / total) * 100);
                  return (
                    <button
                      key={o.id}
                      type="button"
                      onClick={() => useDiscord.getState().votePoll(msg.channelId, msg.id, o.id)}
                      className="relative block w-full overflow-hidden rounded-sm bg-dc-server px-2 py-1.5 text-left text-sm"
                    >
                      <span
                        className="absolute inset-y-0 left-0 bg-dc-brand/30"
                        style={{ width: `${pct}%` }}
                      />
                      <span className="relative flex justify-between">
                        <span>{o.label}</span>
                        <span className="text-dc-muted">
                          {o.votes} · {pct}%
                        </span>
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}
          {!!msg.reactions?.length && (
            <div className="mt-1 flex flex-wrap gap-1">
              {msg.reactions.map((r) => (
                <button
                  key={r.emoji}
                  type="button"
                  onClick={() => react(msg.channelId, msg.id, r.emoji)}
                  className={cn(
                    "flex h-6 items-center gap-1 rounded-lg border px-1.5 text-sm",
                    r.me ? "border-dc-brand bg-dc-mention" : "border-transparent bg-dc-server hover:border-dc-mod",
                  )}
                >
                  {r.emoji} <span className="text-xs text-dc-muted">{r.count}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
      <div className="absolute top-0 right-4 hidden -translate-y-1/2 rounded-sm bg-dc-chat shadow-[var(--shadow-float)] group-hover:flex">
        {["😂", "🔥", "👍", "❤️"].map((e) => (
          <button
            key={e}
            type="button"
            className="grid size-8 place-items-center hover:bg-dc-hover"
            onClick={() => react(msg.channelId, msg.id, e)}
          >
            {e}
          </button>
        ))}
        <IconBtn label={t(lang, "reply")} onClick={() => setReply(msg)}>
          <Reply className="size-4" />
        </IconBtn>
        <IconBtn
          label={t(lang, "more")}
          onClick={(e) =>
            setContextMenu({ x: e.clientX, y: e.clientY, kind: "message", id: msg.id, extra: msg.channelId })
          }
        >
          <MoreHorizontal className="size-4" />
        </IconBtn>
      </div>
    </article>
  );
}

function Composer({ channelId, placeholder }: { channelId: string; placeholder: string }) {
  const composer = useDiscord((s) => s.composer);
  const setComposer = useDiscord((s) => s.setComposer);
  const send = useDiscord((s) => s.sendMessage);
  const edit = useDiscord((s) => s.editMessage);
  const editingId = useDiscord((s) => s.editingId);
  const replyTo = useDiscord((s) => s.replyTo);
  const setReply = useDiscord((s) => s.setReply);
  const setEditing = useDiscord((s) => s.setEditing);
  const openOverlay = useDiscord((s) => s.openOverlay);
  const attach = useDiscord((s) => s.attachPreview);
  const setAttach = useDiscord((s) => s.setAttach);
  const lang = useDiscord((s) => s.settings.language);
  const fileRef = useRef<HTMLInputElement>(null);
  const ta = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    ta.current?.focus();
  }, [channelId, replyTo, editingId]);

  function onKey(e: KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      if (editingId) edit(channelId, editingId, composer);
      else send(channelId, composer);
    }
    if (e.key === "Escape") {
      setReply(null);
      setEditing(null);
    }
    if (composer.startsWith("/") && e.key !== "Enter") {
      openOverlay("slash");
    }
  }

  return (
    <div className="px-4 pb-6">
      {replyTo && (
        <div className="flex items-center justify-between rounded-t-lg bg-dc-sidebar px-3 py-1.5 text-sm text-dc-muted">
          {t(lang, "reply")} · {replyTo.content.slice(0, 60)}
          <button type="button" onClick={() => setReply(null)}>
            ×
          </button>
        </div>
      )}
      {editingId && (
        <div className="rounded-t-lg bg-dc-sidebar px-3 py-1.5 text-sm text-dc-yellow">{t(lang, "edit")} · Esc para cancelar</div>
      )}
      {attach && (
        <div className="mb-1 flex items-center gap-2 rounded-md bg-dc-sidebar p-2 text-sm">
          {attach.type.startsWith("image") && (
            <img src={attach.url} alt="" className="h-16 rounded-sm" />
          )}
          {attach.name}
          <button type="button" onClick={() => setAttach(null)} className="ml-auto">
            ×
          </button>
        </div>
      )}
      <div className={cn("flex items-end gap-1 rounded-lg bg-dc-input px-2 py-1.5", (replyTo || editingId) && "rounded-t-none")}>
        <button
          type="button"
          className="grid size-10 place-items-center text-dc-muted hover:text-dc-heading"
          aria-label={t(lang, "attach")}
          onClick={() => fileRef.current?.click()}
        >
          <PlusCircle className="size-6" />
        </button>
        <input
          ref={fileRef}
          type="file"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (!f) return;
            const url = URL.createObjectURL(f);
            setAttach({ name: f.name, url, type: f.type });
          }}
        />
        <textarea
          ref={ta}
          value={composer}
          onChange={(e) => setComposer(e.target.value.slice(0, 2000))}
          onKeyDown={onKey}
          placeholder={placeholder}
          rows={1}
          className="max-h-40 min-h-10 flex-1 resize-none bg-transparent py-2 text-[15px] text-dc-text outline-none placeholder:text-dc-faint"
        />
        <IconBtn label={t(lang, "gift")} onClick={() => openOverlay("gift")}>
          <Gift className="size-5" />
        </IconBtn>
        <IconBtn label={t(lang, "gifs")} onClick={() => openOverlay("gif")}>
          <span className="text-[10px] font-black">GIF</span>
        </IconBtn>
        <IconBtn label={t(lang, "stickersBtn")} onClick={() => openOverlay("sticker")}>
          <Sticker className="size-5" />
        </IconBtn>
        <IconBtn label={t(lang, "emoji")} onClick={() => openOverlay("emoji")}>
          <Smile className="size-5" />
        </IconBtn>
      </div>
    </div>
  );
}

function TypingDots() {
  return (
    <span className="flex gap-0.5">
      {[0, 1, 2].map((i) => (
        <span
          key={i}
          className="size-1.5 rounded-full bg-dc-heading"
          style={{ animation: "dc-typing 1s ease-in-out infinite", animationDelay: `${i * 0.15}s` }}
        />
      ))}
    </span>
  );
}

export function MemberList({ serverId }: { serverId: string }) {
  const users = useDiscord((s) => s.users);
  const servers = useDiscord((s) => s.servers);
  const openProfile = useDiscord((s) => s.openProfile);
  const setContextMenu = useDiscord((s) => s.setContextMenu);
  const lang = useDiscord((s) => s.settings.language);
  const ids = serverMembers[serverId] ?? [];
  const server = servers.find((s) => s.id === serverId);
  const rolesMap = userRoles[serverId] ?? {};
  const online = ids.map((id) => users[id]).filter((u) => u && u.status !== "offline" && u.status !== "invisible");
  const offline = ids.map((id) => users[id]).filter((u) => u && (u.status === "offline" || u.status === "invisible"));

  function roleColor(uid: string) {
    const rids = rolesMap[uid] ?? [];
    const role = server?.roles.find((r) => rids.includes(r.id) && r.hoist);
    return role?.color;
  }

  return (
    <aside className="flex h-full w-60 shrink-0 flex-col bg-dc-sidebar">
      <div className="flex-1 overflow-y-auto dc-scroll px-2 py-4">
        <div className="px-2 text-[11px] font-bold uppercase tracking-wide text-dc-muted">
          {t(lang, "onlineMembers")} {online.length}
        </div>
        {online.map((u) => (
          <button
            key={u.id}
            type="button"
            onClick={() => openProfile(u.id)}
            onContextMenu={(e) => {
              e.preventDefault();
              setContextMenu({ x: e.clientX, y: e.clientY, kind: "user", id: u.id, extra: serverId });
            }}
            className="mt-0.5 flex w-full items-center gap-2 rounded-sm px-2 py-1.5 hover:bg-dc-hover"
          >
            <UserAvatar avatar={u.avatar} status={u.status} size={32} />
            <div className="min-w-0 text-left">
              <div className="truncate text-sm font-medium" style={{ color: roleColor(u.id) ?? undefined }}>
                {u.displayName}
              </div>
              {(u.customStatus || u.bot) && (
                <div className="truncate text-xs text-dc-muted">
                  {u.customStatusEmoji} {u.customStatus || (u.bot ? "App" : "")}
                </div>
              )}
            </div>
          </button>
        ))}
        <div className="mt-4 px-2 text-[11px] font-bold uppercase tracking-wide text-dc-muted">
          {t(lang, "offlineMembers")} {offline.length}
        </div>
        {offline.map((u) => (
          <button
            key={u.id}
            type="button"
            onClick={() => openProfile(u.id)}
            className="mt-0.5 flex w-full items-center gap-2 rounded-sm px-2 py-1.5 opacity-50 hover:bg-dc-hover hover:opacity-100"
          >
            <UserAvatar avatar={u.avatar} status="offline" size={32} />
            <span className="truncate text-sm">{u.displayName}</span>
          </button>
        ))}
      </div>
    </aside>
  );
}

function ForumBody({ channelId }: { channelId: string }) {
  const posts = useDiscord((s) => s.messages[channelId] ?? []);
  const users = useDiscord((s) => s.users);
  const lang = useDiscord((s) => s.settings.language);
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const send = useDiscord((s) => s.sendMessage);
  return (
    <div className="flex-1 overflow-y-auto dc-scroll p-4">
      <div className="mb-4 rounded-lg bg-dc-sidebar p-3">
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder={t(lang, "postTitle")}
          className="mb-2 h-9 w-full rounded-sm bg-dc-server px-2 text-dc-heading outline-none"
        />
        <textarea
          value={body}
          onChange={(e) => setBody(e.target.value)}
          placeholder={t(lang, "postBody")}
          className="h-20 w-full rounded-sm bg-dc-server p-2 text-sm outline-none"
        />
        <button
          type="button"
          className="mt-2 h-8 rounded-sm bg-dc-brand px-3 text-sm text-dc-white"
          onClick={() => {
            if (!title.trim()) return;
            send(channelId, `**${title}**\n\n${body}`);
            setTitle("");
            setBody("");
          }}
        >
          {t(lang, "publish")}
        </button>
      </div>
      {posts.length === 0 && <p className="text-dc-muted">{t(lang, "forumEmpty")}</p>}
      {posts.map((p) => (
        <article key={p.id} className="mb-2 rounded-lg bg-dc-sidebar p-3">
          <div className="flex items-center gap-2 text-sm">
            <UserAvatar avatar={users[p.authorId]?.avatar ?? "wumpus"} size={24} />
            <span className="font-medium text-dc-heading">{users[p.authorId]?.displayName}</span>
            <span className="text-dc-faint">{formatClock(p.createdAt)}</span>
          </div>
          <div className="mt-2 text-dc-text">
            <Markdown text={p.content} />
          </div>
          {!!p.threadCount && (
            <div className="mt-2 text-sm text-dc-link">
              {p.threadCount} {t(lang, "replies")}
            </div>
          )}
        </article>
      ))}
    </div>
  );
}

function StageBody({ name }: { name: string }) {
  const lang = useDiscord((s) => s.settings.language);
  const [onStage, setOnStage] = useState(false);
  const [hand, setHand] = useState(false);
  return (
    <div className="flex flex-1 flex-col items-center justify-center gap-4 bg-dc-elevated p-6 text-center">
      <RadioIcon />
      <h2 className="text-2xl font-bold text-dc-heading">{name}</h2>
      <p className="text-dc-muted">{t(lang, "stageEmpty")}</p>
      <div className="flex gap-2">
        <button
          type="button"
          className="h-10 rounded-sm bg-dc-green-btn px-4 text-sm font-medium text-dc-white"
          onClick={() => setOnStage(!onStage)}
        >
          {onStage ? t(lang, "leaveStage") : t(lang, "takeStage")}
        </button>
        <button
          type="button"
          className="h-10 rounded-sm bg-dc-mod px-4 text-sm text-dc-heading"
          onClick={() => setHand(!hand)}
        >
          {hand ? t(lang, "lowerHand") : t(lang, "raiseHand")}
        </button>
      </div>
      {onStage && <p className="text-sm text-dc-green">{t(lang, "speakers")} · você</p>}
    </div>
  );
}

function RadioIcon() {
  return <Volume2 className="size-16 text-dc-muted" />;
}

export function ChatWithMembers() {
  const memberListOpen = useDiscord((s) => s.memberListOpen);
  const activeServerId = useDiscord((s) => s.activeServerId);
  const activeDmId = useDiscord((s) => s.activeDmId);
  const mobilePane = useDiscord((s) => s.mobilePane);
  return (
    <div className="flex min-w-0 flex-1">
      <ChatView />
      {memberListOpen && activeServerId && !activeDmId && mobilePane !== "list" && (
        <div className="hidden h-full lg:flex">
          {/* Member list is inside ChatView for desktop; extra copy avoided */}
        </div>
      )}
    </div>
  );
}
