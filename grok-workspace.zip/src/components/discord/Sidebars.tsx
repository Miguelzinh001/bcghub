import {
  BellOff,
  ChevronDown,
  Hash,
  Headphones,
  HeadphonesOff,
  Mic,
  MicOff,
  Plus,
  Search,
  Settings,
  UserPlus,
  Volume2,
  Megaphone,
  MessagesSquare,
  Radio,
  Lock,
  Phone,
  Video,
  Users,
  Pin,
  Inbox,
  HelpCircle,
} from "lucide-react";
import { useDiscord, findServer } from "@/lib/discord/store";
import { t } from "@/lib/discord/i18n";
import { formatTimeAgo } from "@/lib/utils";
import { UserAvatar, IconBtn, Pill } from "./primitives";
import { sfx } from "@/lib/discord/sounds";
import { cn } from "@/lib/utils";
import type { Channel, ChannelType } from "@/lib/discord/types";

function ChannelIcon({ type, className }: { type: ChannelType; className?: string }) {
  const c = cn("size-4 shrink-0", className);
  if (type === "voice") return <Volume2 className={c} />;
  if (type === "announcement") return <Megaphone className={c} />;
  if (type === "forum") return <MessagesSquare className={c} />;
  if (type === "stage") return <Radio className={c} />;
  if (type === "rules") return <Lock className={c} />;
  return <Hash className={c} />;
}

export function DmSidebar() {
  const dms = useDiscord((s) => s.dms);
  const users = useDiscord((s) => s.users);
  const meId = useDiscord((s) => s.meId);
  const active = useDiscord((s) => s.activeDmId);
  const setActiveDm = useDiscord((s) => s.setActiveDm);
  const setFriendsTab = useDiscord((s) => s.setFriendsTab);
  const openOverlay = useDiscord((s) => s.openOverlay);
  const setContextMenu = useDiscord((s) => s.setContextMenu);
  const search = useDiscord((s) => s.searchQuery);
  const setSearch = useDiscord((s) => s.setSearch);
  const lang = useDiscord((s) => s.settings.language);
  const friends = useDiscord((s) => s.friends);
  const q = search.toLowerCase();

  const activeNow = friends
    .filter((f) => f.status === "friends")
    .map((f) => users[f.userId])
    .filter((u) => u && (u.status === "online" || u.status === "idle"))
    .slice(0, 8);

  const filtered = dms.filter((d) => {
    const name = d.group
      ? d.name ?? ""
      : users[d.userIds.find((id) => id !== meId) ?? ""]?.displayName ?? "";
    return name.toLowerCase().includes(q) || (d.lastMessage ?? "").toLowerCase().includes(q);
  });

  return (
    <aside className="flex h-full w-full flex-col bg-dc-sidebar md:w-60">
      <div className="flex h-12 shrink-0 items-center gap-2 px-3 shadow-[0_1px_0_var(--color-dc-divider)]">
        <div className="flex h-8 flex-1 items-center gap-2 rounded-sm bg-dc-server px-2 text-dc-muted">
          <Search className="size-4" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={t(lang, "search")}
            className="h-full w-full bg-transparent text-sm text-dc-text outline-none placeholder:text-dc-faint"
          />
        </div>
        <button
          type="button"
          title={t(lang, "addFriends")}
          onClick={() => {
            setFriendsTab("add");
            setActiveDm(null);
          }}
          className="hidden h-8 flex-1 items-center justify-center gap-1 rounded-sm bg-dc-mod text-sm font-medium text-dc-heading md:flex"
        >
          <UserPlus className="size-4" />
          {t(lang, "addFriends")}
        </button>
        <button
          type="button"
          title={t(lang, "plusMenu")}
          onClick={() => openOverlay("new-dm")}
          className="grid size-8 place-items-center rounded-sm bg-dc-brand text-dc-white"
        >
          <Plus className="size-4" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto dc-scroll pb-20">
        {activeNow.length > 0 && (
          <div className="px-2 pt-3">
            <div className="mb-2 px-2 text-[11px] font-bold uppercase tracking-wide text-dc-muted">
              {t(lang, "activeNow")}
            </div>
            <div className="flex gap-2 overflow-x-auto px-1 pb-2">
              {activeNow.map((u) => (
                <button
                  key={u.id}
                  type="button"
                  onClick={() => {
                    const dm = dms.find((d) => !d.group && d.userIds.includes(u.id));
                    if (dm) setActiveDm(dm.id);
                    else openOverlay("new-dm");
                  }}
                  className="flex w-16 shrink-0 flex-col items-center gap-1"
                >
                  <div className="rounded-2xl bg-dc-server p-1.5">
                    <UserAvatar avatar={u.avatar} status={u.status} size={48} />
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        <button
          type="button"
          onClick={() => {
            setFriendsTab("online");
            setActiveDm(null);
          }}
          className={cn(
            "mx-2 mt-1 flex h-10 items-center gap-3 rounded-md px-2 text-sm font-medium",
            !active ? "bg-dc-active text-dc-heading" : "text-dc-muted hover:bg-dc-hover hover:text-dc-heading",
          )}
        >
          <Users className="size-5" />
          {t(lang, "friends")}
        </button>
        <button
          type="button"
          onClick={() => openOverlay("nitro")}
          className="mx-2 mt-0.5 flex h-10 items-center gap-3 rounded-md px-2 text-sm font-medium text-dc-muted hover:bg-dc-hover hover:text-dc-heading"
        >
          <span className="grid size-5 place-items-center text-dc-nitro">✦</span>
          Nitro
        </button>
        <button
          type="button"
          onClick={() => openOverlay("shop")}
          className="mx-2 mt-0.5 flex h-10 items-center gap-3 rounded-md px-2 text-sm font-medium text-dc-muted hover:bg-dc-hover hover:text-dc-heading"
        >
          <span className="grid size-5 place-items-center">▣</span>
          {t(lang, "shop")}
        </button>

        <div className="mt-4 flex items-center justify-between px-4 text-[11px] font-bold uppercase tracking-wide text-dc-muted">
          {t(lang, "messages")}
          <button type="button" onClick={() => openOverlay("new-dm")} aria-label={t(lang, "newDm")}>
            <Plus className="size-3.5" />
          </button>
        </div>

        <ul className="mt-1 px-2">
          {filtered.map((d) => {
            const otherId = d.userIds.find((id) => id !== meId) ?? d.userIds[0];
            const other = users[otherId];
            const name = d.group ? d.name ?? t(lang, "group") : other?.displayName ?? t(lang, "unknown");
            const selected = active === d.id;
            return (
              <li key={d.id}>
                <button
                  type="button"
                  onClick={() => setActiveDm(d.id)}
                  onContextMenu={(e) => {
                    e.preventDefault();
                    setContextMenu({ x: e.clientX, y: e.clientY, kind: "dm", id: d.id });
                  }}
                  className={cn(
                    "flex w-full items-center gap-3 rounded-md px-2 py-2 text-left",
                    selected ? "bg-dc-active" : "hover:bg-dc-hover",
                    d.ignored && "opacity-60",
                  )}
                >
                  {d.group ? (
                    <UserAvatar avatar={d.icon ?? "wumpus"} size={40} />
                  ) : (
                    <UserAvatar avatar={other?.avatar ?? "wumpus"} status={other?.status} size={40} />
                  )}
                  <div className="min-w-0 flex-1">
                    <div className="flex items-baseline justify-between gap-2">
                      <span className="flex min-w-0 items-center truncate text-[15px] font-medium text-dc-heading">
                        {name}
                        {other?.official && <Pill tone="official">{t(lang, "official")}</Pill>}
                      </span>
                      <span className="shrink-0 text-xs text-dc-faint">{formatTimeAgo(d.lastAt, lang)}</span>
                    </div>
                    <p className="truncate text-sm text-dc-muted">
                      {d.ignored ? t(lang, "messageIgnored") : d.lastMessage}
                    </p>
                  </div>
                  {!!d.unread && d.unread > 0 && (
                    <span className="size-2 shrink-0 rounded-full bg-dc-heading" />
                  )}
                </button>
              </li>
            );
          })}
        </ul>
      </div>
      <UserPanel />
    </aside>
  );
}

export function ChannelSidebar() {
  const servers = useDiscord((s) => s.servers);
  const activeServerId = useDiscord((s) => s.activeServerId);
  const activeChannelId = useDiscord((s) => s.activeChannelId);
  const setActiveChannel = useDiscord((s) => s.setActiveChannel);
  const collapsed = useDiscord((s) => s.collapsedCats);
  const toggleCat = useDiscord((s) => s.toggleCat);
  const muted = useDiscord((s) => s.mutedChannels);
  const users = useDiscord((s) => s.users);
  const openOverlay = useDiscord((s) => s.openOverlay);
  const setServerMenu = useDiscord((s) => s.setServerMenu);
  const serverMenu = useDiscord((s) => s.serverMenu);
  const setContextMenu = useDiscord((s) => s.setContextMenu);
  const lang = useDiscord((s) => s.settings.language);
  const server = findServer(servers, activeServerId);
  if (!server) return null;

  return (
    <aside className="flex h-full w-full flex-col bg-dc-sidebar md:w-60">
      <button
        type="button"
        onClick={() => setServerMenu(!serverMenu)}
        className="flex h-12 shrink-0 items-center justify-between px-4 shadow-[0_1px_0_var(--color-dc-divider)] hover:bg-dc-hover"
      >
        <span className="flex items-center gap-2 truncate font-semibold text-dc-heading">
          {server.verified && (
            <span className="grid size-4 place-items-center rounded-full bg-dc-brand text-[9px] text-dc-white">✓</span>
          )}
          {server.name}
        </span>
        <ChevronDown className="size-4 text-dc-muted" />
      </button>
      {serverMenu && (
        <div className="absolute z-30 mt-12 ml-2 w-56 rounded-md bg-dc-elevated p-1.5 shadow-[var(--shadow-float)]">
          <MenuItem onClick={() => openOverlay("invite")}>{t(lang, "invite")}</MenuItem>
          <MenuItem onClick={() => openOverlay("server-settings")}>{t(lang, "serverSettings")}</MenuItem>
          <MenuItem onClick={() => openOverlay("create-channel")}>{t(lang, "createChannel")}</MenuItem>
          <MenuItem onClick={() => openOverlay("create-channel")}>{t(lang, "createCategory")}</MenuItem>
          <div className="my-1 h-px bg-dc-divider" />
          <MenuItem onClick={() => openOverlay("server-settings", "notifications")}>
            {t(lang, "notificationSettings")}
          </MenuItem>
          <MenuItem onClick={() => openOverlay("privacy")}>{t(lang, "privacySettings")}</MenuItem>
          <div className="my-1 h-px bg-dc-divider" />
          <MenuItem danger onClick={() => useDiscord.getState().leaveServer(server.id)}>
            {t(lang, "leaveServer")}
          </MenuItem>
        </div>
      )}
      <div className="flex-1 overflow-y-auto dc-scroll pb-20 pt-3">
        {server.categories.map((cat) => {
          const isCollapsed = collapsed[cat.id];
          return (
            <div key={cat.id} className="mb-2">
              <button
                type="button"
                onClick={() => toggleCat(cat.id)}
                className="flex w-full items-center gap-0.5 px-2 py-1 text-[11px] font-bold uppercase tracking-wide text-dc-muted hover:text-dc-heading"
              >
                <ChevronDown className={cn("size-3 transition-transform", isCollapsed && "-rotate-90")} />
                {cat.name}
                <Plus
                  className="ml-auto size-3.5"
                  onClick={(e) => {
                    e.stopPropagation();
                    openOverlay("create-channel");
                  }}
                />
              </button>
              {!isCollapsed &&
                cat.channels.map((ch) => (
                  <ChannelRow
                    key={ch.id}
                    ch={ch}
                    active={activeChannelId === ch.id}
                    muted={!!muted[ch.id]}
                    users={users}
                    onClick={() => setActiveChannel(ch.id)}
                    onContext={(e) => {
                      e.preventDefault();
                      setContextMenu({ x: e.clientX, y: e.clientY, kind: "channel", id: ch.id, extra: server.id });
                    }}
                  />
                ))}
            </div>
          );
        })}
      </div>
      <UserPanel />
    </aside>
  );
}

function ChannelRow({
  ch,
  active,
  muted,
  users,
  onClick,
  onContext,
}: {
  ch: Channel;
  active: boolean;
  muted: boolean;
  users: ReturnType<typeof useDiscord.getState>["users"];
  onClick: () => void;
  onContext: (e: React.MouseEvent) => void;
}) {
  const voice = ch.type === "voice" || ch.type === "stage";
  const connected = ch.connectedUserIds ?? [];
  return (
    <div>
      <button
        type="button"
        onClick={onClick}
        onContextMenu={onContext}
        className={cn(
          "mx-2 flex h-8 w-[calc(100%-16px)] items-center gap-1.5 rounded-sm px-2 text-[15px]",
          active ? "bg-dc-active text-dc-heading" : "text-dc-muted hover:bg-dc-hover hover:text-dc-heading",
          muted && "opacity-50",
          ch.unread && !active && "font-semibold text-dc-heading",
        )}
      >
        <ChannelIcon type={ch.type} className={ch.unread ? "text-dc-heading" : ""} />
        <span className="min-w-0 flex-1 truncate text-left">{ch.name}</span>
        {muted && <BellOff className="size-3.5" />}
        {!!ch.mentions && ch.mentions > 0 && (
          <span className="min-w-4 rounded-full bg-dc-red px-1 text-center text-[10px] font-bold leading-4 text-dc-white">
            {ch.mentions}
          </span>
        )}
      </button>
      {voice &&
        connected.map((uid) => {
          const u = users[uid];
          if (!u) return null;
          return (
            <div key={uid} className="ml-8 flex items-center gap-2 py-0.5 pr-2 text-sm text-dc-muted">
              <UserAvatar avatar={u.avatar} size={20} />
              <span className="truncate">{u.displayName}</span>
            </div>
          );
        })}
    </div>
  );
}

function MenuItem({
  children,
  onClick,
  danger,
}: {
  children: React.ReactNode;
  onClick?: () => void;
  danger?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "flex h-8 w-full items-center rounded-sm px-2 text-sm",
        danger ? "text-dc-red hover:bg-dc-red hover:text-dc-white" : "text-dc-text hover:bg-dc-brand hover:text-dc-white",
      )}
    >
      {children}
    </button>
  );
}

export function UserPanel() {
  const me = useDiscord((s) => s.users[s.meId]);
  const voice = useDiscord((s) => s.voice);
  const patchVoice = useDiscord((s) => s.patchVoice);
  const leaveVoice = useDiscord((s) => s.leaveVoice);
  const openOverlay = useDiscord((s) => s.openOverlay);
  const setUserMenu = useDiscord((s) => s.setUserMenu);
  const lang = useDiscord((s) => s.settings.language);
  const servers = useDiscord((s) => s.servers);
  if (!me) return null;
  const vc = voice
    ? servers.flatMap((s) => s.categories.flatMap((c) => c.channels)).find((c) => c.id === voice.channelId)
    : null;
  const sv = voice ? servers.find((s) => s.id === voice.serverId) : null;

  return (
    <div className="absolute bottom-0 left-[72px] right-0 z-20 md:left-auto md:w-60">
      {voice && vc && (
        <div className="border-t border-dc-divider bg-dc-sidebar px-2 py-2">
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-1 text-sm font-semibold text-dc-green">
                <span className="size-2 rounded-full bg-dc-green" />
                {t(lang, "voiceConnected")}
              </div>
              <div className="truncate text-xs text-dc-muted">
                {vc.name} / {sv?.name}
              </div>
            </div>
            <div className="flex">
              <IconBtn label={t(lang, "screen")} onClick={() => patchVoice({ streaming: !voice.streaming })}>
                <span className="text-xs">{voice.streaming ? "■" : "▣"}</span>
              </IconBtn>
              <IconBtn
                label={t(lang, "disconnect")}
                danger
                onClick={() => {
                  sfx.leave();
                  leaveVoice();
                }}
              >
                <Phone className="size-4 rotate-[135deg]" />
              </IconBtn>
            </div>
          </div>
        </div>
      )}
      <div className="flex items-center gap-1 bg-[#232428] px-2 py-1.5">
        <button
          type="button"
          onClick={() => setUserMenu(true)}
          className="flex min-w-0 flex-1 items-center gap-2 rounded-sm px-1 py-1 hover:bg-dc-hover"
        >
          <UserAvatar avatar={me.avatar} status={me.status} size={32} />
          <div className="min-w-0 text-left">
            <div className="truncate text-sm font-semibold leading-4 text-dc-heading">{me.displayName}</div>
            <div className="truncate text-xs leading-4 text-dc-muted">
              {me.customStatusEmoji ? `${me.customStatusEmoji} ` : ""}
              {me.status === "dnd" ? t(lang, "dnd") : me.customStatus || me.username}
            </div>
          </div>
        </button>
        <IconBtn
          label={voice?.muted ? t(lang, "unmute") : t(lang, "mute")}
          active={voice?.muted}
          onClick={() => {
            sfx.mute();
            patchVoice({ muted: !voice?.muted });
            if (!voice) useDiscord.setState({ voice: { channelId: "", serverId: null, muted: true, deafened: false, video: false, streaming: false, noiseSuppression: true } });
          }}
        >
          {voice?.muted ? <MicOff className="size-4 text-dc-red" /> : <Mic className="size-4" />}
        </IconBtn>
        <IconBtn
          label={voice?.deafened ? t(lang, "undeafen") : t(lang, "deafen")}
          onClick={() => {
            sfx.deafen();
            const d = !voice?.deafened;
            patchVoice({ deafened: d, muted: d || voice?.muted });
            if (!voice)
              useDiscord.setState({
                voice: { channelId: "", serverId: null, muted: true, deafened: true, video: false, streaming: false, noiseSuppression: true },
              });
          }}
        >
          {voice?.deafened ? <HeadphonesOff className="size-4 text-dc-red" /> : <Headphones className="size-4" />}
        </IconBtn>
        <IconBtn label={t(lang, "userSettings")} onClick={() => openOverlay("settings")}>
          <Settings className="size-4" />
        </IconBtn>
      </div>
    </div>
  );
}

export function ChatHeader({
  title,
  icon,
  topic,
  isDm,
  onBack,
}: {
  title: string;
  icon?: React.ReactNode;
  topic?: string;
  isDm?: boolean;
  onBack?: () => void;
}) {
  const lang = useDiscord((s) => s.settings.language);
  const openOverlay = useDiscord((s) => s.openOverlay);
  const toggleMembers = useDiscord((s) => s.toggleMembers);
  const startCall = useDiscord((s) => s.startCall);
  const activeDmId = useDiscord((s) => s.activeDmId);
  return (
    <header className="flex h-12 shrink-0 items-center gap-2 px-3 shadow-[0_1px_0_var(--color-dc-divider)]">
      {onBack && (
        <button type="button" className="mr-1 md:hidden" onClick={onBack} aria-label={t(lang, "back")}>
          ‹
        </button>
      )}
      <span className="text-dc-muted">{icon}</span>
      <h1 className="truncate font-semibold text-dc-heading">{title}</h1>
      {topic && <span className="hidden truncate text-sm text-dc-muted md:inline">— {topic}</span>}
      <div className="ml-auto flex items-center gap-0.5">
        {isDm && (
          <>
            <IconBtn
              label={t(lang, "startCall")}
              onClick={() => activeDmId && startCall(activeDmId, false)}
            >
              <Phone className="size-5" />
            </IconBtn>
            <IconBtn
              label={t(lang, "startVideo")}
              onClick={() => activeDmId && startCall(activeDmId, true)}
            >
              <Video className="size-5" />
            </IconBtn>
          </>
        )}
        <IconBtn label={t(lang, "pins")} onClick={() => openOverlay("pins")}>
          <Pin className="size-5" />
        </IconBtn>
        {!isDm && (
          <IconBtn label={t(lang, "members")} onClick={toggleMembers}>
            <Users className="size-5" />
          </IconBtn>
        )}
        <div className="mx-2 hidden h-6 w-36 items-center rounded-sm bg-dc-server px-2 text-sm text-dc-faint md:flex">
          <Search className="mr-1 size-3.5" />
          <button type="button" className="flex-1 text-left" onClick={() => openOverlay("search")}>
            {t(lang, "search")}
          </button>
        </div>
        <IconBtn label={t(lang, "inbox")} onClick={() => openOverlay("inbox")}>
          <Inbox className="size-5" />
        </IconBtn>
        <IconBtn label={t(lang, "help")} onClick={() => openOverlay("help")}>
          <HelpCircle className="size-5" />
        </IconBtn>
      </div>
    </header>
  );
}

export { ChannelIcon };
