import { SettingsModal } from "./Settings";
import { useEffect, useMemo, useState } from "react";
import {
  Compass,
  Copy,
  Hash,
  Phone,
  PhoneOff,
  Search,
  Video,
  Volume2,
  Mic,
  MicOff,
  Monitor,
  Smile,
} from "lucide-react";
import { useDiscord, allChannels } from "@/lib/discord/store";
import { t } from "@/lib/discord/i18n";
import { UserAvatar, Panel, StatusDot } from "./primitives";
import { AvatarArt } from "@/lib/discord/avatars";
import {
  activities,
  discoverCards,
  emojiCats,
  gifPack,
  quests,
  shopItems,
  slashCommands,
  soundboard,
  userRoles,
} from "@/lib/discord/seed";
import { sfx } from "@/lib/discord/sounds";
import { cn, formatFullDate } from "@/lib/utils";
import type { ChannelType, Presence } from "@/lib/discord/types";

export function OverlayHost() {
  const overlay = useDiscord((s) => s.overlay);
  const contextMenu = useDiscord((s) => s.contextMenu);
  const userMenu = useDiscord((s) => s.userMenu);
  const call = useDiscord((s) => s.call);
  const toasts = useDiscord((s) => s.toasts);
  return (
    <>
      {overlay === "settings" && <SettingsModal kind="user" />}
      {overlay === "server-settings" && <SettingsModal kind="server" />}
      {overlay === "create-server" && <CreateServer />}
      {overlay === "join-server" && <JoinServer />}
      {overlay === "create-channel" && <CreateChannel />}
      {overlay === "invite" && <InviteModal />}
      {overlay === "emoji" && <EmojiPicker />}
      {overlay === "gif" && <GifPicker />}
      {overlay === "sticker" && <StickerPicker />}
      {overlay === "slash" && <SlashPalette />}
      {overlay === "inbox" && <Inbox />}
      {overlay === "pins" && <Pins />}
      {overlay === "search" && <SearchModal />}
      {overlay === "quick-switcher" && <QuickSwitcher />}
      {overlay === "user-profile" && <UserProfile />}
      {overlay === "nitro" && <NitroModal />}
      {overlay === "shop" && <ShopModal />}
      {overlay === "quests" && <QuestsModal />}
      {overlay === "discover" && <Discover />}
      {overlay === "gift" && <GiftModal />}
      {overlay === "new-dm" && <NewDm />}
      {overlay === "group-dm" && <GroupDm />}
      {overlay === "status" && <StatusPicker />}
      {overlay === "shortcuts" && <Shortcuts />}
      {overlay === "help" && <HelpModal />}
      {overlay === "whats-new" && <WhatsNew />}
      {overlay === "soundboard" && <Soundboard />}
      {overlay === "activities" && <Activities />}
      {overlay === "nsfw" && <NsfwGate />}
      {contextMenu && <ContextMenu />}
      {userMenu && <UserStatusMenu />}
      {call && <CallOverlay />}
      <ToastStack toasts={toasts} />
    </>
  );
}

function CreateServer() {
  const lang = useDiscord((s) => s.settings.language);
  const create = useDiscord((s) => s.createServer);
  const close = useDiscord((s) => s.closeOverlay);
  const open = useDiscord((s) => s.openOverlay);
  const [name, setName] = useState("Servidor do trinity");
  return (
    <Panel onClose={close} className="w-full max-w-md p-6">
      <h2 className="text-center text-2xl font-bold text-dc-heading">{t(lang, "createServer")}</h2>
      <p className="mt-1 text-center text-sm text-dc-muted">{t(lang, "createServerSub")}</p>
      <label className="mt-5 block text-xs font-bold uppercase text-dc-muted">{t(lang, "serverName")}</label>
      <input value={name} onChange={(e) => setName(e.target.value)} className="mt-1 h-10 w-full rounded-sm bg-dc-server px-3 outline-none" />
      <div className="mt-6 flex justify-between">
        <button type="button" className="text-sm text-dc-link" onClick={() => open("join-server")}>
          {t(lang, "joinServer")}
        </button>
        <button type="button" className="h-10 rounded-sm bg-dc-brand px-6 text-sm text-dc-white" onClick={() => create(name)}>
          {t(lang, "create")}
        </button>
      </div>
    </Panel>
  );
}

function JoinServer() {
  const lang = useDiscord((s) => s.settings.language);
  const join = useDiscord((s) => s.joinServerByVanity);
  const close = useDiscord((s) => s.closeOverlay);
  const [code, setCode] = useState("nexus");
  return (
    <Panel onClose={close} className="w-full max-w-md p-6">
      <h2 className="text-xl font-bold text-dc-heading">{t(lang, "joinServer")}</h2>
      <input value={code} onChange={(e) => setCode(e.target.value)} className="mt-4 h-10 w-full rounded-sm bg-dc-server px-3 outline-none" />
      <button type="button" className="mt-4 h-10 w-full rounded-sm bg-dc-brand text-sm text-dc-white" onClick={() => join(code)}>
        {t(lang, "join")}
      </button>
    </Panel>
  );
}

function CreateChannel() {
  const lang = useDiscord((s) => s.settings.language);
  const create = useDiscord((s) => s.createChannel);
  const close = useDiscord((s) => s.closeOverlay);
  const serverId = useDiscord((s) => s.activeServerId);
  const [name, setName] = useState("");
  const [type, setType] = useState<ChannelType>("text");
  if (!serverId) return null;
  return (
    <Panel onClose={close} className="w-full max-w-md p-6">
      <h2 className="text-xl font-bold text-dc-heading">{t(lang, "createChannel")}</h2>
      <div className="mt-3 grid grid-cols-2 gap-2">
        {(["text", "voice", "announcement", "forum", "stage"] as ChannelType[]).map((tp) => (
          <button
            key={tp}
            type="button"
            onClick={() => setType(tp)}
            className={cn("h-9 rounded-sm text-sm", type === tp ? "bg-dc-brand text-dc-white" : "bg-dc-server")}
          >
            {tp}
          </button>
        ))}
      </div>
      <input
        value={name}
        onChange={(e) => setName(e.target.value)}
        placeholder={t(lang, "channelName")}
        className="mt-3 h-10 w-full rounded-sm bg-dc-server px-3 outline-none"
      />
      <button
        type="button"
        className="mt-4 h-10 w-full rounded-sm bg-dc-brand text-sm text-dc-white"
        onClick={() => create(serverId, name, type)}
      >
        {t(lang, "create")}
      </button>
    </Panel>
  );
}

function InviteModal() {
  const lang = useDiscord((s) => s.settings.language);
  const close = useDiscord((s) => s.closeOverlay);
  const server = useDiscord((s) => s.servers.find((x) => x.id === s.activeServerId));
  const toast = useDiscord((s) => s.toast);
  const link = `https://nexus.gg/${server?.vanity ?? server?.id ?? "invite"}`;
  return (
    <Panel onClose={close} className="w-full max-w-md p-6">
      <h2 className="text-xl font-bold text-dc-heading">
        {t(lang, "inviteTitle")} {server?.name}
      </h2>
      <p className="mt-1 text-sm text-dc-muted">{t(lang, "expire")}</p>
      <div className="mt-4 flex h-10 items-center gap-2 rounded-sm bg-dc-server px-2">
        <span className="flex-1 truncate text-sm">{link}</span>
        <button
          type="button"
          className="h-8 rounded-sm bg-dc-brand px-3 text-sm text-dc-white"
          onClick={() => {
            void navigator.clipboard?.writeText(link);
            toast(t(lang, "copied"));
          }}
        >
          <Copy className="size-4" />
        </button>
      </div>
    </Panel>
  );
}

function EmojiPicker() {
  const lang = useDiscord((s) => s.settings.language);
  const close = useDiscord((s) => s.closeOverlay);
  const setComposer = useDiscord((s) => s.setComposer);
  const composer = useDiscord((s) => s.composer);
  const cat = useDiscord((s) => s.emojiCategory);
  const [q, setQ] = useState("");
  return (
    <Panel onClose={close} className="flex h-[420px] w-[420px] max-w-[95vw] flex-col">
      <div className="flex items-center gap-2 border-b border-dc-divider p-2">
        <Search className="size-4 text-dc-muted" />
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t(lang, "search")} className="flex-1 bg-transparent outline-none" />
      </div>
      <div className="flex flex-1 overflow-hidden">
        <div className="w-10 overflow-y-auto border-r border-dc-divider py-2 dc-thin-scroll">
          {emojiCats.map((c) => (
            <button
              key={c.id}
              type="button"
              className="grid size-8 place-items-center text-lg"
              onClick={() => useDiscord.setState({ emojiCategory: c.id })}
            >
              {c.emojis[0]}
            </button>
          ))}
        </div>
        <div className="flex-1 overflow-y-auto p-2 dc-scroll">
          {emojiCats
            .filter((c) => c.id === cat || q)
            .map((c) => (
              <div key={c.id}>
                <div className="py-1 text-xs font-bold uppercase text-dc-muted">{t(lang, c.labelKey as "recent")}</div>
                <div className="grid grid-cols-8 gap-1">
                  {c.emojis
                    .filter((e) => !q || e.includes(q))
                    .map((e) => (
                      <button
                        key={e}
                        type="button"
                        className="grid size-8 place-items-center rounded-sm text-xl hover:bg-dc-hover"
                        onClick={() => {
                          setComposer(composer + e);
                          close();
                        }}
                      >
                        {e}
                      </button>
                    ))}
                </div>
              </div>
            ))}
        </div>
      </div>
    </Panel>
  );
}

function GifPicker() {
  const lang = useDiscord((s) => s.settings.language);
  const close = useDiscord((s) => s.closeOverlay);
  const send = useDiscord((s) => s.sendMessage);
  const channelId = useDiscord((s) => s.activeDmId ?? s.activeChannelId);
  const [q, setQ] = useState("");
  const items = gifPack.filter((g) => g.label.includes(q.toLowerCase()) || !q);
  return (
    <Panel onClose={close} className="h-[420px] w-[420px] max-w-[95vw] p-3">
      <input
        value={q}
        onChange={(e) => setQ(e.target.value)}
        placeholder={t(lang, "gifSearch")}
        className="h-9 w-full rounded-sm bg-dc-server px-2 outline-none"
      />
      <div className="mt-2 grid h-[340px] grid-cols-2 gap-2 overflow-y-auto dc-scroll">
        {items.map((g) => (
          <button
            key={g.id}
            type="button"
            onClick={() => {
              if (channelId) send(channelId, `GIF · ${g.label}`);
              close();
            }}
            className="relative h-28 overflow-hidden rounded-md"
            style={{
              background: `linear-gradient(135deg, hsl(${g.hue} 70% 45%), hsl(${(g.hue + 40) % 360} 70% 30%))`,
            }}
          >
            <span className="absolute inset-0 animate-dc-pulse" />
            <span className="absolute bottom-1 left-1 text-xs font-semibold text-white">{g.label}</span>
          </button>
        ))}
      </div>
    </Panel>
  );
}

function StickerPicker() {
  const close = useDiscord((s) => s.closeOverlay);
  const send = useDiscord((s) => s.sendMessage);
  const channelId = useDiscord((s) => s.activeDmId ?? s.activeChannelId);
  const stickers = ["wumpus", "luna", "garden", "lady", "trinity", "raven"];
  return (
    <Panel onClose={close} className="w-[360px] p-3">
      <div className="grid grid-cols-3 gap-2">
        {stickers.map((id) => (
          <button
            key={id}
            type="button"
            className="overflow-hidden rounded-md"
            onClick={() => {
              if (channelId) send(channelId, `sticker:${id}`);
              close();
            }}
          >
            <AvatarArt id={id} size={100} />
          </button>
        ))}
      </div>
    </Panel>
  );
}

function SlashPalette() {
  const composer = useDiscord((s) => s.composer);
  const setComposer = useDiscord((s) => s.setComposer);
  const close = useDiscord((s) => s.closeOverlay);
  const q = composer.replace(/^\//, "").toLowerCase();
  const items = slashCommands.filter((c) => c.name.startsWith(q) || !q);
  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-24 z-40 flex justify-center px-4">
      <div className="pointer-events-auto w-full max-w-2xl overflow-hidden rounded-md bg-dc-elevated shadow-[var(--shadow-pop)]">
        {items.slice(0, 8).map((c) => (
          <button
            key={c.name}
            type="button"
            className="flex w-full items-center gap-3 px-3 py-2 text-left hover:bg-dc-brand hover:text-dc-white"
            onClick={() => {
              setComposer("/" + c.name + " ");
              close();
            }}
          >
            <Hash className="size-4" />
            <span className="font-medium">/{c.name}</span>
            <span className="text-sm opacity-80">{c.hint}</span>
            <span className="ml-auto text-xs opacity-60">{c.bot}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

function Inbox() {
  const lang = useDiscord((s) => s.settings.language);
  const close = useDiscord((s) => s.closeOverlay);
  const messages = useDiscord((s) => s.messages);
  const meId = useDiscord((s) => s.meId);
  const users = useDiscord((s) => s.users);
  const mentions = Object.values(messages)
    .flat()
    .filter((m) => m.mentions?.includes(meId) || m.mentionEveryone)
    .slice(-20)
    .reverse();
  return (
    <Panel onClose={close} className="flex h-[480px] w-[420px] max-w-[95vw] flex-col">
      <h2 className="border-b border-dc-divider p-3 font-semibold">{t(lang, "inbox")}</h2>
      <div className="flex-1 overflow-y-auto dc-scroll p-2">
        {mentions.length === 0 && <p className="p-6 text-center text-dc-muted">{t(lang, "nothingHere")}</p>}
        {mentions.map((m) => (
          <div key={m.id} className="rounded-md p-2 hover:bg-dc-hover">
            <div className="text-sm font-medium">{users[m.authorId]?.displayName}</div>
            <div className="truncate text-sm text-dc-muted">{m.content}</div>
          </div>
        ))}
      </div>
    </Panel>
  );
}

function Pins() {
  const lang = useDiscord((s) => s.settings.language);
  const close = useDiscord((s) => s.closeOverlay);
  const channelId = useDiscord((s) => s.activeDmId ?? s.activeChannelId);
  const pins = useDiscord((s) => (s.messages[channelId ?? ""] ?? []).filter((m) => m.pinned));
  const users = useDiscord((s) => s.users);
  return (
    <Panel onClose={close} className="w-[400px] p-3">
      <h2 className="mb-2 font-semibold">{t(lang, "pins")}</h2>
      {pins.length === 0 && <p className="text-dc-muted">{t(lang, "noPins")}</p>}
      {pins.map((m) => (
        <div key={m.id} className="mb-2 rounded-md bg-dc-sidebar p-2 text-sm">
          <div className="font-medium">{users[m.authorId]?.displayName}</div>
          {m.content}
        </div>
      ))}
    </Panel>
  );
}

function SearchModal() {
  const lang = useDiscord((s) => s.settings.language);
  const close = useDiscord((s) => s.closeOverlay);
  const [q, setQ] = useState("");
  const messages = useDiscord((s) => s.messages);
  const users = useDiscord((s) => s.users);
  const hits = useMemo(() => {
    if (!q.trim()) return [];
    const l = q.toLowerCase();
    return Object.values(messages)
      .flat()
      .filter((m) => m.content.toLowerCase().includes(l))
      .slice(0, 30);
  }, [q, messages]);
  return (
    <Panel onClose={close} className="flex h-[480px] w-[560px] max-w-[95vw] flex-col p-3">
      <input
        autoFocus
        value={q}
        onChange={(e) => setQ(e.target.value)}
        placeholder={t(lang, "searchMessages")}
        className="h-10 rounded-sm bg-dc-server px-3 outline-none"
      />
      <div className="mt-2 flex-1 overflow-y-auto dc-scroll">
        {hits.map((m) => (
          <div key={m.id} className="border-b border-dc-divider py-2 text-sm">
            <span className="font-medium">{users[m.authorId]?.displayName}</span>
            <span className="ml-2 text-dc-muted">{m.content}</span>
          </div>
        ))}
      </div>
    </Panel>
  );
}

function QuickSwitcher() {
  const lang = useDiscord((s) => s.settings.language);
  const close = useDiscord((s) => s.closeOverlay);
  const servers = useDiscord((s) => s.servers);
  const dms = useDiscord((s) => s.dms);
  const users = useDiscord((s) => s.users);
  const meId = useDiscord((s) => s.meId);
  const setActiveServer = useDiscord((s) => s.setActiveServer);
  const setActiveChannel = useDiscord((s) => s.setActiveChannel);
  const setActiveDm = useDiscord((s) => s.setActiveDm);
  const [q, setQ] = useState("");
  const channels = allChannels(servers);
  const l = q.toLowerCase();
  const items = [
    ...dms
      .filter((d) => (d.name ?? users[d.userIds.find((id) => id !== meId) ?? ""]?.displayName ?? "").toLowerCase().includes(l))
      .map((d) => ({
        id: d.id,
        label: d.group ? d.name ?? "Grupo" : users[d.userIds.find((id) => id !== meId) ?? ""]?.displayName ?? "",
        kind: "dm" as const,
      })),
    ...channels
      .filter((c) => c.name.toLowerCase().includes(l))
      .map((c) => ({ id: c.id, label: "#" + c.name, kind: "ch" as const, serverId: c.serverId })),
  ].slice(0, 12);
  return (
    <Panel onClose={close} className="w-[480px] max-w-[95vw] p-2">
      <input
        autoFocus
        value={q}
        onChange={(e) => setQ(e.target.value)}
        placeholder={t(lang, "searchPlaceholder")}
        className="h-10 w-full rounded-sm bg-dc-server px-3 outline-none"
      />
      <div className="mt-1">
        {items.map((it) => (
          <button
            key={it.id}
            type="button"
            className="flex h-9 w-full items-center rounded-sm px-2 text-left hover:bg-dc-brand hover:text-white"
            onClick={() => {
              if (it.kind === "dm") setActiveDm(it.id);
              else {
                setActiveServer(it.serverId!);
                setActiveChannel(it.id);
              }
              close();
            }}
          >
            {it.label}
          </button>
        ))}
      </div>
    </Panel>
  );
}

function UserProfile() {
  const close = useDiscord((s) => s.closeOverlay);
  const id = useDiscord((s) => s.profileUserId ?? s.meId);
  const user = useDiscord((s) => s.users[id ?? ""]);
  const lang = useDiscord((s) => s.settings.language);
  const note = useDiscord((s) => s.notes[id ?? ""] ?? "");
  const setNote = useDiscord((s) => s.setNote);
  const setFriendStatus = useDiscord((s) => s.setFriendStatus);
  const dms = useDiscord((s) => s.dms);
  const setActiveDm = useDiscord((s) => s.setActiveDm);
  const startCall = useDiscord((s) => s.startCall);
  const serverId = useDiscord((s) => s.activeServerId);
  const roles = serverId ? userRoles[serverId]?.[id ?? ""] ?? [] : [];
  const server = useDiscord((s) => s.servers.find((x) => x.id === s.activeServerId));
  if (!user) return null;
  return (
    <Panel onClose={close} className="w-[340px] overflow-hidden">
      <div className="h-16" style={{ background: user.bannerColor ?? user.accent }} />
      <div className="px-4 pb-4">
        <div className="-mt-8">
          <UserAvatar avatar={user.avatar} status={user.status} size={80} />
        </div>
        <div className="mt-2 text-xl font-bold text-dc-heading">{user.displayName}</div>
        <div className="text-sm text-dc-muted">
          {user.username}
          {user.pronouns ? ` · ${user.pronouns}` : ""}
        </div>
        {user.bio && <p className="mt-2 text-sm">{user.bio}</p>}
        <div className="mt-3 text-xs font-bold uppercase text-dc-muted">{t(lang, "nexusSince")}</div>
        <div className="text-sm">{formatFullDate(user.createdAt, lang)}</div>
        {roles.length > 0 && server && (
          <>
            <div className="mt-3 text-xs font-bold uppercase text-dc-muted">{t(lang, "rolesLabel")}</div>
            <div className="mt-1 flex flex-wrap gap-1">
              {roles.map((rid) => {
                const r = server.roles.find((x) => x.id === rid);
                if (!r) return null;
                return (
                  <span key={rid} className="flex items-center gap-1 rounded-sm bg-dc-server px-1.5 py-0.5 text-xs">
                    <span className="size-2 rounded-full" style={{ background: r.color }} />
                    {r.name}
                  </span>
                );
              })}
            </div>
          </>
        )}
        <div className="mt-3 text-xs font-bold uppercase text-dc-muted">{t(lang, "note")}</div>
        <input
          defaultValue={note}
          onBlur={(e) => setNote(user.id, e.target.value)}
          placeholder={t(lang, "addNote")}
          className="mt-1 h-8 w-full rounded-sm bg-dc-server px-2 text-sm outline-none"
        />
        <div className="mt-3 flex gap-2">
          <button
            type="button"
            className="h-8 flex-1 rounded-sm bg-dc-brand text-sm text-white"
            onClick={() => {
              const dm = dms.find((d) => !d.group && d.userIds.includes(user.id));
              if (dm) setActiveDm(dm.id);
              close();
            }}
          >
            {t(lang, "messageUser")}
          </button>
          <button
            type="button"
            className="h-8 rounded-sm bg-dc-server px-3"
            onClick={() => {
              const dm = dms.find((d) => !d.group && d.userIds.includes(user.id));
              if (dm) startCall(dm.id, false);
            }}
          >
            <Phone className="size-4" />
          </button>
        </div>
        {user.id !== "trinity" && (
          <button
            type="button"
            className="mt-2 text-sm text-dc-red"
            onClick={() => setFriendStatus(user.id, "blocked")}
          >
            {t(lang, "block")}
          </button>
        )}
      </div>
    </Panel>
  );
}

function NitroModal() {
  const lang = useDiscord((s) => s.settings.language);
  const close = useDiscord((s) => s.closeOverlay);
  return (
    <Panel onClose={close} className="w-full max-w-lg p-6">
      <h2 className="text-2xl font-bold text-dc-heading">{t(lang, "nitroBoost")}</h2>
      <p className="mt-1 text-dc-muted">{t(lang, "nitroSub")}</p>
      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        <div className="rounded-lg bg-dc-sidebar p-4">
          <div className="text-lg font-bold">Nitro Basic</div>
          <div className="text-dc-muted">R$ 9,99{t(lang, "month")}</div>
          <button type="button" className="mt-3 h-9 w-full rounded-sm bg-dc-brand text-sm text-white">
            {t(lang, "subscribe")}
          </button>
        </div>
        <div className="rounded-lg bg-dc-sidebar p-4 ring-1 ring-dc-nitro">
          <div className="text-lg font-bold text-dc-nitro">Nitro</div>
          <div className="text-dc-muted">R$ 26,90{t(lang, "month")}</div>
          <button type="button" className="mt-3 h-9 w-full rounded-sm bg-dc-nitro text-sm text-white">
            {t(lang, "subscribe")}
          </button>
        </div>
      </div>
    </Panel>
  );
}

function ShopModal() {
  const lang = useDiscord((s) => s.settings.language);
  const close = useDiscord((s) => s.closeOverlay);
  return (
    <Panel onClose={close} className="w-full max-w-lg p-6">
      <h2 className="text-2xl font-bold">{t(lang, "shopTitle")}</h2>
      <p className="text-dc-muted">{t(lang, "shopSub")}</p>
      <div className="mt-4 grid grid-cols-2 gap-3">
        {shopItems.map((it) => (
          <div key={it.id} className="rounded-lg bg-dc-sidebar p-3">
            <div className="h-16 rounded-md bg-dc-mod" />
            <div className="mt-2 font-medium">{it.name}</div>
            <div className="text-xs text-dc-muted">{it.price}</div>
          </div>
        ))}
      </div>
    </Panel>
  );
}

function QuestsModal() {
  const lang = useDiscord((s) => s.settings.language);
  const close = useDiscord((s) => s.closeOverlay);
  return (
    <Panel onClose={close} className="w-full max-w-lg p-6">
      <h2 className="text-2xl font-bold">{t(lang, "questsTitle")}</h2>
      <p className="text-dc-muted">{t(lang, "questsSub")}</p>
      <div className="mt-4 space-y-3">
        {quests.map((q) => (
          <div key={q.id} className="rounded-lg bg-dc-sidebar p-3">
            <div className="flex justify-between">
              <span className="font-medium">{q.title}</span>
              <span className="text-xs text-dc-muted">
                {q.days} {t(lang, "daysLeft")}
              </span>
            </div>
            <div className="mt-2 h-2 overflow-hidden rounded-full bg-dc-server">
              <div className="h-full bg-dc-brand" style={{ width: `${q.progress}%` }} />
            </div>
            <div className="mt-1 text-xs text-dc-muted">{q.reward}</div>
          </div>
        ))}
      </div>
    </Panel>
  );
}

function Discover() {
  const lang = useDiscord((s) => s.settings.language);
  const close = useDiscord((s) => s.closeOverlay);
  const setActiveServer = useDiscord((s) => s.setActiveServer);
  const [q, setQ] = useState("");
  const cards = discoverCards.filter((c) => c.name.toLowerCase().includes(q.toLowerCase()) || c.tag.toLowerCase().includes(q.toLowerCase()));
  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-dc-server animate-dc-fade">
      <div className="mx-auto max-w-5xl px-4 py-8">
        <div className="flex items-center justify-between">
          <h1 className="flex items-center gap-2 text-2xl font-bold text-dc-heading">
            <Compass /> {t(lang, "discover")}
          </h1>
          <button type="button" onClick={close} className="text-dc-muted">
            {t(lang, "close")}
          </button>
        </div>
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder={t(lang, "searchServers")}
          className="mt-4 h-12 w-full rounded-lg bg-dc-chat px-4 outline-none"
        />
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {cards.map((c) => (
            <button
              key={c.id}
              type="button"
              onClick={() => {
                setActiveServer(c.id);
                close();
              }}
              className="overflow-hidden rounded-lg bg-dc-chat text-left"
            >
              <div className="h-20" style={{ background: `hsl(${c.name.length * 24} 40% 30%)` }} />
              <div className="-mt-6 ml-3 size-12 overflow-hidden rounded-2xl outline outline-4 outline-dc-chat">
                <AvatarArt id={c.icon} size={48} />
              </div>
              <div className="p-3">
                <div className="font-semibold text-dc-heading">{c.name}</div>
                <p className="mt-1 text-sm text-dc-muted">{c.blurb}</p>
                <div className="mt-2 flex gap-3 text-xs text-dc-muted">
                  <span className="flex items-center gap-1">
                    <span className="size-2 rounded-full bg-dc-online" />
                    {c.online}
                  </span>
                  <span>{c.members} membros</span>
                  <span className="rounded-sm bg-dc-server px-1">{c.tag}</span>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

function GiftModal() {
  const lang = useDiscord((s) => s.settings.language);
  const close = useDiscord((s) => s.closeOverlay);
  return (
    <Panel onClose={close} className="w-full max-w-sm p-6 text-center">
      <h2 className="text-xl font-bold">{t(lang, "giftTitle")}</h2>
      <p className="mt-2 text-dc-muted">{t(lang, "giftBody")}</p>
      <button type="button" className="mt-4 h-10 w-full rounded-sm bg-dc-brand text-sm text-white" onClick={close}>
        {t(lang, "sendGift")}
      </button>
    </Panel>
  );
}

function NewDm() {
  const lang = useDiscord((s) => s.settings.language);
  const close = useDiscord((s) => s.closeOverlay);
  const friends = useDiscord((s) => s.friends.filter((f) => f.status === "friends"));
  const users = useDiscord((s) => s.users);
  const dms = useDiscord((s) => s.dms);
  const setActiveDm = useDiscord((s) => s.setActiveDm);
  const setFriendStatus = useDiscord((s) => s.setFriendStatus);
  const [q, setQ] = useState("");
  return (
    <Panel onClose={close} className="w-[400px] p-4">
      <h2 className="font-semibold">{t(lang, "newDm")}</h2>
      <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t(lang, "to")} className="mt-2 h-9 w-full rounded-sm bg-dc-server px-2 outline-none" />
      <div className="mt-2 max-h-64 overflow-y-auto dc-scroll">
        {friends
          .map((f) => users[f.userId])
          .filter((u) => u && u.displayName.toLowerCase().includes(q.toLowerCase()))
          .map((u) => (
            <button
              key={u.id}
              type="button"
              className="flex w-full items-center gap-2 rounded-sm px-2 py-1.5 hover:bg-dc-hover"
              onClick={() => {
                let dm = dms.find((d) => !d.group && d.userIds.includes(u.id));
                if (!dm) {
                  setFriendStatus(u.id, "friends");
                  dm = useDiscord.getState().dms.find((d) => !d.group && d.userIds.includes(u.id));
                }
                if (dm) setActiveDm(dm.id);
                close();
              }}
            >
              <UserAvatar avatar={u.avatar} status={u.status} size={32} />
              {u.displayName}
            </button>
          ))}
      </div>
    </Panel>
  );
}

function GroupDm() {
  const lang = useDiscord((s) => s.settings.language);
  const close = useDiscord((s) => s.closeOverlay);
  const create = useDiscord((s) => s.createGroup);
  const friends = useDiscord((s) => s.friends.filter((f) => f.status === "friends"));
  const users = useDiscord((s) => s.users);
  const [sel, setSel] = useState<string[]>([]);
  const [name, setName] = useState("");
  return (
    <Panel onClose={close} className="w-[400px] p-4">
      <h2 className="font-semibold">{t(lang, "createGroup")}</h2>
      <input value={name} onChange={(e) => setName(e.target.value)} placeholder={t(lang, "groupName")} className="mt-2 h-9 w-full rounded-sm bg-dc-server px-2 outline-none" />
      <div className="mt-2 max-h-56 overflow-y-auto">
        {friends.map((f) => {
          const u = users[f.userId];
          if (!u) return null;
          const on = sel.includes(u.id);
          return (
            <button
              key={u.id}
              type="button"
              className="flex w-full items-center gap-2 px-2 py-1.5"
              onClick={() => setSel(on ? sel.filter((x) => x !== u.id) : [...sel, u.id])}
            >
              <span className={cn("grid size-4 place-items-center rounded-xs border", on && "bg-dc-brand border-dc-brand")}>
                {on ? "✓" : ""}
              </span>
              <UserAvatar avatar={u.avatar} size={24} />
              {u.displayName}
            </button>
          );
        })}
      </div>
      <button
        type="button"
        disabled={sel.length < 1}
        className="mt-3 h-9 w-full rounded-sm bg-dc-brand text-sm text-white disabled:opacity-50"
        onClick={() => create(sel, name)}
      >
        {t(lang, "create")}
      </button>
    </Panel>
  );
}

function StatusPicker() {
  const lang = useDiscord((s) => s.settings.language);
  const close = useDiscord((s) => s.closeOverlay);
  const setStatus = useDiscord((s) => s.setStatus);
  const me = useDiscord((s) => s.users[s.meId]);
  const [text, setText] = useState(me?.customStatus ?? "");
  const statuses: { id: Presence; label: ReturnType<typeof t> }[] = [
    { id: "online", label: t(lang, "onlineStatus") },
    { id: "idle", label: t(lang, "idle") },
    { id: "dnd", label: t(lang, "dnd") },
    { id: "invisible", label: t(lang, "invisible") },
  ];
  return (
    <Panel onClose={close} className="w-[320px] p-4">
      {statuses.map((s) => (
        <button
          key={s.id}
          type="button"
          className="flex w-full items-center gap-2 rounded-sm px-2 py-2 hover:bg-dc-hover"
          onClick={() => setStatus(s.id, text)}
        >
          <StatusDot status={s.id} ring={false} />
          {s.label}
        </button>
      ))}
      <input
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder={t(lang, "statusText")}
        className="mt-2 h-9 w-full rounded-sm bg-dc-server px-2 outline-none"
      />
      <button type="button" className="mt-2 h-9 w-full rounded-sm bg-dc-brand text-sm text-white" onClick={() => setStatus(me?.status ?? "online", text)}>
        {t(lang, "saveStatus")}
      </button>
    </Panel>
  );
}

function Shortcuts() {
  const lang = useDiscord((s) => s.settings.language);
  const close = useDiscord((s) => s.closeOverlay);
  return (
    <Panel onClose={close} className="w-[420px] p-5">
      <h2 className="text-xl font-bold">{t(lang, "shortcutHelp")}</h2>
      <ul className="mt-3 space-y-1 text-sm">
        <li>Ctrl+K — {t(lang, "quickSwitcher")}</li>
        <li>Ctrl+F — {t(lang, "search")}</li>
        <li>Ctrl+, — {t(lang, "userSettings")}</li>
        <li>Ctrl+Shift+M — {t(lang, "toggleMute")}</li>
        <li>Ctrl+I — {t(lang, "inbox")}</li>
      </ul>
    </Panel>
  );
}

function HelpModal() {
  const lang = useDiscord((s) => s.settings.language);
  const close = useDiscord((s) => s.closeOverlay);
  return (
    <Panel onClose={close} className="w-[400px] p-5">
      <h2 className="text-xl font-bold">{t(lang, "help")}</h2>
      <p className="mt-2 text-dc-muted">{t(lang, "aboutNexus")}</p>
      <p className="mt-1 text-sm text-dc-faint">{t(lang, "version")}</p>
    </Panel>
  );
}

function WhatsNew() {
  const close = useDiscord((s) => s.closeOverlay);
  return (
    <Panel onClose={close} className="w-[400px] p-5">
      <h2 className="text-xl font-bold">Nexus 2.0</h2>
      <ul className="mt-3 list-disc space-y-1 pl-5 text-sm">
        <li>Layout mobile e desktop</li>
        <li>Voz, vídeo e atividades</li>
        <li>Fóruns, palco e enquetes</li>
        <li>Nitro, loja e missões</li>
      </ul>
    </Panel>
  );
}

function Soundboard() {
  const close = useDiscord((s) => s.closeOverlay);
  return (
    <Panel onClose={close} className="w-[360px] p-4">
      <h2 className="mb-3 font-semibold">Soundboard</h2>
      <div className="grid grid-cols-4 gap-2">
        {soundboard.map((s) => (
          <button
            key={s.id}
            type="button"
            onClick={() => sfx.soundboard(s.id)}
            className="h-16 rounded-md text-xs font-medium text-white"
            style={{ background: s.color }}
          >
            {s.label}
          </button>
        ))}
      </div>
    </Panel>
  );
}

function Activities() {
  const close = useDiscord((s) => s.closeOverlay);
  const toast = useDiscord((s) => s.toast);
  return (
    <Panel onClose={close} className="w-[400px] p-4">
      <h2 className="mb-3 font-semibold">Atividades</h2>
      <div className="grid grid-cols-2 gap-2">
        {activities.map((a) => (
          <button
            key={a.id}
            type="button"
            className="h-16 rounded-md text-sm font-medium text-white"
            style={{ background: a.color }}
            onClick={() => {
              toast("Atividade", a.name + " iniciada");
              close();
            }}
          >
            {a.name}
          </button>
        ))}
      </div>
    </Panel>
  );
}

function NsfwGate() {
  const lang = useDiscord((s) => s.settings.language);
  const close = useDiscord((s) => s.closeOverlay);
  const chId = useDiscord((s) => s.activeChannelId);
  return (
    <Panel className="w-[400px] p-6 text-center">
      <h2 className="text-xl font-bold">{t(lang, "nsfwWarn")}</h2>
      <p className="mt-2 text-dc-muted">{t(lang, "nsfwBody")}</p>
      <div className="mt-4 flex justify-center gap-2">
        <button type="button" className="h-9 rounded-sm bg-dc-server px-4" onClick={close}>
          {t(lang, "goBack")}
        </button>
        <button
          type="button"
          className="h-9 rounded-sm bg-dc-brand px-4 text-white"
          onClick={() => {
            if (chId) useDiscord.setState({ nsfwAllowed: { ...useDiscord.getState().nsfwAllowed, [chId]: true } });
            close();
          }}
        >
          {t(lang, "continue")}
        </button>
      </div>
    </Panel>
  );
}

function ContextMenu() {
  const m = useDiscord((s) => s.contextMenu);
  const close = useDiscord((s) => s.setContextMenu);
  const lang = useDiscord((s) => s.settings.language);
  const del = useDiscord((s) => s.deleteMessage);
  const pin = useDiscord((s) => s.pinMessage);
  const setReply = useDiscord((s) => s.setReply);
  const setEditing = useDiscord((s) => s.setEditing);
  const messages = useDiscord((s) => s.messages);
  const openOverlay = useDiscord((s) => s.openOverlay);
  const openProfile = useDiscord((s) => s.openProfile);
  const setFriendStatus = useDiscord((s) => s.setFriendStatus);
  const leaveServer = useDiscord((s) => s.leaveServer);
  const closeDm = useDiscord((s) => s.closeDm);
  const toast = useDiscord((s) => s.toast);
  const meId = useDiscord((s) => s.meId);
  useEffect(() => {
    const on = () => close(null);
    window.addEventListener("click", on);
    return () => window.removeEventListener("click", on);
  }, [close]);
  if (!m) return null;
  const items: { label: string; action: () => void; danger?: boolean }[] = [];
  if (m.kind === "message" && m.extra) {
    const msg = (messages[m.extra] ?? []).find((x) => x.id === m.id);
    items.push(
      { label: t(lang, "reply"), action: () => msg && setReply(msg) },
      { label: t(lang, "addReaction"), action: () => openOverlay("emoji") },
      { label: t(lang, "pin"), action: () => pin(m.extra!, m.id) },
      { label: t(lang, "copy"), action: () => { void navigator.clipboard?.writeText(msg?.content ?? ""); toast(t(lang, "copied")); } },
      { label: t(lang, "copyLink"), action: () => toast(t(lang, "copied")) },
      { label: t(lang, "markUnread"), action: () => toast(t(lang, "unread")) },
    );
    if (msg?.authorId === meId) {
      items.push(
        { label: t(lang, "edit"), action: () => { setEditing(m.id); useDiscord.setState({ composer: msg.content }); } },
        { label: t(lang, "delete"), action: () => del(m.extra!, m.id), danger: true },
      );
    }
  }
  if (m.kind === "user") {
    items.push(
      { label: t(lang, "viewProfile"), action: () => openProfile(m.id) },
      { label: t(lang, "messageUser"), action: () => openProfile(m.id) },
      { label: t(lang, "mention"), action: () => useDiscord.setState({ composer: useDiscord.getState().composer + `@${m.id} ` }) },
      { label: t(lang, "block"), action: () => setFriendStatus(m.id, "blocked"), danger: true },
    );
  }
  if (m.kind === "server") {
    items.push(
      { label: t(lang, "markServerRead"), action: () => useDiscord.getState().markRead(m.id) },
      { label: t(lang, "invite"), action: () => openOverlay("invite") },
      { label: t(lang, "serverSettings"), action: () => openOverlay("server-settings") },
      { label: t(lang, "leaveServer"), action: () => leaveServer(m.id), danger: true },
    );
  }
  if (m.kind === "channel") {
    items.push(
      { label: t(lang, "markAsRead"), action: () => useDiscord.getState().markRead(m.id) },
      { label: t(lang, "inviteToChannel"), action: () => openOverlay("invite") },
      { label: t(lang, "muteChannel"), action: () => useDiscord.getState().toggleMuteChannel(m.id) },
      { label: t(lang, "editChannel"), action: () => openOverlay("create-channel") },
      { label: t(lang, "copyId"), action: () => { void navigator.clipboard?.writeText(m.id); toast(t(lang, "copied")); } },
    );
  }
  if (m.kind === "dm") {
    items.push(
      { label: t(lang, "closeDm"), action: () => closeDm(m.id), danger: true },
      { label: t(lang, "markAsRead"), action: () => useDiscord.getState().markRead(m.id) },
    );
  }
  const maxY = typeof window !== "undefined" ? window.innerHeight - 8 : 800;
  const top = Math.min(m.y, maxY - items.length * 32);
  return (
    <div
      className="fixed z-[70] w-56 rounded-md bg-dc-elevated p-1.5 shadow-[var(--shadow-float)]"
      style={{ left: Math.min(m.x, (typeof window !== "undefined" ? window.innerWidth : 800) - 230), top }}
    >
      {items.map((it) => (
        <button
          key={it.label}
          type="button"
          className={cn(
            "flex h-8 w-full items-center rounded-sm px-2 text-sm",
            it.danger ? "text-dc-red hover:bg-dc-red hover:text-white" : "hover:bg-dc-brand hover:text-white",
          )}
          onClick={(e) => {
            e.stopPropagation();
            it.action();
            close(null);
          }}
        >
          {it.label}
        </button>
      ))}
    </div>
  );
}

function UserStatusMenu() {
  const lang = useDiscord((s) => s.settings.language);
  const setUserMenu = useDiscord((s) => s.setUserMenu);
  const setStatus = useDiscord((s) => s.setStatus);
  const openOverlay = useDiscord((s) => s.openOverlay);
  const me = useDiscord((s) => s.users[s.meId]);
  useEffect(() => {
    const on = () => setUserMenu(false);
    window.addEventListener("click", on);
    return () => window.removeEventListener("click", on);
  }, [setUserMenu]);
  return (
    <div className="fixed bottom-16 left-[80px] z-40 w-56 rounded-md bg-dc-elevated p-1.5 shadow-[var(--shadow-float)] md:left-[80px]">
      {(["online", "idle", "dnd", "invisible"] as Presence[]).map((st) => (
        <button
          key={st}
          type="button"
          className="flex h-8 w-full items-center gap-2 rounded-sm px-2 text-sm hover:bg-dc-brand hover:text-white"
          onClick={(e) => {
            e.stopPropagation();
            setStatus(st);
          }}
        >
          <StatusDot status={st} ring={false} />
          {st === "online" ? t(lang, "onlineStatus") : st === "idle" ? t(lang, "idle") : st === "dnd" ? t(lang, "dnd") : t(lang, "invisible")}
        </button>
      ))}
      <button
        type="button"
        className="flex h-8 w-full items-center rounded-sm px-2 text-sm hover:bg-dc-hover"
        onClick={(e) => {
          e.stopPropagation();
          openOverlay("status");
        }}
      >
        {t(lang, "customStatus")}
      </button>
      <button
        type="button"
        className="flex h-8 w-full items-center rounded-sm px-2 text-sm hover:bg-dc-hover"
        onClick={(e) => {
          e.stopPropagation();
          openOverlay("settings");
        }}
      >
        {t(lang, "userSettings")}
      </button>
    </div>
  );
}

function CallOverlay() {
  const call = useDiscord((s) => s.call);
  const end = useDiscord((s) => s.endCall);
  const dms = useDiscord((s) => s.dms);
  const users = useDiscord((s) => s.users);
  const meId = useDiscord((s) => s.meId);
  const lang = useDiscord((s) => s.settings.language);
  const voice = useDiscord((s) => s.voice);
  const patchVoice = useDiscord((s) => s.patchVoice);
  const openOverlay = useDiscord((s) => s.openOverlay);
  if (!call) return null;
  const dm = dms.find((d) => d.id === call.dmId);
  const other = dm ? users[dm.userIds.find((id) => id !== meId) ?? ""] : undefined;
  return (
    <div className="fixed inset-0 z-[60] flex flex-col bg-[#0c0d12] animate-dc-fade">
      <div className="flex flex-1 flex-col items-center justify-center gap-4">
        <UserAvatar avatar={other?.avatar ?? "wumpus"} size={96} />
        <h2 className="text-2xl font-bold text-dc-heading">{other?.displayName}</h2>
        <p className="text-dc-muted">{call.ringing ? t(lang, "ringing") : t(lang, "inCall")}</p>
        {call.video && (
          <div className="grid h-48 w-80 place-items-center rounded-lg bg-dc-server text-dc-muted">Câmera</div>
        )}
      </div>
      <div className="flex items-center justify-center gap-3 pb-10">
        <Round
          label={t(lang, "mute")}
          onClick={() => patchVoice({ muted: !voice?.muted })}
          active={voice?.muted}
        >
          {voice?.muted ? <MicOff /> : <Mic />}
        </Round>
        <Round label={t(lang, "video")} onClick={() => {}}>
          <Video />
        </Round>
        <Round label={t(lang, "screen")} onClick={() => patchVoice({ streaming: !voice?.streaming })}>
          <Monitor />
        </Round>
        <Round label="Soundboard" onClick={() => openOverlay("soundboard")}>
          <Smile />
        </Round>
        <Round label={t(lang, "endCall")} danger onClick={end}>
          <PhoneOff />
        </Round>
      </div>
    </div>
  );
}

function Round({
  children,
  onClick,
  danger,
  active,
  label,
}: {
  children: React.ReactNode;
  onClick: () => void;
  danger?: boolean;
  active?: boolean;
  label: string;
}) {
  return (
    <button
      type="button"
      title={label}
      aria-label={label}
      onClick={onClick}
      className={cn(
        "grid size-14 place-items-center rounded-full",
        danger ? "bg-dc-red text-white" : active ? "bg-dc-heading text-dc-server" : "bg-dc-mod text-dc-heading",
      )}
    >
      {children}
    </button>
  );
}

function ToastStack({ toasts }: { toasts: { id: string; title: string; body?: string; tone?: string }[] }) {
  return (
    <div className="pointer-events-none fixed right-4 bottom-20 z-[80] flex flex-col gap-2">
      {toasts.map((t) => (
        <div key={t.id} className="pointer-events-auto min-w-48 rounded-md bg-dc-elevated px-3 py-2 shadow-[var(--shadow-pop)] animate-dc-slide">
          <div className="text-sm font-semibold text-dc-heading">{t.title}</div>
          {t.body && <div className="text-xs text-dc-muted">{t.body}</div>}
        </div>
      ))}
    </div>
  );
}
