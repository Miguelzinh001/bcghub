import type { ReactNode } from "react";
import { AvatarArt } from "@/lib/discord/avatars";
import type { Presence } from "@/lib/discord/types";
import { cn } from "@/lib/utils";

export function StatusDot({
  status,
  size = 10,
  ring = true,
}: {
  status: Presence;
  size?: number;
  ring?: boolean;
}) {
  const color =
    status === "online"
      ? "bg-dc-online"
      : status === "idle"
        ? "bg-dc-idle"
        : status === "dnd"
          ? "bg-dc-dnd"
          : "bg-dc-offline";
  return (
    <span
      className={cn("relative grid place-items-center rounded-full", ring && "bg-dc-sidebar")}
      style={{ width: size + (ring ? 6 : 0), height: size + (ring ? 6 : 0) }}
    >
      {status === "idle" ? (
        <span className="relative block rounded-full bg-dc-idle" style={{ width: size, height: size }}>
          <span
            className="absolute rounded-full bg-dc-sidebar"
            style={{ width: size * 0.55, height: size * 0.55, top: 1, left: 1 }}
          />
        </span>
      ) : status === "dnd" ? (
        <span className="relative grid place-items-center rounded-full bg-dc-dnd" style={{ width: size, height: size }}>
          <span className="block rounded-sm bg-dc-sidebar" style={{ width: size * 0.55, height: 2 }} />
        </span>
      ) : status === "offline" || status === "invisible" ? (
        <span
          className="grid place-items-center rounded-full bg-dc-offline"
          style={{ width: size, height: size }}
        >
          <span className="block rounded-full bg-dc-sidebar" style={{ width: size * 0.4, height: size * 0.4 }} />
        </span>
      ) : (
        <span className={cn("block rounded-full", color)} style={{ width: size, height: size }} />
      )}
    </span>
  );
}

export function UserAvatar({
  avatar,
  status,
  size = 40,
  className,
}: {
  avatar: string;
  status?: Presence;
  size?: number;
  className?: string;
}) {
  const ring = Math.max(8, Math.round(size * 0.28));
  return (
    <div className={cn("relative shrink-0", className)} style={{ width: size, height: size }}>
      <div className="overflow-hidden rounded-full size-full">
        <AvatarArt id={avatar} size={size} />
      </div>
      {status && (
        <span className="absolute -right-0.5 -bottom-0.5">
          <StatusDot status={status} size={ring} />
        </span>
      )}
    </div>
  );
}

export function ServerIcon({
  avatar,
  size = 48,
  active,
  unread,
  mentions,
  label,
  onClick,
  onContextMenu,
}: {
  avatar: string;
  size?: number;
  active?: boolean;
  unread?: boolean;
  mentions?: number;
  label: string;
  onClick?: () => void;
  onContextMenu?: (e: React.MouseEvent) => void;
}) {
  return (
    <button
      type="button"
      title={label}
      aria-label={label}
      onClick={onClick}
      onContextMenu={onContextMenu}
      className="group relative grid size-12 place-items-center"
    >
      <span
        className={cn(
          "absolute left-0 w-1 rounded-r-full bg-dc-heading transition-all duration-150",
          active ? "h-10" : unread ? "h-2 group-hover:h-5" : "h-0 group-hover:h-5",
        )}
      />
      <span
        className={cn(
          "overflow-hidden transition-[border-radius] duration-150",
          active ? "rounded-2xl" : "rounded-[22px] group-hover:rounded-2xl",
        )}
        style={{ width: size, height: size }}
      >
        <AvatarArt id={avatar} size={size} />
      </span>
      {!!mentions && mentions > 0 && (
        <span className="absolute -right-0.5 -bottom-0.5 min-w-4 rounded-full bg-dc-red px-1 text-center text-[10px] font-bold leading-4 text-dc-white outline outline-3 outline-dc-server">
          {mentions > 99 ? "99+" : mentions}
        </span>
      )}
    </button>
  );
}

export function Pill({
  children,
  tone = "bot",
}: {
  children: ReactNode;
  tone?: "bot" | "official" | "nitro";
}) {
  const cls =
    tone === "official"
      ? "bg-dc-brand text-dc-white"
      : tone === "nitro"
        ? "bg-dc-nitro text-dc-white"
        : "bg-dc-brand text-dc-white";
  return (
    <span className={cn("ml-1 inline-flex items-center rounded-[3px] px-1 text-[10px] font-bold uppercase leading-[15px]", cls)}>
      {children}
    </span>
  );
}

export function IconBtn({
  label,
  onClick,
  children,
  active,
  danger,
  className,
}: {
  label: string;
  onClick?: (e: React.MouseEvent) => void;
  children: ReactNode;
  active?: boolean;
  danger?: boolean;
  className?: string;
}) {
  return (
    <button
      type="button"
      title={label}
      aria-label={label}
      onClick={onClick}
      className={cn(
        "grid size-8 place-items-center rounded-sm text-dc-muted transition-colors duration-150 hover:text-dc-heading",
        active && "text-dc-heading",
        danger && "hover:text-dc-red",
        className,
      )}
    >
      {children}
    </button>
  );
}

export function Panel({
  children,
  className,
  onClose,
}: {
  children: ReactNode;
  className?: string;
  onClose?: () => void;
}) {
  return (
    <div
      className="fixed inset-0 z-50 grid place-items-center bg-black/70 p-3 animate-dc-fade"
      onClick={onClose}
    >
      <div
        className={cn("max-h-[90dvh] overflow-hidden rounded-lg bg-dc-chat shadow-[var(--shadow-pop)] animate-dc-scale", className)}
        onClick={(e) => e.stopPropagation()}
      >
        {children}
      </div>
    </div>
  );
}
