import { useDiscord } from "@/lib/discord/store";
import { t, type I18nKey } from "@/lib/discord/i18n";
import { UserAvatar } from "./primitives";
import { cn } from "@/lib/utils";
import type { Settings as SettingsT } from "@/lib/discord/types";

const userNav: { id: string; label: I18nKey; group?: string }[] = [
  { id: "myAccount", label: "myAccount", group: "user" },
  { id: "profile", label: "profile" },
  { id: "privacy", label: "privacy" },
  { id: "sessions", label: "sessions" },
  { id: "connections", label: "connections" },
  { id: "authorized", label: "authorized" },
  { id: "familyCenter", label: "familyCenter" },
  { id: "nitro", label: "nitro", group: "pay" },
  { id: "billing", label: "billing" },
  { id: "giftInventory", label: "giftInventory" },
  { id: "appearance", label: "appearance", group: "app" },
  { id: "accessibility", label: "accessibility" },
  { id: "voiceVideo", label: "voiceVideo" },
  { id: "chat", label: "chat" },
  { id: "notifications", label: "notifications" },
  { id: "keybinds", label: "keybinds" },
  { id: "language", label: "language" },
  { id: "streamer", label: "streamer" },
  { id: "advanced", label: "advanced" },
  { id: "activity", label: "activity", group: "act" },
  { id: "games", label: "games" },
  { id: "overlay", label: "overlay" },
  { id: "whats-new", label: "whatsNew", group: "info" },
  { id: "about", label: "about" },
];

const serverNav: { id: string; label: I18nKey }[] = [
  { id: "overview", label: "overview" },
  { id: "roles", label: "roles" },
  { id: "emojis", label: "emojis" },
  { id: "stickers", label: "stickers" },
  { id: "moderation", label: "moderation" },
  { id: "audit", label: "audit" },
  { id: "safety", label: "safety" },
  { id: "automod", label: "automod" },
  { id: "membersTab", label: "membersTab" },
  { id: "invites", label: "invites" },
  { id: "bans", label: "bans" },
  { id: "community", label: "community" },
  { id: "onboarding", label: "onboarding" },
  { id: "insights", label: "insights" },
  { id: "integrations", label: "integrations" },
  { id: "webhooks", label: "webhooks" },
];

export function SettingsModal({ kind }: { kind: "user" | "server" }) {
  const lang = useDiscord((s) => s.settings.language);
  const close = useDiscord((s) => s.closeOverlay);
  const section = useDiscord((s) => (kind === "user" ? s.settingsSection : s.serverSettingsSection));
  const setSection = useDiscord((s) =>
    kind === "user" ? s.setSettingsSection : s.setServerSettingsSection,
  );
  const nav = kind === "user" ? userNav : serverNav;
  const logout = useDiscord((s) => s.logout);
  const reset = useDiscord((s) => s.reset);

  return (
    <div className="fixed inset-0 z-50 flex bg-dc-sidebar animate-dc-fade">
      <aside className="flex w-[218px] shrink-0 flex-col items-end overflow-y-auto bg-dc-sidebar py-8 pr-2 dc-scroll">
        <div className="w-[172px]">
          {nav.map((n, i) => (
            <div key={n.id}>
              {"group" in n && n.group && i > 0 && <div className="my-2 h-px bg-dc-divider" />}
              <button
                type="button"
                onClick={() => setSection(n.id)}
                className={cn(
                  "mb-0.5 flex h-8 w-full items-center rounded-sm px-2.5 text-left text-base",
                  section === n.id ? "bg-dc-active text-dc-heading" : "text-dc-muted hover:bg-dc-hover hover:text-dc-heading",
                )}
              >
                {t(lang, n.label)}
              </button>
            </div>
          ))}
          {kind === "user" && (
            <>
              <div className="my-2 h-px bg-dc-divider" />
              <button
                type="button"
                onClick={() => logout()}
                className="flex h-8 w-full items-center rounded-sm px-2.5 text-left text-base text-dc-red hover:bg-dc-hover"
              >
                {t(lang, "logOut")}
              </button>
              <button
                type="button"
                onClick={() => reset()}
                className="flex h-8 w-full items-center rounded-sm px-2.5 text-left text-sm text-dc-muted hover:bg-dc-hover"
              >
                {t(lang, "reset")}
              </button>
            </>
          )}
        </div>
      </aside>
      <div className="flex min-w-0 flex-1 flex-col bg-dc-chat">
        <div className="flex justify-end p-4">
          <button
            type="button"
            onClick={close}
            className="grid size-9 place-items-center rounded-full border border-dc-muted text-dc-muted hover:text-dc-heading"
            aria-label={t(lang, "esc")}
          >
            ×
          </button>
        </div>
        <div className="flex-1 overflow-y-auto dc-scroll px-6 pb-16 md:px-16">
          <div className="max-w-xl">
            {kind === "user" ? <UserSection id={section} /> : <ServerSection id={section} />}
          </div>
        </div>
      </div>
    </div>
  );
}

function H({ children }: { children: string }) {
  return <h2 className="mb-5 text-xl font-semibold text-dc-heading">{children}</h2>;
}
function Label({ children }: { children: string }) {
  return <div className="mb-1 mt-5 text-xs font-bold uppercase tracking-wide text-dc-muted">{children}</div>;
}
function Toggle({
  on,
  set,
  label,
}: {
  on: boolean;
  set: (v: boolean) => void;
  label: string;
}) {
  return (
    <button type="button" onClick={() => set(!on)} className="flex w-full items-center justify-between py-2">
      <span className="text-dc-heading">{label}</span>
      <span className={cn("relative h-6 w-10 rounded-full", on ? "bg-dc-green" : "bg-dc-mod")}>
        <span className={cn("absolute top-0.5 size-5 rounded-full bg-dc-white transition-transform", on ? "translate-x-4" : "translate-x-0.5")} />
      </span>
    </button>
  );
}
function Slider({
  value,
  set,
  label,
}: {
  value: number;
  set: (n: number) => void;
  label: string;
}) {
  return (
    <label className="mt-3 block">
      <div className="mb-1 flex justify-between text-sm text-dc-heading">
        {label}
        <span className="tabular-nums text-dc-muted">{value}%</span>
      </div>
      <input
        type="range"
        min={0}
        max={100}
        value={value}
        onChange={(e) => set(Number(e.target.value))}
        className="w-full accent-[#5865f2]"
      />
    </label>
  );
}

function UserSection({ id }: { id: string }) {
  const s = useDiscord((s) => s.settings);
  const patch = useDiscord((s) => s.patchSettings);
  const me = useDiscord((s) => s.users[s.meId]);
  const updateMe = useDiscord((s) => s.updateMe);
  const lang = s.language;
  const openOverlay = useDiscord((s) => s.openOverlay);

  if (id === "myAccount" && me) {
    return (
      <>
        <H>{t(lang, "myAccount")}</H>
        <div className="overflow-hidden rounded-lg bg-dc-sidebar">
          <div className="h-20" style={{ background: me.bannerColor ?? me.accent }} />
          <div className="flex items-end gap-3 px-4 pb-4">
            <div className="-mt-8">
              <UserAvatar avatar={me.avatar} status={me.status} size={80} />
            </div>
            <div className="min-w-0 flex-1 pt-6">
              <div className="text-xl font-bold text-dc-heading">{me.displayName}</div>
              <div className="text-sm text-dc-muted">{me.username}</div>
            </div>
            <button
              type="button"
              className="h-8 rounded-sm bg-dc-brand px-3 text-sm text-dc-white"
              onClick={() => openOverlay("user-profile")}
            >
              {t(lang, "editUser")}
            </button>
          </div>
          <div className="space-y-3 p-4">
            <Field label={t(lang, "displayName")} value={me.displayName} onSave={(v) => updateMe({ displayName: v })} />
            <Field label={t(lang, "usernameField")} value={me.username} onSave={(v) => updateMe({ username: v })} />
            <Field label={t(lang, "emailLabel")} value="t•••••@nexus.gg" />
            <Field label={t(lang, "phone")} value="+55 ••••••09" />
          </div>
        </div>
        <Label>{t(lang, "twoFa")}</Label>
        <p className="text-sm text-dc-muted">{t(lang, "twoFaHint")}</p>
        <button type="button" className="mt-2 h-8 rounded-sm bg-dc-brand px-3 text-sm text-dc-white">
          {t(lang, "enable")}
        </button>
      </>
    );
  }
  if (id === "appearance") {
    return (
      <>
        <H>{t(lang, "appearance")}</H>
        <Label>{t(lang, "theme")}</Label>
        <div className="flex gap-2">
          {(["dark", "light", "sync"] as const).map((th) => (
            <button
              key={th}
              type="button"
              onClick={() => patch({ theme: th })}
              className={cn("h-9 rounded-sm px-3 text-sm", s.theme === th ? "bg-dc-brand text-dc-white" : "bg-dc-server text-dc-heading")}
            >
              {th === "dark" ? t(lang, "dark") : th === "light" ? t(lang, "light") : t(lang, "sync")}
            </button>
          ))}
        </div>
        <Label>{t(lang, "messageDisplay")}</Label>
        <div className="flex gap-2">
          {(["cozy", "compact"] as const).map((m) => (
            <button
              key={m}
              type="button"
              onClick={() => patch({ messageDisplay: m })}
              className={cn("h-9 rounded-sm px-3 text-sm", s.messageDisplay === m ? "bg-dc-brand text-dc-white" : "bg-dc-server")}
            >
              {m === "cozy" ? t(lang, "cozy") : t(lang, "compact")}
            </button>
          ))}
        </div>
        <Slider value={Math.round(((s.fontScale - 12) / 12) * 100)} set={(n) => patch({ fontScale: 12 + (n / 100) * 12 })} label={t(lang, "fontScale")} />
        <Toggle on={s.showAvatars} set={(v) => patch({ showAvatars: v })} label={t(lang, "showAvatars")} />
        <div className="mt-4 rounded-md bg-dc-sidebar p-3 text-sm text-dc-text">{t(lang, "chatExample")}</div>
      </>
    );
  }
  if (id === "voiceVideo") {
    return (
      <>
        <H>{t(lang, "voiceVideo")}</H>
        <Slider value={s.inputVolume} set={(n) => patch({ inputVolume: n })} label={t(lang, "input")} />
        <Slider value={s.outputVolume} set={(n) => patch({ outputVolume: n })} label={t(lang, "output")} />
        <Toggle on={s.echoCancel} set={(v) => patch({ echoCancel: v })} label={t(lang, "echo")} />
        <Toggle on={s.noiseSuppression} set={(v) => patch({ noiseSuppression: v })} label={t(lang, "noise")} />
        <Toggle on={s.autoGain} set={(v) => patch({ autoGain: v })} label={t(lang, "agc")} />
      </>
    );
  }
  if (id === "notifications") {
    return (
      <>
        <H>{t(lang, "notifications")}</H>
        <Toggle on={s.notifications} set={(v) => patch({ notifications: v })} label={t(lang, "notifications")} />
        <Toggle on={s.dndSuppress} set={(v) => patch({ dndSuppress: v })} label={t(lang, "suppressEveryone")} />
        <Toggle on={s.useUnreadBadge} set={(v) => patch({ useUnreadBadge: v })} label={t(lang, "unreadBadge")} />
      </>
    );
  }
  if (id === "chat") {
    return (
      <>
        <H>{t(lang, "chat")}</H>
        <Toggle on={s.animateEmoji} set={(v) => patch({ animateEmoji: v })} label={t(lang, "animateEmoji")} />
        <Toggle on={s.gifAutoplay} set={(v) => patch({ gifAutoplay: v })} label={t(lang, "autoplayGif")} />
        <Toggle on={s.linkPreview} set={(v) => patch({ linkPreview: v })} label={t(lang, "linkPreview")} />
        <Toggle on={s.tts} set={(v) => patch({ tts: v })} label={t(lang, "ttsLabel")} />
      </>
    );
  }
  if (id === "accessibility") {
    return (
      <>
        <H>{t(lang, "accessibility")}</H>
        <Toggle on={s.reduceMotion} set={(v) => patch({ reduceMotion: v })} label={t(lang, "reduceMotion")} />
      </>
    );
  }
  if (id === "language") {
    return (
      <>
        <H>{t(lang, "language")}</H>
        <button type="button" onClick={() => patch({ language: "pt" })} className={cn("mb-1 flex h-10 w-full items-center rounded-sm px-3", lang === "pt" ? "bg-dc-active" : "hover:bg-dc-hover")}>
          {t(lang, "portuguese")}
        </button>
        <button type="button" onClick={() => patch({ language: "en" })} className={cn("flex h-10 w-full items-center rounded-sm px-3", lang === "en" ? "bg-dc-active" : "hover:bg-dc-hover")}>
          {t(lang, "english")}
        </button>
      </>
    );
  }
  if (id === "keybinds") {
    const binds = [
      ["Ctrl+K", t(lang, "quickSwitcher")],
      ["Ctrl+F", t(lang, "searchMessages")],
      ["Ctrl+Shift+M", t(lang, "toggleMute")],
      ["Ctrl+Shift+D", t(lang, "toggleDeafen")],
      ["Ctrl+Shift+A", t(lang, "toggleMemberList")],
      ["Ctrl+P", t(lang, "pins")],
      ["Ctrl+,", t(lang, "userSettings")],
      ["Esc", t(lang, "escape")],
    ];
    return (
      <>
        <H>{t(lang, "keybinds")}</H>
        {binds.map(([k, l]) => (
          <div key={k} className="flex items-center justify-between border-b border-dc-divider py-2 text-sm">
            <span>{l}</span>
            <kbd className="rounded-sm bg-dc-server px-2 py-0.5 font-mono text-dc-heading">{k}</kbd>
          </div>
        ))}
      </>
    );
  }
  if (id === "nitro") {
    return (
      <>
        <H>{t(lang, "nitro")}</H>
        <p className="text-dc-muted">{t(lang, "nitroSub")}</p>
        <div className="mt-4 grid gap-3 md:grid-cols-2">
          <Plan name="Nitro Basic" price="R$ 9,99" perks={["64 MB uploads", "Emoji custom", "Tela de fundo"]} />
          <Plan name="Nitro" price="R$ 26,90" perks={["500 MB uploads", "HD video", "2 boosts", "Perfil animado"]} />
        </div>
      </>
    );
  }
  if (id === "connections") {
    const apps = ["spotifyConn", "steam", "github", "twitch", "xbox", "playstation", "riot", "battleNet"] as I18nKey[];
    return (
      <>
        <H>{t(lang, "connections")}</H>
        <div className="grid gap-2">
          {apps.map((a) => (
            <div key={a} className="flex items-center justify-between rounded-md bg-dc-sidebar px-3 py-2">
              <span>{t(lang, a)}</span>
              <button type="button" className="h-8 rounded-sm bg-dc-brand px-3 text-sm text-dc-white">
                {t(lang, "connect")}
              </button>
            </div>
          ))}
        </div>
      </>
    );
  }
  if (id === "privacy") {
    return (
      <>
        <H>{t(lang, "privacy")}</H>
        <Toggle on={s.allowDMs} set={(v) => patch({ allowDMs: v })} label={t(lang, "allowDms")} />
        <Toggle on={s.allowFriendRequests} set={(v) => patch({ allowFriendRequests: v })} label={t(lang, "allowFr")} />
        <Toggle on={s.showCurrentGame} set={(v) => patch({ showCurrentGame: v })} label={t(lang, "showGame")} />
      </>
    );
  }
  if (id === "streamer") {
    return (
      <>
        <H>{t(lang, "streamer")}</H>
        <Toggle on={s.streamerMode} set={(v) => patch({ streamerMode: v })} label={t(lang, "streamer")} />
        <p className="mt-2 text-sm text-dc-muted">Oculta dados pessoais, convites e janelas sensíveis.</p>
      </>
    );
  }
  if (id === "advanced") {
    return (
      <>
        <H>{t(lang, "advanced")}</H>
        <Toggle on={s.developerMode} set={(v) => patch({ developerMode: v })} label={t(lang, "developerMode")} />
        <Toggle on={s.hardwareAccel} set={(v) => patch({ hardwareAccel: v })} label="Hardware acceleration" />
      </>
    );
  }
  if (id === "about" || id === "whats-new") {
    return (
      <>
        <H>{t(lang, "aboutNexus")}</H>
        <p className="text-dc-muted">{t(lang, "version")} · {t(lang, "stable")}</p>
        <ul className="mt-4 list-disc space-y-1 pl-5 text-sm text-dc-text">
          <li>Layout mobile fiel ao app original</li>
          <li>Voz, palco, fóruns, enquetes e tópicos</li>
          <li>Nitro, loja, missões e atividades</li>
          <li>Atalhos Ctrl+K, Ctrl+F, Ctrl+,</li>
        </ul>
      </>
    );
  }
  if (id === "profile" && me) {
    return (
      <>
        <H>{t(lang, "profile")}</H>
        <Label>{t(lang, "displayName")}</Label>
        <input
          defaultValue={me.displayName}
          onBlur={(e) => updateMe({ displayName: e.target.value })}
          className="h-10 w-full rounded-sm bg-dc-server px-3 outline-none"
        />
        <Label>Bio</Label>
        <textarea
          defaultValue={me.bio}
          onBlur={(e) => updateMe({ bio: e.target.value })}
          className="h-24 w-full rounded-sm bg-dc-server p-2 outline-none"
        />
        <Label>Pronomes</Label>
        <input
          defaultValue={me.pronouns}
          onBlur={(e) => updateMe({ pronouns: e.target.value })}
          className="h-10 w-full rounded-sm bg-dc-server px-3 outline-none"
        />
      </>
    );
  }
  if (id === "sessions") {
    return (
      <>
        <H>{t(lang, "sessions")}</H>
        <p className="text-sm text-dc-muted">{t(lang, "sessionsHint")}</p>
        <div className="mt-3 rounded-md bg-dc-sidebar p-3">
          <div className="font-medium text-dc-heading">{t(lang, "thisDevice")}</div>
          <div className="text-sm text-dc-muted">Nexus Desktop · Linux · agora</div>
        </div>
      </>
    );
  }
  if (id === "billing") {
    return (
      <>
        <H>{t(lang, "billing")}</H>
        <p className="text-dc-muted">{t(lang, "currentPlan")}: {t(lang, "free")}</p>
        <button type="button" onClick={() => openOverlay("nitro")} className="mt-3 h-9 rounded-sm bg-dc-brand px-3 text-sm text-dc-white">
          {t(lang, "subscribe")}
        </button>
      </>
    );
  }
  return (
    <>
      <H>{id}</H>
      <p className="text-dc-muted">{t(lang, "coming")}</p>
    </>
  );
}

function Field({ label, value, onSave }: { label: string; value: string; onSave?: (v: string) => void }) {
  const lang = useDiscord((s) => s.settings.language);
  return (
    <div className="flex items-center justify-between">
      <div>
        <div className="text-[11px] font-bold uppercase text-dc-muted">{label}</div>
        <div className="text-dc-heading">{value}</div>
      </div>
      {onSave && (
        <button type="button" className="h-8 rounded-sm bg-dc-mod px-3 text-sm" onClick={() => {
          const v = prompt(label, value);
          if (v) onSave(v);
        }}>
          {t(lang, "editUser")}
        </button>
      )}
    </div>
  );
}

function Plan({ name, price, perks }: { name: string; price: string; perks: string[] }) {
  const lang = useDiscord((s) => s.settings.language);
  return (
    <div className="rounded-lg bg-dc-sidebar p-4">
      <div className="text-lg font-bold text-dc-heading">{name}</div>
      <div className="text-dc-muted">
        {price}
        {t(lang, "month")}
      </div>
      <ul className="mt-2 space-y-1 text-sm">
        {perks.map((p) => (
          <li key={p}>✓ {p}</li>
        ))}
      </ul>
      <button type="button" className="mt-3 h-9 w-full rounded-sm bg-dc-brand text-sm text-dc-white">
        {t(lang, "subscribe")}
      </button>
    </div>
  );
}

function ServerSection({ id }: { id: string }) {
  const lang = useDiscord((s) => s.settings.language);
  const server = useDiscord((s) => s.servers.find((x) => x.id === s.activeServerId) ?? s.servers[0]);
  const rename = useDiscord((s) => s.renameServer);
  if (!server) return null;
  if (id === "overview") {
    return (
      <>
        <H>{t(lang, "overview")}</H>
        <Label>{t(lang, "serverName")}</Label>
        <input
          defaultValue={server.name}
          onBlur={(e) => rename(server.id, e.target.value)}
          className="h-10 w-full rounded-sm bg-dc-server px-3 outline-none"
        />
        <p className="mt-3 text-sm text-dc-muted">
          {server.memberCount.toLocaleString()} membros · {server.boosts} boosts
        </p>
      </>
    );
  }
  if (id === "roles") {
    return (
      <>
        <H>{t(lang, "roles")}</H>
        {server.roles.map((r) => (
          <div key={r.id} className="flex items-center gap-2 py-2">
            <span className="size-3 rounded-full" style={{ background: r.color }} />
            <span>{r.name}</span>
          </div>
        ))}
      </>
    );
  }
  if (id === "membersTab") {
    return (
      <>
        <H>{t(lang, "membersTab")}</H>
        <p className="text-dc-muted">{server.memberCount.toLocaleString()} {t(lang, "members").toLowerCase()}</p>
      </>
    );
  }
  if (id === "emojis") {
    return (
      <>
        <H>{t(lang, "emojis")}</H>
        <div className="flex gap-2">
          {server.emojis.length === 0 && <p className="text-dc-muted">Nenhum emoji custom.</p>}
          {server.emojis.map((e) => (
            <span key={e.id} className="rounded-sm bg-dc-server px-2 py-1 text-sm">
              :{e.name}:
            </span>
          ))}
        </div>
      </>
    );
  }
  return (
    <>
      <H>{t(lang, (serverNav.find((n) => n.id === id)?.label as I18nKey) ?? "overview")}</H>
      <p className="text-dc-muted">{t(lang, "coming")}</p>
    </>
  );
}

export type { SettingsT };
