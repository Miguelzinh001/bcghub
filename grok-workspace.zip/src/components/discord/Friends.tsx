import { useState } from "react";
import { UserPlus, MoreHorizontal, Phone, MessageCircle, Check, X } from "lucide-react";
import { useDiscord } from "@/lib/discord/store";
import { t } from "@/lib/discord/i18n";
import { UserAvatar, Pill } from "./primitives";
import { cn } from "@/lib/utils";

const tabs = ["online", "all", "pending", "blocked", "add"] as const;

export function FriendsView() {
  const lang = useDiscord((s) => s.settings.language);
  const tab = useDiscord((s) => s.friendsTab);
  const setTab = useDiscord((s) => s.setFriendsTab);
  const friends = useDiscord((s) => s.friends);
  const users = useDiscord((s) => s.users);
  const dms = useDiscord((s) => s.dms);
  const setActiveDm = useDiscord((s) => s.setActiveDm);
  const setFriendStatus = useDiscord((s) => s.setFriendStatus);
  const addFriend = useDiscord((s) => s.addFriend);
  const startCall = useDiscord((s) => s.startCall);
  const openProfile = useDiscord((s) => s.openProfile);
  const [uname, setUname] = useState("");
  const [q, setQ] = useState("");

  const list = friends
    .map((f) => ({ ...f, user: users[f.userId] }))
    .filter((f) => f.user)
    .filter((f) => {
      if (tab === "online") return f.status === "friends" && f.user.status === "online";
      if (tab === "all") return f.status === "friends";
      if (tab === "pending") return f.status === "pending_in" || f.status === "pending_out";
      if (tab === "blocked") return f.status === "blocked" || f.status === "ignored";
      return false;
    })
    .filter((f) => f.user.displayName.toLowerCase().includes(q.toLowerCase()));

  function openDm(userId: string) {
    const dm = dms.find((d) => !d.group && d.userIds.includes(userId));
    if (dm) setActiveDm(dm.id);
    else {
      setFriendStatus(userId, "friends");
      setTimeout(() => {
        const d = useDiscord.getState().dms.find((x) => !x.group && x.userIds.includes(userId));
        if (d) setActiveDm(d.id);
      }, 0);
    }
  }

  return (
    <section className="flex min-w-0 flex-1 flex-col bg-dc-chat">
      <header className="flex h-12 shrink-0 items-center gap-3 px-4 shadow-[0_1px_0_var(--color-dc-divider)]">
        <UserPlus className="size-5 text-dc-muted" />
        <h1 className="font-semibold text-dc-heading">{t(lang, "friends")}</h1>
        <div className="mx-2 h-6 w-px bg-dc-divider" />
        {tabs.map((tb) => (
          <button
            key={tb}
            type="button"
            onClick={() => setTab(tb)}
            className={cn(
              "h-6 rounded-sm px-2 text-sm font-medium",
              tb === "add"
                ? "bg-dc-green-btn text-dc-white"
                : tab === tb
                  ? "bg-dc-active text-dc-heading"
                  : "text-dc-muted hover:text-dc-heading",
            )}
          >
            {tb === "online"
              ? t(lang, "online")
              : tb === "all"
                ? t(lang, "all")
                : tb === "pending"
                  ? t(lang, "pending")
                  : tb === "blocked"
                    ? t(lang, "blocked")
                    : t(lang, "addFriend")}
          </button>
        ))}
      </header>

      {tab === "add" ? (
        <div className="mx-auto w-full max-w-xl p-8">
          <h2 className="text-xl font-semibold uppercase tracking-wide text-dc-heading">{t(lang, "addFriend")}</h2>
          <p className="mt-1 text-dc-muted">{t(lang, "friendPlaceholder")}</p>
          <form
            className="mt-4 flex h-12 items-center rounded-lg bg-dc-server px-3"
            onSubmit={(e) => {
              e.preventDefault();
              addFriend(uname);
              setUname("");
            }}
          >
            <input
              value={uname}
              onChange={(e) => setUname(e.target.value)}
              placeholder="trinity"
              className="h-full flex-1 bg-transparent text-dc-heading outline-none"
            />
            <button
              type="submit"
              disabled={!uname.trim()}
              className="h-8 rounded-sm bg-dc-brand px-3 text-sm text-dc-white disabled:opacity-50"
            >
              {t(lang, "sendRequest")}
            </button>
          </form>
        </div>
      ) : (
        <>
          <div className="px-4 py-3">
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder={t(lang, "searchFriends")}
              className="h-8 w-full rounded-sm bg-dc-server px-2 text-sm outline-none"
            />
          </div>
          <div className="flex-1 overflow-y-auto dc-scroll px-2 pb-8">
            <div className="px-2 pb-2 text-[11px] font-bold uppercase tracking-wide text-dc-muted">
              {tab === "online" ? t(lang, "online") : tab === "pending" ? t(lang, "pending") : tab === "blocked" ? t(lang, "blocked") : t(lang, "all")} — {list.length}
            </div>
            {list.length === 0 && (
              <p className="px-4 py-8 text-center text-dc-muted">
                {tab === "pending" ? t(lang, "pendingEmpty") : tab === "blocked" ? t(lang, "blockedEmpty") : t(lang, "noFriends")}
              </p>
            )}
            {list.map((f) => (
              <div
                key={f.userId}
                className="group flex items-center gap-3 rounded-lg px-2 py-2 hover:bg-dc-hover"
              >
                <button type="button" onClick={() => openProfile(f.userId)}>
                  <UserAvatar avatar={f.user.avatar} status={f.user.status} size={32} />
                </button>
                <div className="min-w-0 flex-1">
                  <div className="truncate font-medium text-dc-heading">
                    {f.user.displayName}
                    {f.user.nitro && <Pill tone="nitro">Nitro</Pill>}
                  </div>
                  <div className="text-xs text-dc-muted">
                    {f.status === "pending_in"
                      ? t(lang, "incoming")
                      : f.status === "pending_out"
                        ? t(lang, "outgoing")
                        : f.user.customStatus || f.user.status}
                  </div>
                </div>
                {f.status === "pending_in" && (
                  <>
                    <button
                      type="button"
                      className="grid size-9 place-items-center rounded-full bg-dc-server text-dc-green"
                      onClick={() => setFriendStatus(f.userId, "friends")}
                      aria-label={t(lang, "accept")}
                    >
                      <Check className="size-4" />
                    </button>
                    <button
                      type="button"
                      className="grid size-9 place-items-center rounded-full bg-dc-server text-dc-red"
                      onClick={() => setFriendStatus(f.userId, "remove")}
                      aria-label={t(lang, "ignore")}
                    >
                      <X className="size-4" />
                    </button>
                  </>
                )}
                {f.status === "friends" && (
                  <>
                    <button
                      type="button"
                      className="grid size-9 place-items-center rounded-full bg-dc-server text-dc-heading opacity-0 group-hover:opacity-100"
                      onClick={() => openDm(f.userId)}
                      aria-label={t(lang, "messageUser")}
                    >
                      <MessageCircle className="size-4" />
                    </button>
                    <button
                      type="button"
                      className="grid size-9 place-items-center rounded-full bg-dc-server text-dc-heading opacity-0 group-hover:opacity-100"
                      onClick={() => {
                        openDm(f.userId);
                        const dm = useDiscord.getState().dms.find((d) => !d.group && d.userIds.includes(f.userId));
                        if (dm) startCall(dm.id, false);
                      }}
                      aria-label={t(lang, "call")}
                    >
                      <Phone className="size-4" />
                    </button>
                    <button
                      type="button"
                      className="grid size-9 place-items-center rounded-full bg-dc-server text-dc-heading"
                      aria-label={t(lang, "more")}
                    >
                      <MoreHorizontal className="size-4" />
                    </button>
                  </>
                )}
                {(f.status === "blocked" || f.status === "ignored") && (
                  <button
                    type="button"
                    className="h-8 rounded-sm bg-dc-server px-3 text-sm"
                    onClick={() => setFriendStatus(f.userId, "remove")}
                  >
                    {t(lang, "unblock")}
                  </button>
                )}
              </div>
            ))}
          </div>
        </>
      )}
    </section>
  );
}
