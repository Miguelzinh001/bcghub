import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function uid(prefix = "id") {
  return `${prefix}_${Math.random().toString(36).slice(2, 10)}${Date.now().toString(36).slice(-4)}`;
}

export function daysAgo(n: number, hours = 0, minutes = 0) {
  return new Date(Date.now() - n * 86400000 - hours * 3600000 - minutes * 60000).toISOString();
}

export function hoursAgo(n: number) {
  return new Date(Date.now() - n * 3600000).toISOString();
}

export function minutesAgo(n: number) {
  return new Date(Date.now() - n * 60000).toISOString();
}

export function formatTimeAgo(iso: string, lang: "pt" | "en" = "pt") {
  const diff = Date.now() - new Date(iso).getTime();
  const m = Math.floor(diff / 60000);
  const h = Math.floor(diff / 3600000);
  const d = Math.floor(diff / 86400000);
  if (m < 1) return lang === "pt" ? "agora" : "now";
  if (m < 60) return `${m}m`;
  if (h < 24) return `${h}h`;
  if (d < 30) return `${d}d`;
  const mo = Math.max(1, Math.floor(d / 30));
  if (lang === "pt") return mo === 1 ? "1 mês" : `${mo} meses`;
  return mo === 1 ? "1 mo" : `${mo} mo`;
}

export function formatClock(iso: string) {
  const d = new Date(iso);
  return d.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" });
}

export function formatFullDate(iso: string, lang: "pt" | "en" = "pt") {
  const d = new Date(iso);
  return d.toLocaleString(lang === "pt" ? "pt-BR" : "en-US", {
    day: "2-digit",
    month: "long",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function formatDaySep(iso: string, lang: "pt" | "en" = "pt") {
  const d = new Date(iso);
  const today = new Date();
  const yest = new Date(today);
  yest.setDate(today.getDate() - 1);
  const same = (a: Date, b: Date) =>
    a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
  if (same(d, today)) return lang === "pt" ? "Hoje" : "Today";
  if (same(d, yest)) return lang === "pt" ? "Ontem" : "Yesterday";
  return d.toLocaleDateString(lang === "pt" ? "pt-BR" : "en-US", {
    day: "2-digit",
    month: "long",
    year: "numeric",
  });
}

export function sameDay(a: string, b: string) {
  const da = new Date(a);
  const db = new Date(b);
  return da.getFullYear() === db.getFullYear() && da.getMonth() === db.getMonth() && da.getDate() === db.getDate();
}
