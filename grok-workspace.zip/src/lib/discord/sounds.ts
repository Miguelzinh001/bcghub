let ctx: AudioContext | null = null;

function ac() {
  if (typeof window === "undefined") return null;
  if (!ctx) ctx = new AudioContext();
  return ctx;
}

function beep(freq: number, dur: number, type: OscillatorType, gain = 0.04, delay = 0) {
  const c = ac();
  if (!c) return;
  const o = c.createOscillator();
  const g = c.createGain();
  o.type = type;
  o.frequency.value = freq;
  g.gain.value = gain;
  o.connect(g);
  g.connect(c.destination);
  const t = c.currentTime + delay;
  o.start(t);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.stop(t + dur + 0.02);
}

export const sfx = {
  message: () => {
    beep(880, 0.08, "sine", 0.03);
    beep(1320, 0.1, "sine", 0.025, 0.07);
  },
  join: () => beep(520, 0.12, "triangle", 0.04),
  leave: () => beep(280, 0.16, "triangle", 0.04),
  mute: () => beep(240, 0.08, "square", 0.02),
  deafen: () => {
    beep(200, 0.08, "square", 0.02);
    beep(140, 0.1, "square", 0.02, 0.08);
  },
  call: () => {
    beep(640, 0.18, "sine", 0.05);
    beep(860, 0.18, "sine", 0.05, 0.2);
  },
  click: () => beep(1200, 0.03, "sine", 0.015),
  error: () => beep(180, 0.2, "sawtooth", 0.03),
  soundboard: (id: string) => {
    const map: Record<string, () => void> = {
      airhorn: () => {
        beep(420, 0.25, "sawtooth", 0.06);
        beep(280, 0.3, "square", 0.04, 0.05);
      },
      cricket: () => {
        beep(4200, 0.04, "square", 0.02);
        beep(4200, 0.04, "square", 0.02, 0.12);
        beep(4200, 0.04, "square", 0.02, 0.24);
      },
      drum: () => {
        beep(80, 0.12, "sine", 0.08);
        beep(220, 0.08, "triangle", 0.04, 0.14);
        beep(880, 0.18, "sine", 0.03, 0.22);
      },
      honk: () => beep(220, 0.28, "square", 0.05),
      wow: () => {
        beep(400, 0.2, "sine", 0.04);
        beep(700, 0.25, "sine", 0.04, 0.15);
      },
      bruh: () => beep(110, 0.35, "sawtooth", 0.05),
      error: () => {
        beep(440, 0.12, "square", 0.04);
        beep(330, 0.2, "square", 0.04, 0.12);
      },
      vine: () => beep(60, 0.35, "sine", 0.1),
    };
    (map[id] ?? map.honk)();
  },
};
