import { daysAgo, hoursAgo, minutesAgo } from "@/lib/utils";
import type {
  Channel,
  Category,
  DMChannel,
  FriendRelation,
  Message,
  Role,
  Server,
  Settings,
  User,
} from "./types";

export const ME_ID = "trinity";

export const defaultSettings: Settings = {
  theme: "dark",
  compact: false,
  language: "pt",
  fontScale: 16,
  messageDisplay: "cozy",
  showAvatars: true,
  animateEmoji: true,
  gifAutoplay: true,
  linkPreview: true,
  developerMode: false,
  streamerMode: false,
  reduceMotion: false,
  hardwareAccel: true,
  notifications: true,
  dndSuppress: true,
  tts: false,
  inputVolume: 80,
  outputVolume: 70,
  micTest: 0,
  echoCancel: true,
  noiseSuppression: true,
  autoGain: true,
  overlay: true,
  showCurrentGame: true,
  allowDMs: true,
  allowFriendRequests: true,
  previewLinks: true,
  useUnreadBadge: true,
  chatFont: "default",
};

function u(
  partial: Omit<User, "createdAt"> & { createdAt?: string },
): User {
  return { createdAt: daysAgo(400), ...partial };
}

export const users: Record<string, User> = {
  trinity: u({
    id: "trinity",
    username: "trinity",
    displayName: "trinity",
    avatar: "trinity",
    accent: "#7dd3fc",
    status: "dnd",
    customStatus: "Não perturbar",
    bio: "só passando · garden addict · tickets closed",
    nitro: true,
    pronouns: "ela/dela",
    badges: ["nitro", "boost", "early"],
    bannerColor: "#0ea5e9",
  }),
  dyno: u({
    id: "dyno",
    username: "dyno",
    displayName: "Dyno",
    avatar: "dyno",
    accent: "#3b82f6",
    status: "online",
    bot: true,
    bio: "O bot de moderação mais usado.",
    badges: ["bot"],
  }),
  discord: u({
    id: "discord",
    username: "discord",
    displayName: "Discord",
    avatar: "discord",
    accent: "#5865f2",
    status: "online",
    bot: true,
    official: true,
    bio: "Atualizações oficiais, dicas e segurança.",
    badges: ["official", "bot"],
  }),
  welcomer: u({
    id: "welcomer",
    username: "welcomer",
    displayName: "Welcomer",
    avatar: "welcomer",
    accent: "#fbbf24",
    status: "online",
    bot: true,
    bio: "Boas-vindas automáticas para o seu servidor.",
    badges: ["bot"],
  }),
  ivana: u({
    id: "ivana",
    username: "ivana",
    displayName: "ivana",
    avatar: "ivana",
    accent: "#a78bfa",
    status: "offline",
    bio: "zzz",
  }),
  bruna: u({
    id: "bruna",
    username: "bruna",
    displayName: "bruna",
    avatar: "bruna",
    accent: "#fb7185",
    status: "online",
    customStatus: "sorteios no pix",
    customStatusEmoji: "💸",
    bio: "lives · sorteios · comunidade",
    nitro: true,
    badges: ["nitro"],
  }),
  kika: u({
    id: "kika",
    username: "kika",
    displayName: "希花..",
    avatar: "kika",
    accent: "#f472b6",
    status: "idle",
    customStatus: "boa noite",
    customStatusEmoji: "🍡",
    bio: "anime · late night vc",
    pronouns: "ela/dela",
  }),
  tickety: u({
    id: "tickety",
    username: "tickety",
    displayName: "Tickety",
    avatar: "tickety",
    accent: "#64748b",
    status: "online",
    bot: true,
    badges: ["bot"],
  }),
  garden: u({
    id: "garden",
    username: "growagarden",
    displayName: "Grow a Garden 2",
    avatar: "garden",
    accent: "#22c55e",
    status: "online",
    bot: true,
    badges: ["bot"],
  }),
  tracker: u({
    id: "tracker",
    username: "invitetracker",
    displayName: "Invite Tracker",
    avatar: "tracker",
    accent: "#22d3ee",
    status: "online",
    bot: true,
    badges: ["bot"],
  }),
  luna: u({
    id: "luna",
    username: "luna",
    displayName: "luna",
    avatar: "luna",
    accent: "#fb7185",
    status: "online",
    customStatus: "miau",
    customStatusEmoji: "🐱",
    nitro: true,
    pronouns: "ela/dela",
  }),
  ash: u({
    id: "ash",
    username: "ash",
    displayName: "ash",
    avatar: "ash",
    accent: "#9ca3af",
    status: "online",
    bio: "quiet hours",
  }),
  raven: u({
    id: "raven",
    username: "raven",
    displayName: "raven",
    avatar: "raven",
    accent: "#111827",
    status: "idle",
    customStatus: "playlist 3am",
    customStatusEmoji: "🎧",
  }),
  kai: u({
    id: "kai",
    username: "kai",
    displayName: "kai",
    avatar: "kai",
    accent: "#2dd4bf",
    status: "online",
    customStatus: "ranked",
    customStatusEmoji: "🎮",
    bio: "fps + farm games",
  }),
  nina: u({
    id: "nina",
    username: "nina",
    displayName: "nina",
    avatar: "nina",
    accent: "#f43f5e",
    status: "dnd",
    customStatus: "estudando",
    customStatusEmoji: "📚",
  }),
  leo: u({
    id: "leo",
    username: "leo",
    displayName: "leo",
    avatar: "leo",
    accent: "#f59e0b",
    status: "online",
    bio: "mod · events",
    badges: ["mod"],
  }),
  mira: u({
    id: "mira",
    username: "mira",
    displayName: "mira",
    avatar: "mira",
    accent: "#818cf8",
    status: "idle",
    nitro: true,
  }),
  tor: u({
    id: "tor",
    username: "torment",
    displayName: "Torment",
    avatar: "tor",
    accent: "#94a3b8",
    status: "online",
  }),
  voidu: u({
    id: "voidu",
    username: "v01dau",
    displayName: "v01dau",
    avatar: "void",
    accent: "#818cf8",
    status: "offline",
  }),
  wumpus: u({
    id: "wumpus",
    username: "wumpus",
    displayName: "Wumpus",
    avatar: "wumpus",
    accent: "#5865f2",
    status: "online",
    bot: true,
    official: true,
  }),
};

const defaultPerms = ["VIEW", "SEND", "READ_HISTORY", "CONNECT", "SPEAK", "REACT"];
const modPerms = [...defaultPerms, "KICK", "BAN", "MANAGE_MESSAGES", "MUTE", "MANAGE_NICK"];
const adminPerms = [...modPerms, "MANAGE_CHANNELS", "MANAGE_ROLES", "ADMIN", "MENTION_EVERYONE"];

function roles(server: string): Role[] {
  return [
    { id: `${server}-owner`, name: "Dono", color: "#f7c948", hoist: true, permissions: adminPerms },
    { id: `${server}-admin`, name: "Admin", color: "#ed4245", hoist: true, permissions: adminPerms },
    { id: `${server}-mod`, name: "Moderador", color: "#57f287", hoist: true, permissions: modPerms },
    { id: `${server}-boost`, name: "Booster", color: "#f47fff", hoist: true, permissions: defaultPerms },
    { id: `${server}-bot`, name: "Bots", color: "#5865f2", hoist: true, permissions: defaultPerms },
    { id: `${server}-member`, name: "Membro", color: "#949ba4", hoist: false, permissions: defaultPerms },
  ];
}

function ch(
  serverId: string,
  id: string,
  name: string,
  type: Channel["type"],
  extra: Partial<Channel> = {},
): Channel {
  return { id, serverId, name, type, position: 0, ...extra };
}

function cat(id: string, name: string, channels: Channel[], collapsed = false): Category {
  return { id, name, collapsed, channels };
}

export const servers: Server[] = [
  {
    id: "nexus",
    name: "Nexus HQ",
    icon: "discord",
    description: "Servidor oficial do Nexus. Regras, anúncios e suporte.",
    ownerId: "discord",
    unread: 2,
    mentions: 2,
    boosts: 14,
    verified: true,
    community: true,
    memberCount: 12840,
    onlineCount: 2031,
    vanity: "nexus",
    roles: roles("nexus"),
    emojis: [
      { id: "pepe", name: "pepe" },
      { id: "blob", name: "blob" },
      { id: "catkiss", name: "catkiss" },
    ],
    categories: [
      cat("nexus-info", "INFORMAÇÕES", [
        ch("nexus", "nexus-regras", "regras", "rules", { topic: "Leia antes de falar." }),
        ch("nexus", "nexus-anuncios", "anúncios", "announcement", { topic: "Novidades oficiais." }),
        ch("nexus", "nexus-guia", "guia", "text", { topic: "Como usar o Nexus." }),
      ]),
      cat("nexus-chat", "GERAL", [
        ch("nexus", "nexus-geral", "geral", "text", { topic: "Conversa livre.", unread: true, mentions: 2 }),
        ch("nexus", "nexus-fotos", "mídia", "text", { topic: "Imagens e clips." }),
        ch("nexus", "nexus-comandos", "comandos", "text", { topic: "Bots e slash commands." }),
        ch("nexus", "nexus-forum", "ideias", "forum", { topic: "Sugestões da comunidade." }),
      ]),
      cat("nexus-voice", "VOZ", [
        ch("nexus", "nexus-lounge", "Lounge", "voice", { connectedUserIds: ["kai", "mira"] }),
        ch("nexus", "nexus-music", "Música", "voice", { connectedUserIds: ["raven"] }),
        ch("nexus", "nexus-stage", "Palco", "stage"),
        ch("nexus", "nexus-afk", "AFK", "voice"),
      ]),
    ],
  },
  {
    id: "vault",
    name: "VaultX",
    icon: "vault",
    description: "Clã competitivo. Rankeds, scrims e clips.",
    ownerId: "kai",
    unread: 5,
    mentions: 0,
    boosts: 7,
    memberCount: 842,
    onlineCount: 126,
    roles: roles("vault"),
    emojis: [{ id: "clutch", name: "clutch" }],
    categories: [
      cat("vault-txt", "TEXTO", [
        ch("vault", "vault-geral", "geral", "text", { unread: true }),
        ch("vault", "vault-clips", "clips", "text"),
        ch("vault", "vault-lfg", "lfg", "text", { topic: "Procura grupo." }),
      ]),
      cat("vault-vc", "VOZ", [
        ch("vault", "vault-lobby", "Lobby", "voice", { connectedUserIds: ["kai", "leo", "tor"] }),
        ch("vault", "vault-scrim", "Scrim 1", "voice"),
        ch("vault", "vault-scrim2", "Scrim 2", "voice"),
      ]),
    ],
  },
  {
    id: "garden-sv",
    name: "Grow a Garden",
    icon: "garden",
    description: "Farm, trades e eventos da horta.",
    ownerId: "garden",
    unread: 2,
    mentions: 0,
    boosts: 3,
    memberCount: 54021,
    onlineCount: 4102,
    community: true,
    roles: roles("garden-sv"),
    emojis: [{ id: "carrot", name: "carrot" }],
    categories: [
      cat("g-info", "INFO", [
        ch("garden-sv", "g-anuncios", "anúncios", "announcement"),
        ch("garden-sv", "g-regras", "regras", "rules"),
      ]),
      cat("g-chat", "CHAT", [
        ch("garden-sv", "g-geral", "geral", "text", { unread: true }),
        ch("garden-sv", "g-trades", "trades", "text"),
        ch("garden-sv", "g-help", "ajuda", "text"),
      ]),
      cat("g-vc", "VOZ", [
        ch("garden-sv", "g-farm", "Farm Party", "voice", { connectedUserIds: ["luna", "ash"] }),
        ch("garden-sv", "g-chill", "Chill", "voice"),
      ]),
    ],
  },
  {
    id: "hug",
    name: "HUG COMMUNITY",
    icon: "hug",
    description: "Comunidade aconchegante. Eventos, calls e amizades.",
    ownerId: "nina",
    unread: 206,
    mentions: 12,
    boosts: 21,
    memberCount: 12006,
    onlineCount: 980,
    community: true,
    roles: roles("hug"),
    emojis: [{ id: "hug", name: "hug" }],
    categories: [
      cat("h-info", "INÍCIO", [
        ch("hug", "h-regras", "regras", "rules"),
        ch("hug", "h-anuncios", "anúncios", "announcement", { mentions: 3 }),
        ch("hug", "h-eventos", "eventos", "text"),
      ]),
      cat("h-chat", "CHAT", [
        ch("hug", "h-geral", "geral", "text", { unread: true, mentions: 9 }),
        ch("hug", "h-memes", "memes", "text"),
        ch("hug", "h-nsfw", "nsfw", "text", { nsfw: true }),
        ch("hug", "h-forum", "desabafos", "forum"),
      ]),
      cat("h-vc", "CALLS", [
        ch("hug", "h-main", "Main", "voice", { connectedUserIds: ["nina", "mira", "leo"] }),
        ch("hug", "h-late", "Late Night", "voice"),
        ch("hug", "h-stage", "Palco", "stage"),
      ]),
    ],
  },
  {
    id: "night",
    name: "Night Drive",
    icon: "night",
    description: "Synthwave, carros e madrugada.",
    ownerId: "raven",
    unread: 0,
    mentions: 0,
    boosts: 2,
    memberCount: 412,
    onlineCount: 38,
    roles: roles("night"),
    emojis: [],
    categories: [
      cat("n-chat", "CHAT", [
        ch("night", "n-geral", "geral", "text"),
        ch("night", "n-playlist", "playlist", "text"),
      ]),
      cat("n-vc", "VOZ", [
        ch("night", "n-drive", "Drive", "voice"),
        ch("night", "n-radio", "Rádio", "voice"),
      ]),
    ],
  },
  {
    id: "pixel",
    name: "Pixel Arcade",
    icon: "pixel",
    description: "Jogos retrô, game nights e speedruns.",
    ownerId: "leo",
    unread: 0,
    mentions: 0,
    boosts: 5,
    memberCount: 2201,
    onlineCount: 190,
    roles: roles("pixel"),
    emojis: [],
    categories: [
      cat("p-chat", "JOGOS", [
        ch("pixel", "p-geral", "geral", "text"),
        ch("pixel", "p-lfg", "lfg", "text"),
      ]),
      cat("p-vc", "VOZ", [
        ch("pixel", "p-arcade", "Arcade", "voice"),
        ch("pixel", "p-party", "Party", "voice"),
      ]),
    ],
  },
  {
    id: "study",
    name: "Study Together",
    icon: "study",
    description: "Pomodoro, accountability e silêncio.",
    ownerId: "nina",
    unread: 0,
    mentions: 0,
    boosts: 4,
    memberCount: 8900,
    onlineCount: 640,
    community: true,
    roles: roles("study"),
    emojis: [],
    categories: [
      cat("s-chat", "ESTUDO", [
        ch("study", "s-geral", "geral", "text"),
        ch("study", "s-recursos", "recursos", "text"),
        ch("study", "s-forum", "dúvidas", "forum"),
      ]),
      cat("s-vc", "FOCO", [
        ch("study", "s-silent", "Silêncio", "voice", { connectedUserIds: ["nina"] }),
        ch("study", "s-talk", "Discussão", "voice"),
      ]),
    ],
  },
  {
    id: "music-sv",
    name: "Music Lounge",
    icon: "music",
    description: "Live listening parties e recomendações.",
    ownerId: "raven",
    unread: 1,
    mentions: 0,
    boosts: 9,
    memberCount: 3300,
    onlineCount: 275,
    roles: roles("music-sv"),
    emojis: [],
    categories: [
      cat("m-chat", "MÚSICA", [
        ch("music-sv", "m-geral", "geral", "text", { unread: true }),
        ch("music-sv", "m-recs", "recomendações", "text"),
      ]),
      cat("m-vc", "OUVIR", [
        ch("music-sv", "m-live", "Listening Party", "voice", { connectedUserIds: ["raven", "kika"] }),
        ch("music-sv", "m-karaoke", "Karaokê", "voice"),
      ]),
    ],
  },
  {
    id: "devbr",
    name: "Dev Brasil",
    icon: "dev",
    description: "Código, vagas, code review e café.",
    ownerId: "mira",
    unread: 0,
    mentions: 0,
    boosts: 11,
    memberCount: 15400,
    onlineCount: 1102,
    verified: true,
    community: true,
    roles: roles("devbr"),
    emojis: [],
    categories: [
      cat("d-info", "INFO", [
        ch("devbr", "d-regras", "regras", "rules"),
        ch("devbr", "d-vagas", "vagas", "text"),
      ]),
      cat("d-chat", "DEV", [
        ch("devbr", "d-geral", "geral", "text"),
        ch("devbr", "d-help", "ajuda", "text"),
        ch("devbr", "d-showcase", "showcase", "forum"),
      ]),
      cat("d-vc", "PAIR", [
        ch("devbr", "d-pair", "Pair Programming", "voice"),
        ch("devbr", "d-lounge", "Lounge", "voice"),
      ]),
    ],
  },
  {
    id: "anime",
    name: "Anime Club",
    icon: "anime",
    description: "Temporada atual, spoilers marcados, watch parties.",
    ownerId: "kika",
    unread: 4,
    mentions: 1,
    boosts: 6,
    memberCount: 6700,
    onlineCount: 512,
    roles: roles("anime"),
    emojis: [{ id: "animespark", name: "spark" }],
    categories: [
      cat("a-chat", "ANIME", [
        ch("anime", "a-geral", "geral", "text", { unread: true, mentions: 1 }),
        ch("anime", "a-spoilers", "spoilers", "text", { nsfw: true, topic: "Marque spoilers." }),
        ch("anime", "a-recs", "recomendações", "forum"),
      ]),
      cat("a-vc", "WATCH", [
        ch("anime", "a-watch", "Watch Party", "voice"),
        ch("anime", "a-stage", "Discussão", "stage"),
      ]),
    ],
  },
  {
    id: "ladybug",
    name: "Ladybug",
    icon: "lady",
    description: "Servidor pequeno de amigos.",
    ownerId: "luna",
    unread: 2,
    mentions: 0,
    boosts: 1,
    memberCount: 28,
    onlineCount: 6,
    roles: roles("ladybug"),
    emojis: [],
    categories: [
      cat("l-chat", "CASA", [
        ch("ladybug", "l-geral", "geral", "text", { unread: true }),
        ch("ladybug", "l-fotos", "fotos", "text"),
      ]),
      cat("l-vc", "CALL", [ch("ladybug", "l-sala", "Sala", "voice")]),
    ],
  },
];

export const dms: DMChannel[] = [
  {
    id: "dm-dyno",
    userIds: ["trinity", "dyno"],
    lastMessage: "Dyno: @trinity Seja bem vindo, a M...",
    lastAt: daysAgo(3, 2),
    unread: 0,
  },
  {
    id: "dm-discord",
    userIds: ["trinity", "discord"],
    lastMessage: "Discord: Olá,",
    lastAt: daysAgo(3, 4),
    unread: 0,
  },
  {
    id: "dm-welcomer",
    userIds: ["trinity", "welcomer"],
    lastMessage: "Welcomer: Sent by Torment x v01dau...",
    lastAt: daysAgo(12),
    unread: 0,
  },
  {
    id: "dm-ivana",
    userIds: ["trinity", "ivana"],
    lastMessage: "Mensagem ignorada",
    lastAt: daysAgo(13),
    ignored: true,
  },
  {
    id: "dm-bruna",
    userIds: ["trinity", "bruna"],
    lastMessage: "bruna: SORTEIOS 500 NO PIX + 50...",
    lastAt: daysAgo(22),
    unread: 1,
  },
  {
    id: "dm-kika",
    userIds: ["trinity", "kika"],
    lastMessage: "Você: Boa noite",
    lastAt: daysAgo(28),
  },
  {
    id: "dm-tickety",
    userIds: ["trinity", "tickety"],
    lastMessage: "Tickety: Ticket Closed",
    lastAt: daysAgo(29),
  },
  {
    id: "dm-garden",
    userIds: ["trinity", "garden"],
    lastMessage: "Grow a Garden 2: Hey @trinity! Je...",
    lastAt: daysAgo(60),
  },
  {
    id: "dm-tracker",
    userIds: ["trinity", "tracker"],
    lastMessage: "Invite Tracker: 10x GHOST PEPPE...",
    lastAt: daysAgo(62),
  },
  {
    id: "dm-luna",
    userIds: ["trinity", "luna"],
    lastMessage: "luna: volta no vc depois",
    lastAt: hoursAgo(2),
    unread: 0,
    pinned: true,
  },
  {
    id: "gdm-night",
    userIds: ["trinity", "luna", "ash", "raven"],
    group: true,
    name: "madrugada",
    icon: "night",
    lastMessage: "ash: alguém up?",
    lastAt: hoursAgo(5),
  },
];

export const friends: FriendRelation[] = [
  { userId: "luna", status: "friends", since: daysAgo(120) },
  { userId: "ash", status: "friends", since: daysAgo(90) },
  { userId: "raven", status: "friends", since: daysAgo(80) },
  { userId: "kai", status: "friends", since: daysAgo(40) },
  { userId: "nina", status: "friends", since: daysAgo(55) },
  { userId: "leo", status: "friends", since: daysAgo(200) },
  { userId: "mira", status: "friends", since: daysAgo(15) },
  { userId: "kika", status: "friends", since: daysAgo(70) },
  { userId: "bruna", status: "friends", since: daysAgo(30) },
  { userId: "tor", status: "pending_in", since: daysAgo(1) },
  { userId: "voidu", status: "pending_out", since: daysAgo(2) },
  { userId: "ivana", status: "ignored", since: daysAgo(13) },
];

function msg(
  channelId: string,
  authorId: string,
  content: string,
  createdAt: string,
  extra: Partial<Message> = {},
): Message {
  return {
    id: `m_${channelId}_${createdAt}_${authorId}_${content.slice(0, 8)}`,
    channelId,
    authorId,
    content,
    createdAt,
    type: "default",
    ...extra,
  };
}

export const messages: Record<string, Message[]> = {
  "dm-dyno": [
    msg("dm-dyno", "dyno", "Olá **@trinity**! 🎁 Seja bem vindo, a Moderação automática está ativa neste servidor.", daysAgo(3, 2), {
      embeds: [
        {
          author: "Dyno",
          title: "Bem-vindo",
          description: "Você recebeu o cargo **Membro**. Use `/help` para ver comandos.",
          color: "#3b82f6",
          footer: "Dyno • automod",
        },
      ],
    }),
    msg("dm-dyno", "dyno", "Dica: ative a verificação em duas etapas na sua conta.", daysAgo(3, 2, 2)),
  ],
  "dm-discord": [
    msg("dm-discord", "discord", "Olá, **trinity**. Esta é uma mensagem oficial do Nexus.", daysAgo(3, 4)),
    msg(
      "dm-discord",
      "discord",
      "Nunca pedimos sua senha. Se alguém se passar por nós, denuncie.",
      daysAgo(3, 4, 1),
      {
        embeds: [
          {
            title: "Dicas de segurança",
            description: "Ative 2FA, não clique em links suspeitos e desconfie de sorteios milagrosos.",
            color: "#5865f2",
            footer: "Nexus Safety",
          },
        ],
      },
    ),
  ],
  "dm-welcomer": [
    msg("dm-welcomer", "welcomer", "Sent by **Torment** x **v01dau** — imagem de boas-vindas gerada.", daysAgo(12), {
      embeds: [
        {
          title: "Bem-vindo ao servidor",
          description: "trinity acabou de entrar. Diga oi em #geral!",
          color: "#fbbf24",
          image: "welcome",
        },
      ],
    }),
  ],
  "dm-ivana": [
    msg("dm-ivana", "ivana", "oi sumida", daysAgo(13)),
    msg("dm-ivana", "trinity", "oi", daysAgo(13, 0, 20)),
  ],
  "dm-bruna": [
    msg("dm-bruna", "bruna", "oi genteee entram no server", daysAgo(22, 3)),
    msg(
      "dm-bruna",
      "bruna",
      "🍀 **SORTEIOS 500 NO PIX + 50** nitro boost — reaja e entre no canal de anúncios",
      daysAgo(22),
      {
        reactions: [
          { emoji: "🎉", count: 128, me: false },
          { emoji: "💸", count: 64, me: false },
        ],
        embeds: [
          {
            title: "Sorteio da semana",
            description: "500 no Pix + 50 Nitro. Termina sexta 21h. Requisitos: estar no servidor e reagir.",
            color: "#23a55a",
            footer: "bruna • sorteios",
          },
        ],
      },
    ),
  ],
  "dm-kika": [
    msg("dm-kika", "kika", "acordou?", daysAgo(28, 2)),
    msg("dm-kika", "trinity", "Boa noite", daysAgo(28)),
  ],
  "dm-tickety": [
    msg("dm-tickety", "tickety", "Ticket **#1842** aberto — assunto: Nitro não aplicado.", daysAgo(29, 1)),
    msg("dm-tickety", "trinity", "já recebi, pode fechar", daysAgo(29, 0, 40)),
    msg("dm-tickety", "tickety", "Ticket Closed", daysAgo(29), {
      type: "system",
    }),
  ],
  "dm-garden": [
    msg("dm-garden", "garden", "→ Hey **@trinity**! Jeito novo de plantar chegou. Entre em #anúncios 🥕", daysAgo(60)),
  ],
  "dm-tracker": [
    msg("dm-tracker", "tracker", "🎉 10x GHOST PEPPER — alguém usou seu convite. Total: **42** membros.", daysAgo(62)),
  ],
  "dm-luna": [
    msg("dm-luna", "luna", "cade vc", hoursAgo(3)),
    msg("dm-luna", "trinity", "to no garden farmando", hoursAgo(3)),
    msg("dm-luna", "luna", "volta no vc depois", hoursAgo(2), {
      reactions: [{ emoji: "👍", count: 1, me: true }],
    }),
  ],
  "gdm-night": [
    msg("gdm-night", "raven", "playlist nova no lounge", hoursAgo(6)),
    msg("gdm-night", "luna", "to indo", hoursAgo(5, 0)),
    msg("gdm-night", "ash", "alguém up?", hoursAgo(5)),
  ],
  "nexus-geral": [
    msg("nexus-geral", "discord", "Bem-vindos ao **Nexus HQ**. Leiam as regras e se apresentem!", daysAgo(40), {
      pinned: true,
    }),
    msg("nexus-geral", "kai", "alguém up pra ranked?", hoursAgo(6)),
    msg("nexus-geral", "leo", "to no lounge", hoursAgo(5)),
    msg("nexus-geral", "mira", "shippei o layout novo, ficou limpo", hoursAgo(4)),
    msg("nexus-geral", "nina", "pessoal, silêncio no study às 20h — pomodoro coletivo", hoursAgo(3)),
    msg("nexus-geral", "trinity", " boaa, eu entro", hoursAgo(3), {
      replyToId: undefined,
    }),
    msg("nexus-geral", "luna", "kika soltou spoiler no anime club 😭", hoursAgo(2), {
      mentions: ["kika"],
    }),
    msg("nexus-geral", "kika", "foi mal ||era o final da s2||", hoursAgo(2)),
    msg("nexus-geral", "wumpus", "Dica: pressione **Ctrl+K** para pular entre canais.", hoursAgo(1), {
      type: "system",
    }),
    msg("nexus-geral", "kai", "quem vem pro vault lobby", minutesAgo(12), {
      mentions: ["trinity"],
      reactions: [
        { emoji: "🔥", count: 4, me: false },
        { emoji: "🎮", count: 2, me: true },
      ],
    }),
    msg("nexus-geral", "leo", "up", minutesAgo(8)),
  ],
  "nexus-anuncios": [
    msg("nexus-anuncios", "discord", "**Atualização 2.0** — fóruns, palco, atividades e Nitro visual.", daysAgo(7), {
      pinned: true,
      embeds: [
        {
          title: "Nexus 2.0",
          description: "Novo layout mobile, quick switcher, soundboard e loja.",
          color: "#5865f2",
        },
      ],
    }),
  ],
  "nexus-comandos": [
    msg("nexus-comandos", "dyno", "Use `/help`, `/play`, `/poll`, `/timeout` e `/serverinfo`.", daysAgo(2)),
  ],
  "nexus-lounge": [],
  "vault-geral": [
    msg("vault-geral", "kai", "scrim 21h, 5 stack. reajam", hoursAgo(8), {
      reactions: [{ emoji: "✅", count: 5, me: true }],
    }),
    msg("vault-geral", "tor", "to in", hoursAgo(7)),
    msg("vault-geral", "leo", "clip do clutch no #clips", hoursAgo(2)),
  ],
  "g-geral": [
    msg("g-geral", "garden", "Evento de primavera: sementes raras no NPC das 18h.", daysAgo(1)),
    msg("g-geral", "luna", "alguém troca sunflower?", hoursAgo(4)),
    msg("g-geral", "ash", "eu tenho 3 extra", hoursAgo(4)),
  ],
  "h-geral": [
    msg("h-geral", "nina", "bom dia comunidade 💛", hoursAgo(10)),
    msg("h-geral", "mira", "call aberta no Main", hoursAgo(2)),
    msg("h-geral", "leo", "@trinity vem", minutesAgo(20), { mentions: ["trinity"] }),
    msg("h-geral", "luna", "sorteio da bruna tá on", minutesAgo(5)),
  ],
  "a-geral": [
    msg("a-geral", "kika", "ep novo saiu, sem spoiler no geral pfv", hoursAgo(9)),
    msg("a-geral", "raven", "watch party sexta", hoursAgo(1), { mentions: ["trinity"] }),
  ],
  "m-geral": [
    msg("m-geral", "raven", "listening party agora — synthwave set", minutesAgo(40)),
  ],
  "l-geral": [
    msg("l-geral", "luna", "fotos da sexta no #fotos", daysAgo(1)),
  ],
  "d-geral": [
    msg("d-geral", "mira", "PR review às 19h, canal pair", hoursAgo(5)),
  ],
  "s-geral": [
    msg("s-geral", "nina", "pomodoro 50/10 começando. cam opcional.", hoursAgo(1)),
  ],
  "n-geral": [
    msg("n-geral", "raven", "volume baixo, cidade dormindo", hoursAgo(8)),
  ],
  "p-geral": [
    msg("p-geral", "leo", "game night sábado — mario kart", daysAgo(2)),
  ],
  "nexus-forum": [
    msg("nexus-forum", "mira", "**Ideia:** pastas de servidor no mobile\n\nQueria agrupar Vault + Pixel.", daysAgo(4), {
      threadCount: 3,
    }),
    msg("nexus-forum", "kai", "**Atividades na call**\n\nChess e Watch Together já salvam a call morta.", daysAgo(2), {
      threadCount: 6,
    }),
  ],
  "h-forum": [
    msg("h-forum", "ash", "semana pesada. alguém up pra call quieta?", daysAgo(1), { threadCount: 4 }),
  ],
};

export const serverMembers: Record<string, string[]> = {
  nexus: ["trinity", "discord", "dyno", "wumpus", "kai", "leo", "mira", "nina", "luna", "ash", "raven", "kika", "welcomer"],
  vault: ["trinity", "kai", "leo", "tor", "mira", "voidu"],
  "garden-sv": ["trinity", "garden", "luna", "ash", "tracker"],
  hug: ["trinity", "nina", "mira", "leo", "luna", "bruna", "ash", "kika"],
  night: ["trinity", "raven", "ash", "luna"],
  pixel: ["trinity", "leo", "kai", "tor"],
  study: ["trinity", "nina", "mira", "ash"],
  "music-sv": ["trinity", "raven", "kika", "luna"],
  devbr: ["trinity", "mira", "leo", "nina", "kai"],
  anime: ["trinity", "kika", "raven", "luna", "ash"],
  ladybug: ["trinity", "luna", "ash"],
};

export const userRoles: Record<string, Record<string, string[]>> = {
  nexus: {
    trinity: ["nexus-boost", "nexus-member"],
    discord: ["nexus-owner", "nexus-bot"],
    dyno: ["nexus-bot"],
    wumpus: ["nexus-bot"],
    kai: ["nexus-member"],
    leo: ["nexus-mod"],
    mira: ["nexus-admin"],
    nina: ["nexus-member"],
    luna: ["nexus-boost"],
    ash: ["nexus-member"],
    raven: ["nexus-member"],
    kika: ["nexus-member"],
    welcomer: ["nexus-bot"],
  },
  vault: {
    trinity: ["vault-member"],
    kai: ["vault-owner"],
    leo: ["vault-admin"],
    tor: ["vault-mod"],
    mira: ["vault-member"],
    voidu: ["vault-member"],
  },
  hug: {
    trinity: ["hug-member"],
    nina: ["hug-owner"],
    mira: ["hug-admin"],
    leo: ["hug-mod"],
    luna: ["hug-boost"],
    bruna: ["hug-mod"],
    ash: ["hug-member"],
    kika: ["hug-member"],
  },
};

export const discoverCards = [
  {
    id: "vault",
    name: "VaultX",
    icon: "vault",
    members: "842",
    online: "126",
    tag: "Jogos",
    blurb: "Clã competitivo. Rankeds, scrims e clips toda noite.",
  },
  {
    id: "hug",
    name: "HUG COMMUNITY",
    icon: "hug",
    members: "12.006",
    online: "980",
    tag: "Social",
    blurb: "Eventos, calls aconchegantes e amizades de verdade.",
  },
  {
    id: "garden-sv",
    name: "Grow a Garden",
    icon: "garden",
    members: "54.021",
    online: "4.102",
    tag: "Jogos",
    blurb: "Farm, trades e eventos da horta. Sem toxicidade.",
  },
  {
    id: "devbr",
    name: "Dev Brasil",
    icon: "dev",
    members: "15.400",
    online: "1.102",
    tag: "Tecnologia",
    blurb: "Código, vagas, code review e café. PT-BR.",
  },
  {
    id: "anime",
    name: "Anime Club",
    icon: "anime",
    members: "6.700",
    online: "512",
    tag: "Anime",
    blurb: "Temporada atual, spoilers marcados, watch parties.",
  },
  {
    id: "music-sv",
    name: "Music Lounge",
    icon: "music",
    members: "3.300",
    online: "275",
    tag: "Música",
    blurb: "Listening parties, recomendações e karaokê.",
  },
  {
    id: "study",
    name: "Study Together",
    icon: "study",
    members: "8.900",
    online: "640",
    tag: "Educação",
    blurb: "Pomodoro coletivo, accountability e silêncio.",
  },
  {
    id: "pixel",
    name: "Pixel Arcade",
    icon: "pixel",
    members: "2.201",
    online: "190",
    tag: "Jogos",
    blurb: "Retrô, game nights e speedruns de fim de semana.",
  },
];

export const gifPack = [
  { id: "cat", label: "cat dance", hue: 340 },
  { id: "clap", label: "clap", hue: 40 },
  { id: "cry", label: "sad cat", hue: 210 },
  { id: "fire", label: "it's fire", hue: 20 },
  { id: "nod", label: "nod", hue: 160 },
  { id: "nope", label: "nope", hue: 0 },
  { id: "party", label: "party parrot", hue: 280 },
  { id: "thumb", label: "thumbs up", hue: 130 },
  { id: "wave", label: "wave", hue: 200 },
  { id: "wow", label: "mind blown", hue: 50 },
  { id: "sleep", label: "good night", hue: 250 },
  { id: "gg", label: "gg", hue: 90 },
];

export const emojiCats: { id: string; labelKey: string; emojis: string[] }[] = [
  {
    id: "recent",
    labelKey: "recent",
    emojis: ["🔥", "😂", "❤️", "👍", "😭", "🎉", "💀", "✨"],
  },
  {
    id: "people",
    labelKey: "people",
    emojis: [
      "😀", "😃", "😄", "😁", "😆", "😅", "😂", "🤣", "😊", "😇", "🙂", "😉", "😍", "🥰", "😘", "😗",
      "😜", "🤪", "😎", "🤩", "🥳", "😏", "😒", "😞", "😔", "😟", "😕", "🙁", "😣", "😖", "😫", "😩",
      "🥺", "😢", "😭", "😤", "😠", "😡", "🤬", "🤯", "😳", "🥵", "🥶", "😱", "😨", "🤗", "🤔", "🤭",
      "🤫", "🤥", "😐", "😑", "😬", "🙄", "😯", "😦", "😮", "😲", "🥱", "😴", "🤤", "😪", "😵", "🤐",
      "🥴", "🤢", "🤮", "🤧", "😷", "🤒", "🤕", "🤑", "🤠", "😈", "👿", "👹", "👺", "🤡", "💩", "👻",
      "💀", "☠️", "👽", "👾", "🤖", "🎃", "😺", "😸", "😹", "😻", "👋", "🤚", "🖐️", "✋", "🖖", "👌",
      "🤌", "🤏", "✌️", "🤞", "🤟", "🤘", "🤙", "👈", "👉", "👆", "👇", "☝️", "👍", "👎", "✊", "👊",
      "🤛", "🤜", "👏", "🙌", "👐", "🤲", "🤝", "🙏", "💪", "🫶", "👀", "🧠", "👑", "🦊", "🐱", "🐶",
    ],
  },
  {
    id: "nature",
    labelKey: "nature",
    emojis: ["🌸", "💮", "🏵️", "🌹", "🥀", "🌺", "🌻", "🌼", "🌷", "🌱", "🪴", "🌲", "🌳", "🌴", "🌵", "🌾", "🍀", "🍁", "🍂", "🍃", "🍄", "🌊", "🌈", "☀️", "🌙", "⭐", "⚡", "🔥", "❄️", "💨"],
  },
  {
    id: "food",
    labelKey: "food",
    emojis: ["🍏", "🍎", "🍐", "🍊", "🍋", "🍌", "🍉", "🍇", "🍓", "🫐", "🍈", "🍒", "🍑", "🥭", "🍍", "🥥", "🥝", "🍅", "🍆", "🥑", "🥦", "🥕", "🌽", "🍔", "🍟", "🍕", "🌭", "🥪", "🌮", "🍣", "🍩", "🍰", "☕", "🍵", "🍺"],
  },
  {
    id: "activity",
    labelKey: "activityCat",
    emojis: ["⚽", "🏀", "🏈", "⚾", "🎾", "🏐", "🏉", "🥏", "🎱", "🏓", "🏸", "🥅", "⛳", "🏹", "🎣", "🥊", "🥋", "🎮", "🕹️", "🎲", "🧩", "🎯", "🎳", "🎴", "🎬", "🎤", "🎧", "🎼", "🎹", "🥁", "🎸", "🏆", "🥇"],
  },
  {
    id: "travel",
    labelKey: "travel",
    emojis: ["🚗", "🚕", "🚙", "🚌", "🏎️", "🚓", "🚑", "🚒", "🚐", "🚚", "🚜", "🛵", "🏍️", "🚲", "✈️", "🚀", "🛸", "🚁", "🛶", "⛵", "🏠", "🏡", "🏢", "🏰", "🗼", "🗽", "🗿", "🗺️", "🌍"],
  },
  {
    id: "objects",
    labelKey: "objects",
    emojis: ["⌚", "📱", "💻", "⌨️", "🖥️", "🖨️", "🖱️", "🕹️", "💾", "📷", "📹", "🎥", "📞", "☎️", "📺", "📻", "💡", "🔦", "📖", "📚", "📝", "✏️", "📌", "📎", "🔒", "🔑", "🔨", "🛠️", "⚙️", "🧪", "💊", "💉", "🎁", "🎈", "🎉", "✉️", "📦"],
  },
  {
    id: "symbols",
    labelKey: "symbols",
    emojis: ["❤️", "🧡", "💛", "💚", "💙", "💜", "🖤", "🤍", "🤎", "💔", "❣️", "💕", "💞", "💓", "💗", "💖", "💘", "💝", "💟", "☮️", "✝️", "☪️", "🕉️", "☸️", "✡️", "🔯", "🕎", "☯️", "☦️", "🛐", "⛎", "♈", "♉", "♊", "♻️", "✔️", "❌", "❓", "❗", "💯", "💢", "💥", "💫", "💦", "💨", "🕳️", "💬", "🗯️", "💭", "💤", "🔴", "🟠", "🟡", "🟢", "🔵", "🟣", "⚫", "⚪", "🔺", "🔻", "💠", "🔘", "🔳", "🔲"],
  },
  {
    id: "flags",
    labelKey: "flags",
    emojis: ["🏳️", "🏴", "🏁", "🚩", "🇧🇷", "🇵🇹", "🇺🇸", "🇬🇧", "🇯🇵", "🇰🇷", "🇨🇳", "🇩🇪", "🇫🇷", "🇪🇸", "🇮🇹", "🇲🇽", "🇦🇷", "🇨🇦", "🇦🇺", "🇮🇳", "🇷🇺", "🇺🇦", "🏳️‍🌈", "🏳️‍⚧️"],
  },
];

export const slashCommands = [
  { name: "help", hint: "Lista os comandos", bot: "Dyno" },
  { name: "play", hint: "Toca uma música", bot: "Dyno" },
  { name: "skip", hint: "Pula a faixa", bot: "Dyno" },
  { name: "np", hint: "Mostra o que está tocando", bot: "Dyno" },
  { name: "queue", hint: "Mostra a fila", bot: "Dyno" },
  { name: "poll", hint: "Cria uma enquete", bot: "Nexus" },
  { name: "timeout", hint: "Castiga um membro", bot: "Dyno" },
  { name: "ban", hint: "Bane um membro", bot: "Dyno" },
  { name: "kick", hint: "Expulsa um membro", bot: "Dyno" },
  { name: "serverinfo", hint: "Info do servidor", bot: "Dyno" },
  { name: "userinfo", hint: "Info do usuário", bot: "Dyno" },
  { name: "avatar", hint: "Mostra o avatar", bot: "Dyno" },
  { name: "ping", hint: "Latência do bot", bot: "Dyno" },
  { name: "clear", hint: "Apaga mensagens", bot: "Dyno" },
  { name: "slowmode", hint: "Define modo lento", bot: "Dyno" },
  { name: "nick", hint: "Altera apelido", bot: "Dyno" },
  { name: "remind", hint: "Lembrete", bot: "Nexus" },
  { name: "gif", hint: "Busca um GIF", bot: "Nexus" },
  { name: "tableflip", hint: "(╯°□°)╯︵ ┻━┻", bot: "Nexus" },
  { name: "shrug", hint: "¯\\_(ツ)_/¯", bot: "Nexus" },
  { name: "lenny", hint: "( ͡° ͜ʖ ͡°)", bot: "Nexus" },
  { name: "spoiler", hint: "Envia como spoiler", bot: "Nexus" },
  { name: "me", hint: "Ação em itálico", bot: "Nexus" },
  { name: "tts", hint: "Texto para fala", bot: "Nexus" },
  { name: "ticket", hint: "Abre um ticket", bot: "Tickety" },
  { name: "giveaway", hint: "Inicia um sorteio", bot: "Dyno" },
  { name: "invite", hint: "Gera convite", bot: "Invite Tracker" },
];

export const soundboard = [
  { id: "airhorn", label: "Airhorn", color: "#5865f2" },
  { id: "cricket", label: "Crickets", color: "#23a55a" },
  { id: "drum", label: "Ba dum tss", color: "#f0b232" },
  { id: "honk", label: "Honk", color: "#f23f43" },
  { id: "wow", label: "Wow", color: "#00a8fc" },
  { id: "bruh", label: "Bruh", color: "#f47fff" },
  { id: "error", label: "Windows", color: "#949ba4" },
  { id: "vine", label: "Vine boom", color: "#1e1f22" },
];

export const shopItems = [
  { id: "nitro-dark", name: "Nitro Dark", price: "Nitro", kind: "theme" },
  { id: "cyber", name: "Cyber Glow", price: "Nitro", kind: "effect" },
  { id: "sakura", name: "Sakura", price: "Nitro", kind: "banner" },
  { id: "galaxy", name: "Galaxy", price: "Nitro", kind: "effect" },
  { id: "retro", name: "Retro Wave", price: "Loja", kind: "style" },
  { id: "forest", name: "Forest", price: "Loja", kind: "banner" },
];

export const quests = [
  { id: "q1", title: "Ouça 15 min no Spotify", reward: "Decoração de avatar", progress: 70, days: 5 },
  { id: "q2", title: "Fique 30 min em call", reward: "Nitro 2 semanas", progress: 20, days: 12 },
  { id: "q3", title: "Envie 20 mensagens", reward: "Orbe de perfil", progress: 100, days: 2 },
];

export const activities = [
  { id: "yt", name: "YouTube Together", color: "#ff0000" },
  { id: "poker", name: "Poker Night", color: "#3ba55d" },
  { id: "chess", name: "Chess in the Park", color: "#5865f2" },
  { id: "sketch", name: "Sketch Heads", color: "#f0b232" },
  { id: "spell", name: "SpellCast", color: "#9b59b6" },
  { id: "watch", name: "Watch Together", color: "#00a8fc" },
  { id: "putt", name: "Putt Party", color: "#23a55a" },
  { id: "ask", name: "Ask Away", color: "#eb459e" },
];
