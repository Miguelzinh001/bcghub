export type Presence = "online" | "idle" | "dnd" | "offline" | "invisible";
export type ChannelType =
  | "text"
  | "voice"
  | "announcement"
  | "forum"
  | "stage"
  | "rules"
  | "category";
export type MessageType =
  | "default"
  | "reply"
  | "system"
  | "call"
  | "boost"
  | "pin"
  | "join"
  | "poll"
  | "thread";
export type FriendStatus = "friends" | "pending_in" | "pending_out" | "blocked" | "ignored";
export type ThemeMode = "dark" | "light" | "sync";
export type Lang = "pt" | "en";
export type MobilePane = "list" | "chat" | "members" | "profile" | "settings" | "discover" | "nitro";

export interface User {
  id: string;
  username: string;
  displayName: string;
  avatar: string;
  banner?: string;
  accent: string;
  status: Presence;
  customStatus?: string;
  customStatusEmoji?: string;
  bio?: string;
  bot?: boolean;
  official?: boolean;
  nitro?: boolean;
  createdAt: string;
  pronouns?: string;
  badges?: string[];
  bannerColor?: string;
}

export interface Role {
  id: string;
  name: string;
  color: string;
  hoist: boolean;
  permissions: string[];
}

export interface CustomEmoji {
  id: string;
  name: string;
  animated?: boolean;
}

export interface Channel {
  id: string;
  serverId: string;
  name: string;
  type: ChannelType;
  topic?: string;
  nsfw?: boolean;
  slowmode?: number;
  unread?: boolean;
  mentions?: number;
  muted?: boolean;
  connectedUserIds?: string[];
  position: number;
  private?: boolean;
  bitrate?: number;
  userLimit?: number;
  parentId?: string;
}

export interface Category {
  id: string;
  name: string;
  collapsed: boolean;
  channels: Channel[];
}

export interface Server {
  id: string;
  name: string;
  icon: string;
  banner?: string;
  description?: string;
  ownerId: string;
  unread: number;
  mentions: number;
  boosts: number;
  verified?: boolean;
  community?: boolean;
  memberCount: number;
  onlineCount: number;
  categories: Category[];
  roles: Role[];
  emojis: CustomEmoji[];
  vanity?: string;
  folderId?: string | null;
}

export interface ServerFolder {
  id: string;
  name: string;
  color: string;
  serverIds: string[];
  open: boolean;
}

export interface Attachment {
  id: string;
  name: string;
  type: "image" | "file" | "video";
  url: string;
  size?: string;
  width?: number;
  height?: number;
}

export interface Embed {
  title?: string;
  description?: string;
  url?: string;
  color?: string;
  footer?: string;
  image?: string;
  author?: string;
  fields?: { name: string; value: string; inline?: boolean }[];
}

export interface PollOption {
  id: string;
  label: string;
  votes: number;
  me?: boolean;
}

export interface Poll {
  question: string;
  options: PollOption[];
  endsAt?: string;
}

export interface Reaction {
  emoji: string;
  count: number;
  me: boolean;
}

export interface Message {
  id: string;
  channelId: string;
  authorId: string;
  content: string;
  createdAt: string;
  editedAt?: string;
  type: MessageType;
  replyToId?: string;
  pinned?: boolean;
  reactions?: Reaction[];
  attachments?: Attachment[];
  embeds?: Embed[];
  mentions?: string[];
  mentionEveryone?: boolean;
  poll?: Poll;
  threadCount?: number;
}

export interface DMChannel {
  id: string;
  userIds: string[];
  group?: boolean;
  name?: string;
  icon?: string;
  lastMessage: string;
  lastAt: string;
  unread?: number;
  ignored?: boolean;
  pinned?: boolean;
}

export interface FriendRelation {
  userId: string;
  status: FriendStatus;
  since: string;
}

export interface VoiceState {
  channelId: string;
  serverId: string | null;
  muted: boolean;
  deafened: boolean;
  video: boolean;
  streaming: boolean;
  noiseSuppression: boolean;
}

export interface CallState {
  dmId: string;
  video: boolean;
  ringing: boolean;
  startedAt: string;
}

export interface Settings {
  theme: ThemeMode;
  compact: boolean;
  language: Lang;
  fontScale: number;
  messageDisplay: "cozy" | "compact";
  showAvatars: boolean;
  animateEmoji: boolean;
  gifAutoplay: boolean;
  linkPreview: boolean;
  developerMode: boolean;
  streamerMode: boolean;
  reduceMotion: boolean;
  hardwareAccel: boolean;
  notifications: boolean;
  dndSuppress: boolean;
  tts: boolean;
  inputVolume: number;
  outputVolume: number;
  micTest: number;
  echoCancel: boolean;
  noiseSuppression: boolean;
  autoGain: boolean;
  overlay: boolean;
  showCurrentGame: boolean;
  allowDMs: boolean;
  allowFriendRequests: boolean;
  previewLinks: boolean;
  useUnreadBadge: boolean;
  chatFont: "default" | "mono";
}

export interface ContextMenuState {
  x: number;
  y: number;
  kind: "message" | "user" | "channel" | "server" | "dm";
  id: string;
  extra?: string;
}

export interface ToastItem {
  id: string;
  title: string;
  body?: string;
  tone?: "info" | "success" | "error";
}
