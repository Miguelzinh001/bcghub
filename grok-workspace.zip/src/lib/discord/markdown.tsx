import { useState, type ReactNode } from "react";
import { useDiscord } from "./store";

function Spoiler({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false);
  return (
    <span
      className={open ? "spoiler-shown" : "spoiler-hidden"}
      onClick={() => setOpen(true)}
      role="button"
      tabIndex={0}
    >
      {children}
    </span>
  );
}

type Tok =
  | { t: "text"; v: string }
  | { t: "code"; v: string }
  | { t: "pre"; v: string }
  | { t: "bold"; v: string }
  | { t: "italic"; v: string }
  | { t: "under"; v: string }
  | { t: "strike"; v: string }
  | { t: "spoiler"; v: string }
  | { t: "mention"; v: string }
  | { t: "channel"; v: string }
  | { t: "url"; v: string }
  | { t: "br" };

const combo =
  /```([\s\S]+?)```|`([^`]+)`|\|\|(.+?)\|\|\*\*(.+?)\*\*|__(.+?)__|~~(.+?)~~|\*(.+?)\*|@([a-zA-Z0-9._]+)|#([a-zA-Z0-9\-]+)|(https?:\/\/[^\s<]+)/g;

function tokenize(src: string): Tok[] {
  const out: Tok[] = [];
  let last = 0;
  let m: RegExpExecArray | null;
  const re = new RegExp(combo.source, "g");
  while ((m = re.exec(src))) {
    if (m.index > last) out.push({ t: "text", v: src.slice(last, m.index) });
    if (m[1] !== undefined) out.push({ t: "pre", v: m[1] });
    else if (m[2] !== undefined) out.push({ t: "code", v: m[2] });
    else if (m[3] !== undefined) out.push({ t: "spoiler", v: m[3] });
    else if (m[4] !== undefined) out.push({ t: "bold", v: m[4] });
    else if (m[5] !== undefined) out.push({ t: "under", v: m[5] });
    else if (m[6] !== undefined) out.push({ t: "strike", v: m[6] });
    else if (m[7] !== undefined) out.push({ t: "italic", v: m[7] });
    else if (m[8] !== undefined) out.push({ t: "mention", v: m[8] });
    else if (m[9] !== undefined) out.push({ t: "channel", v: m[9] });
    else if (m[10] !== undefined) out.push({ t: "url", v: m[10] });
    last = m.index + m[0].length;
  }
  if (last < src.length) out.push({ t: "text", v: src.slice(last) });
  return out.flatMap((tok) => {
    if (tok.t !== "text") return [tok];
    const parts = tok.v.split("\n");
    const r: Tok[] = [];
    parts.forEach((p, i) => {
      if (p) r.push({ t: "text", v: p });
      if (i < parts.length - 1) r.push({ t: "br" });
    });
    return r;
  });
}

export function Markdown({ text }: { text: string }) {
  const users = useDiscord((s) => s.users);
  const openProfile = useDiscord((s) => s.openProfile);
  const tokens = tokenize(text);
  return (
    <>
      {tokens.map((tok, i) => {
        switch (tok.t) {
          case "br":
            return <br key={i} />;
          case "code":
            return (
              <code
                key={i}
                className="rounded-xs bg-dc-server px-1 py-0.5 font-mono text-[0.85em] text-dc-heading"
              >
                {tok.v}
              </code>
            );
          case "pre":
            return (
              <pre
                key={i}
                className="my-1 overflow-x-auto rounded-md bg-dc-server p-2 font-mono text-[13px] leading-snug text-dc-heading"
              >
                {tok.v}
              </pre>
            );
          case "bold":
            return <strong key={i}>{tok.v}</strong>;
          case "italic":
            return <em key={i}>{tok.v}</em>;
          case "under":
            return (
              <span key={i} className="underline">
                {tok.v}
              </span>
            );
          case "strike":
            return (
              <s key={i} className="text-dc-muted">
                {tok.v}
              </s>
            );
          case "spoiler":
            return <Spoiler key={i}>{tok.v}</Spoiler>;
          case "mention": {
            const user = Object.values(users).find(
              (u) => u.username.toLowerCase() === tok.v.toLowerCase() || u.id === tok.v.toLowerCase(),
            );
            const everyone = tok.v === "everyone" || tok.v === "here";
            return (
              <span
                key={i}
                className="mention-chip"
                onClick={() => user && openProfile(user.id)}
              >
                @{user?.displayName ?? tok.v}
                {everyone ? "" : ""}
              </span>
            );
          }
          case "channel":
            return (
              <span key={i} className="mention-chip">
                #{tok.v}
              </span>
            );
          case "url":
            return (
              <a
                key={i}
                href={tok.v}
                target="_blank"
                rel="noreferrer"
                className="text-dc-link hover:underline"
              >
                {tok.v}
              </a>
            );
          default:
            return <span key={i}>{tok.v}</span>;
        }
      })}
    </>
  );
}
