import type { CSSProperties } from "react";

type Palette = { bg: string; a: string; b: string; c: string; d: string };

const palettes: Record<string, Palette> = {
  trinity: { bg: "#7dd3fc", a: "#f8fafc", b: "#fde68a", c: "#38bdf8", d: "#0ea5e9" },
  dyno: { bg: "#3b82f6", a: "#93c5fd", b: "#1e3a8a", c: "#60a5fa", d: "#dbeafe" },
  discord: { bg: "#5865f2", a: "#ffffff", b: "#4752c4", c: "#8090ff", d: "#1e1f22" },
  welcomer: { bg: "#fbbf24", a: "#1e1f22", b: "#fef3c7", c: "#f59e0b", d: "#78350f" },
  ivana: { bg: "#4c1d95", a: "#c4b5fd", b: "#1e1b4b", c: "#a78bfa", d: "#2e1065" },
  bruna: { bg: "#fb7185", a: "#ffe4e6", b: "#9f1239", c: "#fda4af", d: "#881337" },
  kika: { bg: "#f472b6", a: "#831843", b: "#fbcfe8", c: "#db2777", d: "#9d174d" },
  tickety: { bg: "#64748b", a: "#e2e8f0", b: "#0f172a", c: "#94a3b8", d: "#334155" },
  garden: { bg: "#4ade80", a: "#14532d", b: "#bbf7d0", c: "#22c55e", d: "#166534" },
  tracker: { bg: "#22d3ee", a: "#083344", b: "#a5f3fc", c: "#06b6d4", d: "#155e75" },
  luna: { bg: "#fb7185", a: "#4c0519", b: "#fecdd3", c: "#e11d48", d: "#9f1239" },
  ash: { bg: "#e5e7eb", a: "#111827", b: "#9ca3af", c: "#6b7280", d: "#f9fafb" },
  raven: { bg: "#111827", a: "#f9fafb", b: "#374151", c: "#9ca3af", d: "#030712" },
  vault: { bg: "#1d4ed8", a: "#dbeafe", b: "#1e3a8a", c: "#60a5fa", d: "#1e40af" },
  hug: { bg: "#7c3aed", a: "#f5d0fe", b: "#4c1d95", c: "#c084fc", d: "#2e1065" },
  night: { bg: "#0f172a", a: "#38bdf8", b: "#1e293b", c: "#7c3aed", d: "#22d3ee" },
  lady: { bg: "#ef4444", a: "#111827", b: "#fecaca", c: "#f87171", d: "#7f1d1d" },
  pixel: { bg: "#f97316", a: "#fff7ed", b: "#9a3412", c: "#fdba74", d: "#7c2d12" },
  study: { bg: "#0ea5e9", a: "#e0f2fe", b: "#075985", c: "#7dd3fc", d: "#0c4a6e" },
  music: { bg: "#ec4899", a: "#fce7f3", b: "#9d174d", c: "#f9a8d4", d: "#831843" },
  dev: { bg: "#10b981", a: "#ecfdf5", b: "#064e3b", c: "#6ee7b7", d: "#022c22" },
  anime: { bg: "#a855f7", a: "#f3e8ff", b: "#6b21a8", c: "#d8b4fe", d: "#581c87" },
  wumpus: { bg: "#5865f2", a: "#fde68a", b: "#1e1f22", c: "#93c5fd", d: "#312e81" },
  kai: { bg: "#2dd4bf", a: "#134e4a", b: "#99f6e4", c: "#14b8a6", d: "#115e59" },
  nina: { bg: "#f43f5e", a: "#fff1f2", b: "#9f1239", c: "#fda4af", d: "#881337" },
  leo: { bg: "#f59e0b", a: "#1c1917", b: "#fde68a", c: "#d97706", d: "#78350f" },
  mira: { bg: "#818cf8", a: "#eef2ff", b: "#312e81", c: "#a5b4fc", d: "#1e1b4b" },
  tor: { bg: "#94a3b8", a: "#0f172a", b: "#e2e8f0", c: "#64748b", d: "#1e293b" },
  void: { bg: "#1e1b4b", a: "#c4b5fd", b: "#0f172a", c: "#818cf8", d: "#312e81" },
  default: { bg: "#5865f2", a: "#ffffff", b: "#1e1f22", c: "#8090ff", d: "#4752c4" },
};

function P(id: string): Palette {
  return palettes[id] ?? palettes.default;
}

export function AvatarArt({ id, size = 40 }: { id: string; size?: number }) {
  const p = P(id);
  const s = { width: size, height: size, display: "block" } as CSSProperties;
  switch (id) {
    case "trinity":
      return (
        <svg viewBox="0 0 64 64" style={s} aria-hidden>
          <rect width="64" height="64" fill={p.bg} />
          <circle cx="32" cy="40" r="18" fill={p.c} />
          <circle cx="32" cy="28" r="13" fill={p.b} />
          <path d="M16 26c4-14 28-14 32 0 0 0-4-8-16-8S16 26 16 26z" fill={p.a} />
          <path d="M18 22c6-10 22-10 28 0v4c-6-8-22-8-28 0z" fill={p.a} />
          <circle cx="27" cy="28" r="2" fill="#1e1f22" />
          <circle cx="37" cy="28" r="2" fill="#1e1f22" />
          <path d="M28 34c2 2 6 2 8 0" stroke="#b45309" strokeWidth="1.4" fill="none" strokeLinecap="round" />
        </svg>
      );
    case "luna":
      return (
        <svg viewBox="0 0 64 64" style={s} aria-hidden>
          <rect width="64" height="64" fill={p.bg} />
          <path d="M18 22 L24 8 L30 22" fill={p.a} />
          <path d="M34 22 L40 8 L46 22" fill={p.a} />
          <circle cx="32" cy="34" r="16" fill={p.c} />
          <circle cx="32" cy="30" r="12" fill="#fecdd3" />
          <circle cx="27" cy="29" r="2" fill="#1e1f22" />
          <circle cx="37" cy="29" r="2" fill="#1e1f22" />
          <circle cx="24" cy="34" r="3" fill="#fb7185" opacity="0.7" />
          <circle cx="40" cy="34" r="3" fill="#fb7185" opacity="0.7" />
          <path d="M20 22c8-6 16-6 24 0" fill={p.d} />
        </svg>
      );
    case "ash":
      return (
        <svg viewBox="0 0 64 64" style={s} aria-hidden>
          <rect width="64" height="64" fill={p.bg} />
          <circle cx="32" cy="36" r="16" fill={p.b} />
          <circle cx="32" cy="28" r="12" fill="#f5f5f4" />
          <path d="M20 24c0-10 24-10 24 0v6H20z" fill={p.a} />
          <circle cx="27" cy="28" r="1.8" fill="#111" />
          <circle cx="37" cy="28" r="1.8" fill="#111" />
        </svg>
      );
    case "raven":
      return (
        <svg viewBox="0 0 64 64" style={s} aria-hidden>
          <rect width="64" height="64" fill={p.bg} />
          <circle cx="32" cy="38" r="16" fill="#e7e5e4" />
          <circle cx="32" cy="28" r="12" fill="#f5f5f4" />
          <path d="M14 20c6-12 16-8 18 0 2-10 14-12 20 2-8-2-14 6-18 8-6-4-14-6-20-10z" fill={p.a} />
          <circle cx="27" cy="28" r="2" fill="#111" />
          <circle cx="37" cy="28" r="2" fill="#111" />
        </svg>
      );
    case "welcomer":
      return (
        <svg viewBox="0 0 64 64" style={s} aria-hidden>
          <rect width="64" height="64" fill={p.bg} />
          <circle cx="32" cy="34" r="18" fill={p.a} />
          <circle cx="24" cy="30" r="3" fill={p.b} />
          <circle cx="40" cy="30" r="3" fill={p.b} />
          <path d="M22 44c6 6 14 6 20 0" stroke={p.b} strokeWidth="2" fill="none" />
          <path d="M20 38c4 2 8 2 12-6 4 8 8 8 12 6" stroke={p.c} strokeWidth="3" fill="none" strokeLinecap="round" />
          <rect x="26" y="8" width="12" height="8" rx="2" fill={p.a} />
        </svg>
      );
    case "dyno":
      return (
        <svg viewBox="0 0 64 64" style={s} aria-hidden>
          <rect width="64" height="64" fill={p.bg} />
          <path d="M12 40 L32 12 L52 40 L44 40 L44 52 L20 52 L20 40 Z" fill={p.a} />
          <circle cx="32" cy="36" r="6" fill={p.b} />
        </svg>
      );
    case "discord":
      return (
        <svg viewBox="0 0 64 64" style={s} aria-hidden>
          <rect width="64" height="64" rx="16" fill={p.bg} />
          <path
            fill={p.a}
            d="M44 20c-2-1-4-2-6-2l-.5 1c4 1 6 3 8 5-3-2-7-4-11-4s-8 2-11 4c2-2 4-4 8-5l-.5-1c-2 0-4 1-6 2-5 8-6 15-5 22 3 2 6 4 9 4l1-2c-1 0-3-1-4-1 3 2 6 3 10 3s7-1 10-3c-1 0-3 1-4 1l1 2c3 0 6-2 9-4 1-7 0-14-5-22zm-15 18c-1 0-2-1-2-3s1-3 2-3 2 1 2 3-1 3-2 3zm10 0c-1 0-2-1-2-3s1-3 2-3 2 1 2 3-1 3-2 3z"
          />
        </svg>
      );
    case "tickety":
      return (
        <svg viewBox="0 0 64 64" style={s} aria-hidden>
          <rect width="64" height="64" fill={p.bg} />
          <rect x="16" y="14" width="32" height="36" rx="4" fill={p.a} />
          <path d="M16 28 h32" stroke={p.b} strokeWidth="2" />
          <circle cx="32" cy="40" r="6" fill={p.c} />
          <path d="M29 40 l2 2 4-5" stroke={p.b} strokeWidth="2" fill="none" />
        </svg>
      );
    case "garden":
      return (
        <svg viewBox="0 0 64 64" style={s} aria-hidden>
          <rect width="64" height="64" fill="#86efac" />
          <ellipse cx="32" cy="28" rx="14" ry="16" fill="#22c55e" />
          <rect x="28" y="36" width="8" height="18" rx="3" fill="#f97316" />
          <ellipse cx="32" cy="22" rx="5" ry="6" fill="#4ade80" />
        </svg>
      );
    case "tracker":
      return (
        <svg viewBox="0 0 64 64" style={s} aria-hidden>
          <rect width="64" height="64" fill={p.bg} />
          <circle cx="32" cy="32" r="16" fill="none" stroke={p.a} strokeWidth="4" />
          <path d="M32 20 v12 l8 8" stroke={p.a} strokeWidth="4" fill="none" strokeLinecap="round" />
          <circle cx="48" cy="16" r="8" fill="#22c55e" />
          <path d="M45 16 l2 2 4-4" stroke="#fff" strokeWidth="2" fill="none" />
        </svg>
      );
    case "bruna":
      return (
        <svg viewBox="0 0 64 64" style={s} aria-hidden>
          <rect width="64" height="64" fill={p.bg} />
          <circle cx="32" cy="40" r="16" fill="#fda4af" />
          <circle cx="32" cy="26" r="12" fill="#fed7aa" />
          <path d="M18 24c4-12 24-12 28 0-8-4-20-4-28 0z" fill="#7c2d12" />
          <circle cx="27" cy="26" r="1.8" fill="#1e1f22" />
          <circle cx="37" cy="26" r="1.8" fill="#1e1f22" />
        </svg>
      );
    case "ivana":
      return (
        <svg viewBox="0 0 64 64" style={s} aria-hidden>
          <rect width="64" height="64" fill={p.bg} />
          <circle cx="32" cy="40" r="16" fill={p.c} />
          <circle cx="32" cy="26" r="12" fill="#f5d0fe" />
          <path d="M18 22c6-12 22-12 28 0v6H18z" fill="#1e1b4b" />
          <circle cx="27" cy="26" r="1.6" fill="#1e1f22" />
          <circle cx="37" cy="26" r="1.6" fill="#1e1f22" />
        </svg>
      );
    case "kika":
      return (
        <svg viewBox="0 0 64 64" style={s} aria-hidden>
          <rect width="64" height="64" fill={p.bg} />
          <circle cx="32" cy="38" r="16" fill="#f9a8d4" />
          <circle cx="32" cy="26" r="12" fill="#fecdd3" />
          <path d="M16 28c8-16 24-16 32 0-10-6-22-6-32 0z" fill="#831843" />
          <circle cx="27" cy="26" r="1.8" fill="#1e1f22" />
          <circle cx="37" cy="26" r="1.8" fill="#1e1f22" />
          <path d="M40 18 l6-8 2 8" fill="#f472b6" />
        </svg>
      );
    case "vault":
      return (
        <svg viewBox="0 0 64 64" style={s} aria-hidden>
          <rect width="64" height="64" fill={p.bg} />
          <text x="32" y="40" textAnchor="middle" fontSize="16" fontWeight="800" fill={p.a} fontFamily="sans-serif">
            VX
          </text>
        </svg>
      );
    case "hug":
      return (
        <svg viewBox="0 0 64 64" style={s} aria-hidden>
          <rect width="64" height="64" fill={p.bg} />
          <circle cx="24" cy="30" r="10" fill={p.a} />
          <circle cx="40" cy="30" r="10" fill={p.c} />
          <path d="M16 44c8 8 24 8 32 0" stroke={p.a} strokeWidth="4" fill="none" />
        </svg>
      );
    case "night":
      return (
        <svg viewBox="0 0 64 64" style={s} aria-hidden>
          <rect width="64" height="64" fill={p.bg} />
          <rect x="8" y="36" width="48" height="16" rx="4" fill="#1e293b" />
          <circle cx="18" cy="44" r="5" fill="#0f172a" />
          <circle cx="46" cy="44" r="5" fill="#0f172a" />
          <rect x="14" y="28" width="28" height="10" rx="2" fill="#334155" />
          <rect x="40" y="22" width="10" height="16" fill="#7c3aed" />
          <circle cx="48" cy="14" r="4" fill="#fde68a" />
        </svg>
      );
    case "lady":
      return (
        <svg viewBox="0 0 64 64" style={s} aria-hidden>
          <rect width="64" height="64" fill="#14532d" />
          <ellipse cx="32" cy="34" rx="18" ry="20" fill="#ef4444" />
          <path d="M32 14 v40" stroke="#111" strokeWidth="3" />
          <circle cx="24" cy="28" r="3" fill="#111" />
          <circle cx="40" cy="30" r="3" fill="#111" />
          <circle cx="26" cy="40" r="2.4" fill="#111" />
          <circle cx="38" cy="42" r="2.4" fill="#111" />
        </svg>
      );
    case "wumpus":
      return (
        <svg viewBox="0 0 64 64" style={s} aria-hidden>
          <rect width="64" height="64" fill={p.bg} />
          <ellipse cx="32" cy="36" rx="18" ry="16" fill={p.a} />
          <circle cx="24" cy="32" r="4" fill={p.b} />
          <circle cx="40" cy="32" r="4" fill={p.b} />
          <circle cx="25" cy="31" r="1.4" fill="#fff" />
          <circle cx="41" cy="31" r="1.4" fill="#fff" />
          <path d="M24 44c6 4 10 4 16 0" stroke={p.b} strokeWidth="2" fill="none" />
        </svg>
      );
    default: {
      const letter = (id[0] || "N").toUpperCase();
      return (
        <svg viewBox="0 0 64 64" style={s} aria-hidden>
          <rect width="64" height="64" fill={p.bg} />
          <circle cx="32" cy="24" r="10" fill={p.a} opacity="0.9" />
          <ellipse cx="32" cy="48" rx="16" ry="12" fill={p.a} opacity="0.9" />
          <text
            x="32"
            y="28"
            textAnchor="middle"
            fontSize="12"
            fontWeight="700"
            fill={p.b}
            fontFamily="sans-serif"
          >
            {letter}
          </text>
        </svg>
      );
    }
  }
}

export function ServerArt({ id, size = 48 }: { id: string; size?: number }) {
  return (
    <div className="overflow-hidden size-full" style={{ borderRadius: size > 40 ? 16 : 12 }}>
      <AvatarArt id={id} size={size} />
    </div>
  );
}

export const AVATAR_IDS = Object.keys(palettes);
