import { create } from "zustand";
import { persist } from "zustand/middleware";
import { uid } from "@/lib/utils";
import type {
  CallState,
  Channel,
  ChannelType,
  ContextMenuState,
  DMChannel,
  FriendRelation,
  FriendStatus,
  Message,
  MobilePane,
  Presence,
  Server,
  Settings,
  ToastItem,
  User,
  VoiceState,
} from "./types";
import {
  ME_ID,
  defaultSettings,
  dms as seedDms,
  friends as seedFriends,
  messages as seedMessages,
  servers as seedServers,
  users as seedUsers,
  slashCommands,
} from "./seed";

export type Overlay =
  | null
  | "settings"
  | "server-settings"
  | "create-server"
  | "join-server"
  | "create-channel"
  | "invite"
  | "inbox"
  | "pins"
  | "quick-switcher"
  | "search"
  | "emoji"
  | "gif"
  | "sticker"
  | "slash"
  | "status"
  | "user-profile"
  | "nitro"
  | "shop"
  | "quests"
  | "discover"
  | "shortcuts"
  | "gift"
  | "forward"
  | "new-dm"
  | "group-dm"
  | "channel-settings"
  | "whats-new"
  | "help"
  | "soundboard"
  | "activities"
  | "nsfw"
  | "logout";

interface DiscordState {
  hydrated: boolean;
  loggedIn: boolean;
  meId: string;
  users: Record<string, User>;
  servers: Server[];
  dms: DMChannel[];
  friends: FriendRelation[];
  messages: Record<string, Message[]>;
  settings: Settings;
  activeServerId: string | null;
  activeChannelId: string | null;
  activeDmId: string | null;
  mobilePane: MobilePane;
  memberListOpen: boolean;
  overlay: Overlay;
  overlayTab: string;
  profileUserId: string | null;
  contextMenu: ContextMenuState | null;
  replyTo: Message | null;
  editingId: string | null;
  voice: VoiceState | null;
  call: CallState | null;
  typing: { channelId: string; userIds: string[] } | null;
  toasts: ToastItem[];
  nsfwAllowed: Record<string, boolean>;
  notes: Record<string, string>;
  collapsedCats: Record<string, boolean>;
  mutedChannels: Record<string, boolean>;
  unreadAck: Record<string, boolean>;
  lastSlow: Record<string, number>;
  composer: string;
  searchQuery: string;
  friendsTab: "online" | "all" | "pending" | "blocked" | "add";
  settingsSection: string;
  serverSettingsSection: string;
  emojiCategory: string;
  forwardedMessage: Message | null;
  threadOf: Message | null;
  plusMenu: boolean;
  userMenu: boolean;
  serverMenu: boolean;
  attachPreview: { name: string; url: string; type: string } | null;

  login: (displayName?: string, username?: string) => void;
  logout: () => void;
  reset: () => void;
  setHydrated: () => void;
  t: () => Settings["language"];

  setActiveServer: (id: string | null) => void;
  setActiveChannel: (id: string) => void;
  setActiveDm: (id: string | null) => void;
  setMobilePane: (p: MobilePane) => void;
  toggleMembers: () => void;
  openOverlay: (o: Overlay, tab?: string) => void;
  closeOverlay: () => void;
  setOverlayTab: (t: string) => void;
  openProfile: (userId: string) => void;
  setContextMenu: (m: ContextMenuState | null) => void;
  setReply: (m: Message | null) => void;
  setEditing: (id: string | null) => void;
  setComposer: (v: string) => void;
  setSearch: (v: string) => void;
  setFriendsTab: (t: DiscordState["friendsTab"]) => void;
  setSettingsSection: (s: string) => void;
  setServerSettingsSection: (s: string) => void;
  setPlusMenu: (v: boolean) => void;
  setUserMenu: (v: boolean) => void;
  setServerMenu: (v: boolean) => void;
  setAttach: (a: DiscordState["attachPreview"]) => void;
  patchSettings: (p: Partial<Settings>) => void;
  setStatus: (s: Presence, custom?: string, emoji?: string) => void;
  setNote: (userId: string, note: string) => void;
  toggleCat: (id: string) => void;
  toggleMuteChannel: (id: string) => void;
  markRead: (id: string) => void;
  toast: (title: string, body?: string, tone?: ToastItem["tone"]) => void;
  dismissToast: (id: string) => void;

  sendMessage: (channelId: string, content: string, opts?: Partial<Message>) => void;
  editMessage: (channelId: string, id: string, content: string) => void;
  deleteMessage: (channelId: string, id: string) => void;
  react: (channelId: string, id: string, emoji: string) => void;
  pinMessage: (channelId: string, id: string) => void;
  votePoll: (channelId: string, msgId: string, optionId: string) => void;

  joinVoice: (serverId: string | null, channelId: string) => void;
  leaveVoice: () => void;
  patchVoice: (p: Partial<VoiceState>) => void;
  startCall: (dmId: string, video: boolean) => void;
  endCall: () => void;

  addFriend: (username: string) => void;
  setFriendStatus: (userId: string, status: FriendStatus | "remove") => void;
  createGroup: (userIds: string[], name: string) => void;
  closeDm: (id: string) => void;

  createServer: (name: string) => void;
  joinServerByVanity: (code: string) => void;
  leaveServer: (id: string) => void;
  createChannel: (serverId: string, name: string, type: ChannelType, categoryId?: string) => void;
  deleteChannel: (serverId: string, channelId: string) => void;
  renameServer: (id: string, name: string) => void;
  updateMe: (p: Partial<User>) => void;
}

function cloneSeed() {
  return {
    users: structuredClone(seedUsers),
    servers: structuredClone(seedServers),
    dms: structuredClone(seedDms),
    friends: structuredClone(seedFriends),
    messages: structuredClone(seedMessages),
  };
}

function flattenChannels(servers: Server[]): Channel[] {
  return servers.flatMap((s) => s.categories.flatMap((c) => c.channels));
}

function botReply(content: string): string | null {
  const c = content.trim();
  const low = c.toLowerCase();
  if (low.startsWith("/help"))
    return "Comandos: " + slashCommands.map((s) => "`/" + s.name + "`").join(" · ");
  if (low.startsWith("/ping")) return "Pong! `27ms` · shard 0";
  if (low.startsWith("/tableflip")) return "(╯°□°)╯︵ ┻━┻";
  if (low.startsWith("/shrug")) return "¯\\\\_(ツ)_/¯";
  if (low.startsWith("/lenny")) return "( ͡° ͜ʖ ͡°)";
  if (low.startsWith("/serverinfo"))
    return "**Nexus HQ** · 12.840 membros · dono: Discord · boosts: 14";
  if (low.startsWith("/userinfo")) return "Usuário **trinity** · criado em 2024 · Nitro ativo";
  if (low.startsWith("/avatar")) return "Avatar de **trinity** — veja o perfil.";
  if (low.startsWith("/play ")) return "▶︎ Tocando **" + c.slice(6) + "** no Lounge";
  if (low.startsWith("/np")) return "▶︎ **Midnight City** — M83 · 2:14 / 4:03";
  if (low.startsWith("/skip")) return "Faixa pulada.";
  if (low.startsWith("/queue")) return "Fila: 1. Midnight City · 2. Blinding Lights · 3. Nightcall";
  if (low.startsWith("/invite")) return "Convite: https://nexus.gg/invite/trinity";
  if (low.startsWith("/ticket")) return "Ticket **#2048** aberto. Um moderador já foi notificado.";
  if (low.startsWith("/giveaway")) return "🎉 Sorteio criado. Reaja com 🎉 para participar.";
  if (low.startsWith("/me ")) return "*" + c.slice(4) + "*";
  if (low === "/tts") return "TTS ativado nesta mensagem.";
  return null;
}

function parsePoll(content: string): Message["poll"] | undefined {
  if (!content.toLowerCase().startsWith("/poll ")) return undefined;
  const rest = content.slice(6);
  const parts = rest.split("|").map((p) => p.trim()).filter(Boolean);
  if (parts.length < 3) return undefined;
  return {
    question: parts[0],
    options: parts.slice(1).map((label, i) => ({
      id: "o" + i,
      label,
      votes: 0,
    })),
  };
}

const initial = () => {
  const seed = cloneSeed();
  return {
    hydrated: false,
    loggedIn: false,
    meId: ME_ID,
    ...seed,
    settings: { ...defaultSettings },
    activeServerId: null as string | null,
    activeChannelId: null as string | null,
    activeDmId: null as string | null,
    mobilePane: "list" as MobilePane,
    memberListOpen: true,
    overlay: null as Overlay,
    overlayTab: "myAccount",
    profileUserId: null as string | null,
    contextMenu: null as ContextMenuState | null,
    replyTo: null as Message | null,
    editingId: null as string | null,
    voice: null as VoiceState | null,
    call: null as CallState | null,
    typing: null as DiscordState["typing"],
    toasts: [] as ToastItem[],
    nsfwAllowed: {} as Record<string, boolean>,
    notes: {} as Record<string, string>,
    collapsedCats: {} as Record<string, boolean>,
    mutedChannels: {} as Record<string, boolean>,
    unreadAck: {} as Record<string, boolean>,
    lastSlow: {} as Record<string, number>,
    composer: "",
    searchQuery: "",
    friendsTab: "online" as DiscordState["friendsTab"],
    settingsSection: "myAccount",
    serverSettingsSection: "overview",
    emojiCategory: "recent",
    forwardedMessage: null as Message | null,
    threadOf: null as Message | null,
    plusMenu: false,
    userMenu: false,
    serverMenu: false,
    attachPreview: null as DiscordState["attachPreview"],
  };
};

export const useDiscord = create<DiscordState>()(
  persist(
    (set, get) => ({
      ...initial(),

      setHydrated: () => set({ hydrated: true }),
      t: () => get().settings.language,

      login: (displayName, username) => {
        const me = { ...get().users[ME_ID] };
        if (displayName) me.displayName = displayName;
        if (username) me.username = username.replace(/[^a-z0-9._]/gi, "").toLowerCase() || me.username;
        set({
          loggedIn: true,
          users: { ...get().users, [ME_ID]: me },
          overlay: null,
        });
      },
      logout: () => set({ loggedIn: false, overlay: null, userMenu: false }),
      reset: () => {
        const seed = cloneSeed();
        set({ ...initial(), ...seed, hydrated: true, loggedIn: false });
      },

      setActiveServer: (id) => {
        const s = get().servers.find((x) => x.id === id);
        const first = s?.categories.flatMap((c) => c.channels).find((c) => c.type === "text" || c.type === "announcement" || c.type === "rules");
        set({
          activeServerId: id,
          activeChannelId: first?.id ?? null,
          activeDmId: null,
          mobilePane: id ? "list" : "list",
          serverMenu: false,
          plusMenu: false,
        });
      },
      setActiveChannel: (id) => {
        const ch = flattenChannels(get().servers).find((c) => c.id === id);
        if (ch?.nsfw && !get().nsfwAllowed[id]) {
          set({ overlay: "nsfw", activeChannelId: id, mobilePane: "chat" });
          return;
        }
        if (ch?.type === "voice" || ch?.type === "stage") {
          get().joinVoice(ch.serverId, ch.id);
          return;
        }
        set({
          activeChannelId: id,
          activeDmId: null,
          mobilePane: "chat",
          overlay: null,
        });
        get().markRead(id);
      },
      setActiveDm: (id) => {
        set({
          activeDmId: id,
          activeServerId: null,
          activeChannelId: null,
          mobilePane: id ? "chat" : "list",
        });
        if (id) get().markRead(id);
      },
      setMobilePane: (p) => set({ mobilePane: p }),
      toggleMembers: () => set({ memberListOpen: !get().memberListOpen }),
      openOverlay: (o, tab) =>
        set({
          overlay: o,
          overlayTab: tab ?? get().overlayTab,
          plusMenu: false,
          userMenu: false,
          serverMenu: false,
          contextMenu: null,
          ...(tab && o === "settings" ? { settingsSection: tab } : {}),
          ...(tab && o === "server-settings" ? { serverSettingsSection: tab } : {}),
        }),
      closeOverlay: () =>
        set({
          overlay: null,
          contextMenu: null,
          plusMenu: false,
          userMenu: false,
          serverMenu: false,
          forwardedMessage: null,
        }),
      setOverlayTab: (t) => set({ overlayTab: t }),
      openProfile: (userId) => set({ overlay: "user-profile", profileUserId: userId, contextMenu: null }),
      setContextMenu: (m) => set({ contextMenu: m, plusMenu: false, userMenu: false }),
      setReply: (m) => set({ replyTo: m, editingId: null }),
      setEditing: (id) => set({ editingId: id, replyTo: null }),
      setComposer: (v) => set({ composer: v }),
      setSearch: (v) => set({ searchQuery: v }),
      setFriendsTab: (t) => set({ friendsTab: t, activeDmId: null, mobilePane: "list" }),
      setSettingsSection: (s) => set({ settingsSection: s }),
      setServerSettingsSection: (s) => set({ serverSettingsSection: s }),
      setPlusMenu: (v) => set({ plusMenu: v, userMenu: false, serverMenu: false }),
      setUserMenu: (v) => set({ userMenu: v, plusMenu: false, serverMenu: false }),
      setServerMenu: (v) => set({ serverMenu: v, plusMenu: false, userMenu: false }),
      setAttach: (a) => set({ attachPreview: a }),
      patchSettings: (p) => set({ settings: { ...get().settings, ...p } }),
      setStatus: (s, custom, emoji) => {
        const me = { ...get().users[get().meId], status: s };
        if (custom !== undefined) me.customStatus = custom;
        if (emoji !== undefined) me.customStatusEmoji = emoji;
        if (s === "dnd") me.customStatus = me.customStatus || "Não perturbar";
        set({ users: { ...get().users, [me.id]: me }, overlay: get().overlay === "status" ? null : get().overlay, userMenu: false });
      },
      setNote: (userId, note) => set({ notes: { ...get().notes, [userId]: note } }),
      toggleCat: (id) => set({ collapsedCats: { ...get().collapsedCats, [id]: !get().collapsedCats[id] } }),
      toggleMuteChannel: (id) =>
        set({ mutedChannels: { ...get().mutedChannels, [id]: !get().mutedChannels[id] } }),
      markRead: (id) => {
        const servers = get().servers.map((s) => ({
          ...s,
          categories: s.categories.map((c) => ({
            ...c,
            channels: c.channels.map((ch) =>
              ch.id === id ? { ...ch, unread: false, mentions: 0 } : ch,
            ),
          })),
          unread: s.categories.some((c) => c.channels.some((ch) => ch.id === id))
            ? 0
            : s.unread,
          mentions: s.categories.some((c) => c.channels.some((ch) => ch.id === id))
            ? 0
            : s.mentions,
        }));
        const dms = get().dms.map((d) => (d.id === id ? { ...d, unread: 0 } : d));
        set({ servers, dms, unreadAck: { ...get().unreadAck, [id]: true } });
      },
      toast: (title, body, tone = "info") => {
        const id = uid("toast");
        set({ toasts: [...get().toasts, { id, title, body, tone }].slice(-4) });
        setTimeout(() => get().dismissToast(id), 3200);
      },
      dismissToast: (id) => set({ toasts: get().toasts.filter((t) => t.id !== id) }),

      sendMessage: (channelId, content, opts) => {
        const trimmed = content.trim();
        if (!trimmed && !get().attachPreview && !opts?.attachments) return;
        const slow = flattenChannels(get().servers).find((c) => c.id === channelId)?.slowmode ?? 0;
        if (slow) {
          const last = get().lastSlow[channelId] ?? 0;
          if (Date.now() - last < slow * 1000) {
            get().toast("Modo lento", `Espere ${slow}s`);
            return;
          }
        }
        let body = trimmed;
        if (body.toLowerCase().startsWith("/spoiler ")) body = "||" + body.slice(9) + "||";
        const poll = parsePoll(body);
        if (poll) body = poll.question;
        const attach = get().attachPreview;
        const m: Message = {
          id: uid("msg"),
          channelId,
          authorId: get().meId,
          content: body,
          createdAt: new Date().toISOString(),
          type: get().replyTo ? "reply" : poll ? "poll" : "default",
          replyToId: get().replyTo?.id,
          poll,
          attachments: attach
            ? [
                {
                  id: uid("att"),
                  name: attach.name,
                  type: attach.type.startsWith("image") ? "image" : "file",
                  url: attach.url,
                },
              ]
            : opts?.attachments,
          mentions: Array.from(body.matchAll(/@([a-z0-9._]+)/gi)).map((x) => x[1].toLowerCase()),
          mentionEveryone: /@everyone|@here/i.test(body),
          ...opts,
        };
        const list = [...(get().messages[channelId] ?? []), m];
        const messages = { ...get().messages, [channelId]: list };
        const dms = get().dms.map((d) =>
          d.id === channelId
            ? { ...d, lastMessage: `Você: ${body.slice(0, 40)}`, lastAt: m.createdAt, unread: 0 }
            : d,
        );
        set({
          messages,
          dms,
          composer: "",
          replyTo: null,
          attachPreview: null,
          lastSlow: { ...get().lastSlow, [channelId]: Date.now() },
        });

        const reply = botReply(trimmed);
        if (reply) {
          const botId =
            trimmed.startsWith("/ticket") ? "tickety" : trimmed.startsWith("/invite") ? "tracker" : "dyno";
          setTimeout(() => {
            const botMsg: Message = {
              id: uid("msg"),
              channelId,
              authorId: botId,
              content: reply,
              createdAt: new Date().toISOString(),
              type: "default",
            };
            const cur = useDiscord.getState();
            useDiscord.setState({
              messages: {
                ...cur.messages,
                [channelId]: [...(cur.messages[channelId] ?? []), botMsg],
              },
              typing: null,
            });
          }, 700);
          set({ typing: { channelId, userIds: [trimmed.startsWith("/ticket") ? "tickety" : "dyno"] } });
        } else if (channelId.startsWith("dm-") || channelId.startsWith("gdm-")) {
          const dm = get().dms.find((d) => d.id === channelId);
          const other = dm?.userIds.find((id) => id !== get().meId);
          const otherUser = other ? get().users[other] : undefined;
          if (otherUser && !otherUser.bot && otherUser.status !== "offline" && Math.random() > 0.35) {
            const replies = [
              "kkkk",
              "to on",
              "já vou",
              "calma aí",
              "sim",
              "nossa",
              "boa",
              "vou ver",
              "up",
              "hmmm",
            ];
            set({ typing: { channelId, userIds: [otherUser.id] } });
            setTimeout(() => {
              const cur = useDiscord.getState();
              const botMsg: Message = {
                id: uid("msg"),
                channelId,
                authorId: otherUser.id,
                content: replies[Math.floor(Math.random() * replies.length)],
                createdAt: new Date().toISOString(),
                type: "default",
              };
              useDiscord.setState({
                typing: null,
                messages: {
                  ...cur.messages,
                  [channelId]: [...(cur.messages[channelId] ?? []), botMsg],
                },
                dms: cur.dms.map((d) =>
                  d.id === channelId
                    ? {
                        ...d,
                        lastMessage: `${otherUser.displayName}: ${botMsg.content}`,
                        lastAt: botMsg.createdAt,
                      }
                    : d,
                ),
              });
            }, 1200 + Math.random() * 1200);
          }
        }
      },
      editMessage: (channelId, id, content) => {
        const list = (get().messages[channelId] ?? []).map((m) =>
          m.id === id ? { ...m, content, editedAt: new Date().toISOString() } : m,
        );
        set({ messages: { ...get().messages, [channelId]: list }, editingId: null, composer: "" });
      },
      deleteMessage: (channelId, id) => {
        const list = (get().messages[channelId] ?? []).filter((m) => m.id !== id);
        set({ messages: { ...get().messages, [channelId]: list }, contextMenu: null });
        get().toast("Mensagem excluída");
      },
      react: (channelId, id, emoji) => {
        const list = (get().messages[channelId] ?? []).map((m) => {
          if (m.id !== id) return m;
          const reactions = [...(m.reactions ?? [])];
          const i = reactions.findIndex((r) => r.emoji === emoji);
          if (i >= 0) {
            const r = reactions[i];
            if (r.me) {
              r.count -= 1;
              r.me = false;
              if (r.count <= 0) reactions.splice(i, 1);
            } else {
              r.count += 1;
              r.me = true;
            }
          } else reactions.push({ emoji, count: 1, me: true });
          return { ...m, reactions };
        });
        set({ messages: { ...get().messages, [channelId]: list } });
      },
      pinMessage: (channelId, id) => {
        const list = (get().messages[channelId] ?? []).map((m) =>
          m.id === id ? { ...m, pinned: !m.pinned } : m,
        );
        set({ messages: { ...get().messages, [channelId]: list }, contextMenu: null });
        get().toast("Mensagem fixada");
      },
      votePoll: (channelId, msgId, optionId) => {
        const list = (get().messages[channelId] ?? []).map((m) => {
          if (m.id !== msgId || !m.poll) return m;
          const options = m.poll.options.map((o) =>
            o.id === optionId
              ? { ...o, votes: o.me ? o.votes - 1 : o.votes + 1, me: !o.me }
              : { ...o, me: false, votes: o.me ? o.votes - 1 : o.votes },
          );
          return { ...m, poll: { ...m.poll, options } };
        });
        set({ messages: { ...get().messages, [channelId]: list } });
      },

      joinVoice: (serverId, channelId) => {
        const servers = get().servers.map((s) => ({
          ...s,
          categories: s.categories.map((c) => ({
            ...c,
            channels: c.channels.map((ch) => {
              const ids = (ch.connectedUserIds ?? []).filter((id) => id !== get().meId);
              if (ch.id === channelId) ids.push(get().meId);
              return { ...ch, connectedUserIds: ids };
            }),
          })),
        }));
        set({
          servers,
          voice: {
            channelId,
            serverId,
            muted: get().voice?.muted ?? false,
            deafened: get().voice?.deafened ?? false,
            video: false,
            streaming: false,
            noiseSuppression: true,
          },
        });
      },
      leaveVoice: () => {
        const me = get().meId;
        const servers = get().servers.map((s) => ({
          ...s,
          categories: s.categories.map((c) => ({
            ...c,
            channels: c.channels.map((ch) => ({
              ...ch,
              connectedUserIds: (ch.connectedUserIds ?? []).filter((id) => id !== me),
            })),
          })),
        }));
        set({ servers, voice: null });
      },
      patchVoice: (p) => {
        const v = get().voice;
        if (!v) return;
        const next = { ...v, ...p };
        if (next.deafened) next.muted = true;
        set({ voice: next });
      },
      startCall: (dmId, video) => {
        set({
          call: { dmId, video, ringing: true, startedAt: new Date().toISOString() },
          activeDmId: dmId,
          mobilePane: "chat",
        });
        setTimeout(() => {
          const cur = useDiscord.getState();
          if (cur.call?.dmId === dmId) useDiscord.setState({ call: { ...cur.call, ringing: false } });
        }, 1600);
      },
      endCall: () => {
        const call = get().call;
        if (call) {
          get().sendMessage(call.dmId, "", {
            type: "call",
            content: "Chamada encerrada",
          });
        }
        set({ call: null });
      },

      addFriend: (username) => {
        const uname = username.replace(/^@/, "").trim().toLowerCase();
        const user = Object.values(get().users).find((u) => u.username.toLowerCase() === uname);
        if (!user) {
          get().toast("Não encontrado", "Confira o nome de usuário.", "error");
          return;
        }
        if (user.id === get().meId) {
          get().toast("Não dá", "Você não pode se adicionar.", "error");
          return;
        }
        const existing = get().friends.find((f) => f.userId === user.id);
        if (existing?.status === "friends") {
          get().toast("Já são amigos");
          return;
        }
        const friends = existing
          ? get().friends.map((f) => (f.userId === user.id ? { ...f, status: "pending_out" as const } : f))
          : [...get().friends, { userId: user.id, status: "pending_out" as const, since: new Date().toISOString() }];
        set({ friends });
        get().toast("Pedido enviado", user.displayName, "success");
      },
      setFriendStatus: (userId, status) => {
        if (status === "remove") {
          set({ friends: get().friends.filter((f) => f.userId !== userId) });
          return;
        }
        const friends = get().friends.some((f) => f.userId === userId)
          ? get().friends.map((f) => (f.userId === userId ? { ...f, status } : f))
          : [...get().friends, { userId, status, since: new Date().toISOString() }];
        set({ friends });
        if (status === "friends") {
          const exists = get().dms.some((d) => !d.group && d.userIds.includes(userId));
          if (!exists) {
            const dm: DMChannel = {
              id: "dm-" + userId,
              userIds: [get().meId, userId],
              lastMessage: "",
              lastAt: new Date().toISOString(),
            };
            set({ dms: [dm, ...get().dms] });
          }
        }
      },
      createGroup: (userIds, name) => {
        const dm: DMChannel = {
          id: uid("gdm"),
          userIds: [get().meId, ...userIds],
          group: true,
          name: name || userIds.map((id) => get().users[id]?.displayName).join(", "),
          lastMessage: "Grupo criado",
          lastAt: new Date().toISOString(),
        };
        set({ dms: [dm, ...get().dms], activeDmId: dm.id, overlay: null, mobilePane: "chat" });
      },
      closeDm: (id) => {
        set({
          dms: get().dms.filter((d) => d.id !== id),
          activeDmId: get().activeDmId === id ? null : get().activeDmId,
        });
      },

      createServer: (name) => {
        const id = uid("sv");
        const general: Channel = {
          id: id + "-geral",
          serverId: id,
          name: "geral",
          type: "text",
          position: 0,
          topic: "Canal geral",
        };
        const voice: Channel = {
          id: id + "-voice",
          serverId: id,
          name: "Geral",
          type: "voice",
          position: 1,
        };
        const server: Server = {
          id,
          name: name || "Meu servidor",
          icon: "wumpus",
          ownerId: get().meId,
          unread: 0,
          mentions: 0,
          boosts: 0,
          memberCount: 1,
          onlineCount: 1,
          roles: [],
          emojis: [],
          categories: [
            { id: id + "-txt", name: "CANAIS DE TEXTO", collapsed: false, channels: [general] },
            { id: id + "-vc", name: "CANAIS DE VOZ", collapsed: false, channels: [voice] },
          ],
        };
        set({
          servers: [...get().servers, server],
          overlay: null,
          activeServerId: id,
          activeChannelId: general.id,
          mobilePane: "chat",
        });
        get().toast("Servidor criado", server.name, "success");
      },
      joinServerByVanity: (code) => {
        const c = code.replace(/^https?:\/\/(nexus\.gg\/)?(invite\/)?/i, "").trim();
        const s = get().servers.find((x) => x.vanity === c || x.id === c || x.name.toLowerCase() === c.toLowerCase());
        if (!s) {
          get().toast("Convite inválido", "Esse código não existe.", "error");
          return;
        }
        get().setActiveServer(s.id);
        get().closeOverlay();
        get().toast("Entrou em " + s.name, undefined, "success");
      },
      leaveServer: (id) => {
        set({
          servers: get().servers.filter((s) => s.id !== id),
          activeServerId: get().activeServerId === id ? null : get().activeServerId,
          overlay: null,
        });
      },
      createChannel: (serverId, name, type, categoryId) => {
        const ch: Channel = {
          id: uid("ch"),
          serverId,
          name: name.replace(/\s+/g, "-").toLowerCase() || "novo-canal",
          type,
          position: 99,
        };
        const servers = get().servers.map((s) => {
          if (s.id !== serverId) return s;
          const cats = s.categories.map((c) => {
            if (categoryId && c.id !== categoryId) return c;
            if (!categoryId && c !== s.categories[0]) return c;
            return { ...c, channels: [...c.channels, ch] };
          });
          return { ...s, categories: cats };
        });
        set({ servers, overlay: null, activeChannelId: ch.id, mobilePane: "chat" });
      },
      deleteChannel: (serverId, channelId) => {
        const servers = get().servers.map((s) =>
          s.id !== serverId
            ? s
            : {
                ...s,
                categories: s.categories.map((c) => ({
                  ...c,
                  channels: c.channels.filter((ch) => ch.id !== channelId),
                })),
              },
        );
        set({
          servers,
          activeChannelId: get().activeChannelId === channelId ? null : get().activeChannelId,
          contextMenu: null,
        });
      },
      renameServer: (id, name) => {
        set({ servers: get().servers.map((s) => (s.id === id ? { ...s, name } : s)) });
      },
      updateMe: (p) => {
        const me = { ...get().users[get().meId], ...p };
        set({ users: { ...get().users, [me.id]: me } });
      },
    }),
    {
      name: "nexus-discord-v1",
      skipHydration: true,
      partialize: (s) => ({
        loggedIn: s.loggedIn,
        users: s.users,
        servers: s.servers,
        dms: s.dms,
        friends: s.friends,
        messages: s.messages,
        settings: s.settings,
        notes: s.notes,
        collapsedCats: s.collapsedCats,
        mutedChannels: s.mutedChannels,
        nsfwAllowed: s.nsfwAllowed,
        meId: s.meId,
      }),
    },
  ),
);

export function allChannels(servers: Server[]): Channel[] {
  return flattenChannels(servers);
}

export function findChannel(servers: Server[], id: string | null) {
  if (!id) return undefined;
  return flattenChannels(servers).find((c) => c.id === id);
}

export function findServer(servers: Server[], id: string | null) {
  if (!id) return undefined;
  return servers.find((s) => s.id === id);
}
