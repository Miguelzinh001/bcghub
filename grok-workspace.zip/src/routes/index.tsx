import { createFileRoute } from "@tanstack/react-router";
import { DiscordApp } from "@/components/discord/App";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <DiscordApp />;
}
